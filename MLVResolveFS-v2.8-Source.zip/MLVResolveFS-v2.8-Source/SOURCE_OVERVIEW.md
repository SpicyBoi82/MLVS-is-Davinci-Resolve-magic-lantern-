# MLV Resolve FS v2.8 — Source Code

This archive contains the editable source/scripts used by the v2.8 One-Click package.

## Main source files

- `app/MLVResolveFS-Launcher.ps1` — Windows GUI launcher and mount/unmount logic.
- `installer/Install-MLVResolveFS.ps1` — one-click installer, dependency setup, Cygwin/WinFsp setup, and backend build orchestration.
- `installer/patch_mlvfs_fastpass.py` — the main v2.8 backend patch set applied to upstream MLVFS. This implements the Resolve-oriented Fast Pass and simple naming behaviour.
- `installer/Fix-Launcher.ps1` — launcher-only update/repair logic.
- `installer/Uninstall-MLVResolveFS.ps1` — uninstall logic.
- `*.cmd` — convenience entry points used by Windows Explorer.

## Upstream backend

v2.8 does not ship a prebuilt copy of MLVFS in the installer ZIP. During installation it clones the upstream project:

https://github.com/davidmilligan/MLVFS

and applies `installer/patch_mlvfs_fastpass.py` before compiling it against Cygwin/WinFsp FUSE.

The v2.8 development/testing described in this project was performed against upstream MLVFS around commit `9f81918` (`only try shell expansion if mlv_path can't be found normally`).

## Important v2.8 changes implemented by the patcher

The patcher contains the source transformations for:

- current Magic Lantern compression flag values;
- direct LJ92/Fast Pass DNG payload handling;
- DNG metadata for lossless JPEG payloads;
- per-frame virtual DNG size handling;
- simple Resolve naming (`M22-1423_000000.dng`, etc.);
- matching WAV naming;
- clean Resolve-oriented directory listings;
- Cygwin/WinFsp compatibility changes made during the build;
- the audio/timestamp work present in the v2.8 branch.

## Dependencies

The installer uses:

- WinFsp: https://winfsp.dev/
- Cygwin: https://www.cygwin.com/
- MLVFS: https://github.com/davidmilligan/MLVFS

Review the licences of those upstream projects when redistributing the software.

## Rebuilding

The easiest way to reproduce the v2.8 build is to run `INSTALL-MLV-RESOLVE-FS.cmd` on Windows. The installer downloads dependencies, clones MLVFS, applies the Python patcher, and compiles the backend.
