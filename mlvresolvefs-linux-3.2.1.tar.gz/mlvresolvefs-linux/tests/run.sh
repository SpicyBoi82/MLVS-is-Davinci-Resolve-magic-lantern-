#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TEST_TMP="$(mktemp -d)"
trap 'rm -rf "$TEST_TMP"' EXIT
${CC:-cc} -std=gnu11 -Wall -Wextra -Wno-format-truncation -Wno-sign-compare -g \
  ${TEST_CFLAGS:--O2} tests/test_backend.c backend/lj92.c backend/dng.c backend/wav.c \
  -lm -pthread -o "$TEST_TMP/test_backend"
"$TEST_TMP/test_backend" "$TEST_TMP"
python3 tests/test_launcher.py
bash -n install.sh uninstall.sh app/mlvresolvefs-gui
