import importlib.util
from pathlib import Path
import tempfile
from gi.repository import GLib
spec=importlib.util.spec_from_file_location('app',str(Path(__file__).resolve().parents[1] / 'app/mlvresolvefs-gui.py'))
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
with tempfile.TemporaryDirectory() as tmp:
    a.CONFIG_DIR=tmp;a.SETTINGS=tmp+'/settings.json';a.MOUNTPOINT_FILE=tmp+'/mountpoint'
    a.AUTOSTART=tmp+'/autostart/mlvresolvefs.desktop';a.LOG=tmp+'/mount.log';a.STATE_DIR=tmp
    w=a.Window();w.show_all()
    while a.Gtk.events_pending(): a.Gtk.main_iteration_do(False)
    assert w.get_title().endswith('3.2.1')
    assert not w.auto_mount.get_active()
    w.auto_mount.set_active(True)
    assert Path(a.AUTOSTART).exists()
    w.dual.set_active(2);assert '--dual-iso=2' in w.backend_args()
    w.save_settings()
    assert '"dual_iso": 2' in Path(a.SETTINGS).read_text()
    w.auto_mount.set_active(False);assert not Path(a.AUTOSTART).exists()
    # Drive the actual modal clip picker and verify selection persistence.
    source=Path(tmp)/'clips';(source/'a').mkdir(parents=True);(source/'ab').mkdir()
    (source/'a/one.MLV').touch();(source/'ab/one.MLV').touch()
    w.source.set_text(str(source)); w.dual.set_active(0)
    w.bad_pixels.set_active(True)
    def accept_picker():
        for dialog in a.Gtk.Window.list_toplevels():
            if isinstance(dialog, a.ClipSelectionDialog) and len(dialog.model)==2:
                dialog.set_all(False)
                dialog.set_folder(str(source/'a'))
                assert sum(row[0] for row in dialog.model)==1
                # Individual checkboxes can override a folder selection.
                dialog.on_toggle(None, '0'); assert not dialog.model[0][0]
                dialog.on_toggle(None, '0'); assert dialog.model[0][0]
                dialog.response(a.Gtk.ResponseType.OK)
                return False
        return True
    GLib.timeout_add(50, accept_picker)
    w.on_choose_badpix()
    assert not w.bad_pixels.get_active()
    assert w.badpix_files==[str(source/'a/one.MLV')]
    assert '--bad-pixels-list='+tmp+'/bad-pixel-files.list' in w.backend_args()
    assert Path(tmp+'/bad-pixel-files.list').read_bytes()==a.os.fsencode(w.badpix_files[0])+b'\0'
    w2=a.Window()
    assert w2.badpix_files==w.badpix_files
    assert not w2.bad_pixels.get_active()
    w2.destroy()
    w.destroy()
print('PASS: real GTK window, modal per-file picker, folder selection, individual toggles, saved list, settings reload and autostart')
