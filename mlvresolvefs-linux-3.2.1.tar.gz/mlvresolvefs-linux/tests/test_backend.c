/* Exercise the production indexer and processing without requiring a FUSE mount. */
#include <assert.h>
#include <stdarg.h>
#include "../backend/index.c"
#include "../backend/process.c"
options_t g_opt;
void mrfs_log(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); vfprintf(stderr, fmt, ap); va_end(ap);
}
static void test_dual(void) {
    const int W=256, H=192, black=512, white=4095;
    uint16_t *img=malloc(W*H*2);
    for(int group=2;group<=4;group+=2) {
        clip_t c={0}; c.width=W; c.height=H; c.black=black; c.white=white;
        c.out_black=black; c.out_white=white; strcpy(c.base,"synthetic");
        for(int y=0;y<H;y++) for(int x=0;x<W;x++)
            img[y*W+x]=black+(((y/group)%2) ? 800 : 100);
        dual_detect(&c,img);
        assert(c.dual.enabled && c.dual.group==group);
        assert(fabs(c.dual.ratio-8)<0.01);
        for(int mode=1;mode<=2;mode++) for(int phase=0;phase<2*group;phase++) {
            g_opt.dualiso=mode;
            for(int y=0;y<H;y++) for(int x=0;x<W;x++)
                img[y*W+x]=black+((((y+phase)/group)%2) ? 800 : 100);
            dual_apply(&c,img);
            for(int i=0;i<W*H;i++) assert(abs((int)img[i]-(black+800))<=1);
        }
        /* Both ISO exposures clipped must stay within the output white. */
        for(int i=0;i<W*H;i++) img[i]=white;
        dual_apply(&c,img);
        for(int i=0;i<W*H;i++) assert(img[i]<=c.out_white && img[i]>=black);
    }
    clip_t c={0}; c.width=W;c.height=H;c.black=black;c.white=white;strcpy(c.base,"normal");
    for(int i=0;i<W*H;i++) img[i]=black+100;
    dual_detect(&c,img); assert(!c.dual.enabled);
    free(img);
}
static void test_edges(void) {
    uint16_t u[64],d[64];
    for(int x=0;x<64;x++) {u[x]=x<28?100:900;d[x]=x<32?100:900;}
    int xu,xd; edge_pick(u,d,30,64,2,2,&xu,&xd);
    assert(xu==28 && xd==32); /* follows this diagonal, same Bayer colour */
    edge_pick(u,d,0,64,6,2,&xu,&xd); assert(xu==0 && xd==0);
}
static void test_hist(void) {
    uint32_t *h=calloc(65536,sizeof(*h));
    for(int i=600;i<2950;i++) h[i]=2;
    for(int i=2950;i<2965;i++) h[i]=1000;
    h[60000]=1; assert(clip_pileup(h,512,20000)==2949);
    memset(h,0,65536*sizeof(*h));
    for(int i=600;i<4932;i++) h[i]=2;
    h[4932]=10000; assert(clip_pileup(h,512,20000)==4931);
    memset(h,0,65536*sizeof(*h));
    for(int i=600;i<3000;i++) h[i]=20;
    assert(clip_pileup(h,512,48000)==0); free(h);
}
static void dispose(clip_t *c) {
    if(c->fds) {for(int i=0;i<c->nfiles;i++) if(c->fds[i]>=0) close(c->fds[i]);free(c->fds);}
    free(c->frames);free(c->audio);free(c->dng_hdr);
    free(c->badpix);pthread_mutex_destroy(&c->lock);
}
static void test_index(const char *dir) {
    char path[1024];snprintf(path,sizeof(path),"%s/fixture.MLV",dir);
    FILE *f=fopen(path,"wb");assert(f);
    mlv_file_hdr_t m={0};memcpy(m.fileMagic,"MLVI",4);m.blockSize=sizeof(m);
    m.videoClass=1;m.sourceFpsNom=25;m.sourceFpsDenom=1;m.videoFrameCount=3;
    fwrite(&m,sizeof(m),1,f);
    mlv_rawi_hdr_t r={0};memcpy(r.h.blockType,"RAWI",4);r.h.blockSize=sizeof(r);
    r.xRes=256;r.yRes=192;r.raw_info.width=256;r.raw_info.height=192;
    r.raw_info.bits_per_pixel=16;r.raw_info.pitch=512;r.raw_info.black_level=512;
    r.raw_info.white_level=2761;r.raw_info.frame_size=256*192*2;
    fwrite(&r,sizeof(r),1,f);
    uint16_t pixels[256*192];
    for(int j=0;j<3;j++) {
        mlv_vidf_hdr_t v={0};memcpy(v.h.blockType,"VIDF",4);v.h.blockSize=sizeof(v)+sizeof(pixels);
        v.h.timestamp=1000000+j*40000;v.frameNumber=j;
        for(int y=0;y<192;y++) for(int x=0;x<256;x++) pixels[y*256+x]=x>200?2950:700+x*5;
        fwrite(&v,sizeof(v),1,f);fwrite(pixels,sizeof(pixels),1,f);
    }fclose(f);
    char *paths[]={path};
    for(int pass=0;pass<3;pass++) {
        memset(&g_opt,0,sizeof(g_opt));g_opt.cache_dir=(char*)dir;
        if(pass==2) g_opt.white_override=3100;
        clip_t c={0};pthread_mutex_init(&c.lock,NULL);c.paths=paths;c.nfiles=1;c.fds=malloc(sizeof(int));c.fds[0]=-1;
        strcpy(c.base,"fixture");strcpy(c.dirname,"fixture");
        assert(clip_index(&c)==0);assert(c.nframes==3);
        assert(c.white==(pass==2?3100:2949));
        assert(c.dng_hdr_size>0);
        assert(clip_load_frame_raw(&c,1,pixels)==0);assert(pixels[255]==2950);
        dispose(&c);
    }
}

static void clear_selection(void) {
    for(size_t i=0;i<g_opt.nbadpix_files;i++) free(g_opt.badpix_files[i]);
    free(g_opt.badpix_files);g_opt.badpix_files=NULL;g_opt.nbadpix_files=0;g_opt.badpix=0;
}
static void test_per_file(const char *dir) {
    /* Two genuine lossless MLVs, same basename, different directories. */
    char folders[2][1024],paths[2][1200],list[1200];
    unsigned char jpeg[2200]={0}; size_t z=0;
    unsigned char head[]={0xff,0xd8,0xff,0xc4,0,20,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                         0xff,0xc3,0,11,14,0,128,0,128,1,1,0x11,0,
                         0xff,0xda,0,8,1,1,0,1,0,0};
    memcpy(jpeg,head,sizeof(head));z=sizeof(head)+128*128/8;jpeg[z++]=0xff;jpeg[z++]=0xd9;
    uint16_t samples[128*128];assert(lj92_decode(jpeg,z,samples,128*128)==0);
    assert(samples[0]==8192 && samples[128*128-1]==8192);
    for(int k=0;k<2;k++) {
        snprintf(folders[k],sizeof(folders[k]),"%s/folder %d",dir,k);assert(mkdir(folders[k],0700)==0);
        snprintf(paths[k],sizeof(paths[k]),"%s/same clip.MLV",folders[k]);
        FILE*f=fopen(paths[k],"wb");assert(f);
        mlv_file_hdr_t m={0};memcpy(m.fileMagic,"MLVI",4);m.blockSize=sizeof(m);
        m.videoClass=1|MLV_VIDEO_CLASS_FLAG_LJ92;m.sourceFpsNom=25;m.sourceFpsDenom=1;m.videoFrameCount=1;
        fwrite(&m,sizeof(m),1,f);
        mlv_rawi_hdr_t r={0};memcpy(r.h.blockType,"RAWI",4);r.h.blockSize=sizeof(r);
        r.xRes=128;r.yRes=128;r.raw_info.bits_per_pixel=14;r.raw_info.black_level=512;r.raw_info.white_level=16383;
        fwrite(&r,sizeof(r),1,f);
        mlv_vidf_hdr_t v={0};memcpy(v.h.blockType,"VIDF",4);v.h.blockSize=sizeof(v)+z;
        fwrite(&v,sizeof(v),1,f);fwrite(jpeg,z,1,f);fclose(f);
    }
    snprintf(list,sizeof(list),"%s/selection.list",dir);
    FILE*f=fopen(list,"wb");assert(f);fwrite(paths[1],strlen(paths[1])+1,1,f);fclose(f);
    memset(&g_opt,0,sizeof(g_opt));g_opt.fastpass=1;g_opt.cache_dir=(char*)dir;
    assert(badpix_load_list(list)==0 && g_opt.nbadpix_files==1);
    for(int pass=0;pass<3;pass++) for(int k=0;k<2;k++) {
        /* Change settings on cache-backed remounts, including global correction. */
        if(pass==1) clear_selection();
        if(pass==2) g_opt.badpix=1;
        clip_t c={0};pthread_mutex_init(&c.lock,NULL);char*p[]={paths[k]};c.paths=p;c.nfiles=1;
        c.fds=malloc(sizeof(int));c.fds[0]=-1;strcpy(c.base,"same clip");strcpy(c.dirname,"same clip");
        assert(clip_index(&c)==0);
        int enabled=pass==2 || (pass==0 && k==1);
        assert(c.badpix_enabled==enabled);assert(c.fastpass==!enabled);
        assert(needs_processing(&c)==enabled);
        assert(c.proc_ready==enabled);
        /* A different global correction must still decode an unselected clip. */
        g_opt.chroma=2;assert(needs_processing(&c));g_opt.chroma=0;
        dispose(&c);
    }
    clear_selection();
    /* Real hot-pixel mapping/correction in a selected uncompressed clip. */
    char hotpath[1200];snprintf(hotpath,sizeof(hotpath),"%s/hot.MLV",dir);
    f=fopen(hotpath,"wb");assert(f);
    mlv_file_hdr_t m={0};memcpy(m.fileMagic,"MLVI",4);m.blockSize=sizeof(m);m.videoClass=1;
    m.sourceFpsNom=25;m.sourceFpsDenom=1;m.videoFrameCount=3;fwrite(&m,sizeof(m),1,f);
    mlv_rawi_hdr_t r={0};memcpy(r.h.blockType,"RAWI",4);r.h.blockSize=sizeof(r);
    r.xRes=128;r.yRes=128;r.raw_info.bits_per_pixel=16;r.raw_info.black_level=512;r.raw_info.white_level=65535;
    fwrite(&r,sizeof(r),1,f);
    for(int j=0;j<3;j++) {
        for(int i=0;i<128*128;i++) samples[i]=1000;
        samples[64*128+64]=60000;
        mlv_vidf_hdr_t v={0};memcpy(v.h.blockType,"VIDF",4);v.h.blockSize=sizeof(v)+sizeof(samples);v.frameNumber=j;
        fwrite(&v,sizeof(v),1,f);fwrite(samples,sizeof(samples),1,f);
    } fclose(f);
    for(int enabled=0;enabled<=1;enabled++) {
        if(enabled) {f=fopen(list,"wb");fwrite(hotpath,strlen(hotpath)+1,1,f);fclose(f);assert(!badpix_load_list(list));}
        clip_t c={0};pthread_mutex_init(&c.lock,NULL);char*p[]={hotpath};c.paths=p;c.nfiles=1;
        c.fds=malloc(sizeof(int));c.fds[0]=-1;strcpy(c.base,"hot");strcpy(c.dirname,"hot");
        assert(!clip_index(&c));assert(!clip_load_frame_raw(&c,0,samples));
        process_frame(&c,samples);
        assert(samples[64*128+64]==(enabled?1000:60000));
        assert(c.nbadpix==(unsigned)enabled);dispose(&c);
    }
    clear_selection();
    /* A broken selection list must fail rather than silently select everything. */
    f=fopen(list,"wb");fputs("unterminated",f);fclose(f);assert(badpix_load_list(list)<0);
    puts("PASS: per-file correction, duplicate basenames, selected hot-pixel repair, mixed lossless Fast Pass, cache-backed setting changes and invalid lists");
}
int main(int argc,char**argv) {
    assert(argc==2);test_hist();test_edges();test_dual();test_index(argv[1]);test_per_file(argv[1]);
    puts("PASS: clipping, diagonal interpolation, both ISO groups, all phases, Preview/Full, normal frames, real index/cache/override and DNG generation");
    return 0;
}
