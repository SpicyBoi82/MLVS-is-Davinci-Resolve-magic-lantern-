#!/usr/bin/env bash
# Removes MLV Resolve FS for the current user. Your MLV files are never touched.
set -u
MP="$(cat "$HOME/.config/mlvresolvefs/mountpoint" 2>/dev/null || echo "$HOME/MLV_Resolve")"
grep -q " $MP fuse.mlvresolvefs" /proc/mounts && fusermount3 -uz "$MP"
rm -rf "$HOME/.local/share/mlvresolvefs" "$HOME/.local/state/mlvresolvefs"
rm -f "$HOME/.local/bin/mlvresolvefs" "$HOME/.local/bin/mlvresolvefs-gui" \
      "$HOME/.local/share/applications/mlvresolvefs.desktop"
rm -f "$HOME/.local/share/DaVinciResolve/Fusion/Scripts/Utility/MLV Resolve FS - "*.lua
rm -f "${XDG_CONFIG_HOME:-$HOME/.config}/autostart/mlvresolvefs.desktop"
echo "Removed. Settings kept in ~/.config/mlvresolvefs (delete it if you like)."
