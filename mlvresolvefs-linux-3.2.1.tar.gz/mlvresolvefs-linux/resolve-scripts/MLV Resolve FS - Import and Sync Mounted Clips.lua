-- MLV Resolve FS (Linux): import every mounted MLV clip into a "MLV Resolve FS" bin
-- and link each clip's WAV by timecode. Run from Workspace > Scripts inside Resolve.

local resolve = resolve or (Resolve and Resolve()) or bmd.scriptapp("Resolve")
if not resolve then print("MLV Resolve FS: could not reach Resolve") return end

local function read_mountpoint()
    local home = os.getenv("HOME") or ""
    local cfg = os.getenv("XDG_CONFIG_HOME") or (home .. "/.config")
    local f = io.open(cfg .. "/mlvresolvefs/mountpoint", "r")
    if f then
        local p = f:read("*l"); f:close()
        if p and #p > 0 then return p end
    end
    return home .. "/MLV_Resolve"
end

local function basename(p) return (p:gsub("/+$", ""):match("([^/]+)$")) or p end

local pm = resolve:GetProjectManager()
local project = pm and pm:GetCurrentProject()
if not project then print("MLV Resolve FS: open a project first") return end
local pool = project:GetMediaPool()
local storage = resolve:GetMediaStorage()

local mount = read_mountpoint()
local dirs = storage:GetSubFolderList(mount) or {}
if #dirs == 0 then
    print("MLV Resolve FS: nothing mounted at " .. mount .. " - mount your MLV folder in the MLV Resolve FS app first")
    return
end

-- find or create the bin
local root = pool:GetRootFolder()
local bin = nil
for _, sub in ipairs(root:GetSubFolderList() or {}) do
    if sub:GetName() == "MLV Resolve FS" then bin = sub break end
end
if not bin then bin = pool:AddSubFolder(root, "MLV Resolve FS") end
pool:SetCurrentFolder(bin)

local existing = {}
for _, clip in ipairs(bin:GetClipList() or {}) do
    local fp = clip:GetClipProperty("File Path") or ""
    existing[fp:match("^(.*)/[^/]*$") or fp] = true
end

local imported, linked, skipped, failed = 0, 0, 0, 0
for _, dir in ipairs(dirs) do
    local name = basename(dir)
    if existing[dir] then
        skipped = skipped + 1
    else
        local items = storage:AddItemListToMediaPool({ dir }) or {}
        if #items == 0 then
            print("MLV Resolve FS: could not import " .. name)
        else
            imported = imported + 1
            local video, audio = {}, {}
            for _, it in ipairs(items) do
                local fp = (it:GetClipProperty("File Path") or ""):lower()
                if fp:match("%.wav$") then table.insert(audio, it) else table.insert(video, it) end
            end
            if #video > 0 and #audio > 0 then
                local ok, res = pcall(function()
                    local items2 = {}
                    for _, v in ipairs(video) do table.insert(items2, v) end
                    for _, a in ipairs(audio) do table.insert(items2, a) end
                    return pool:AutoSyncAudio(items2, {
                        [resolve.AUDIO_SYNC_MODE] = resolve.AUDIO_SYNC_TIMECODE,
                        [resolve.AUDIO_SYNC_RETAIN_EMBEDDED_AUDIO] = false,
                        [resolve.AUDIO_SYNC_RETAIN_VIDEO_METADATA] = false,
                    })
                end)
                if ok and res then linked = linked + 1 else failed = failed + 1 end
            end
        end
    end
end

print(string.format("MLV Resolve FS: %d clip(s) imported, %d audio linked, %d already in the bin", imported, linked, skipped))
if failed > 0 then
    print("MLV Resolve FS: automatic audio sync is not available in this Resolve version for " .. failed ..
          " clip(s). Select the clip and its WAV in the bin, right-click > Auto Sync Audio > Based on Timecode.")
end
