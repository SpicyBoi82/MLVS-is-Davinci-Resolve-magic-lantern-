-- MLV Resolve FS (Linux): link MLV WAV files to their CinemaDNG clips by timecode,
-- for every clip in the current Media Pool bin. Run from Workspace > Scripts.

local resolve = resolve or (Resolve and Resolve()) or bmd.scriptapp("Resolve")
if not resolve then print("MLV Resolve FS: could not reach Resolve") return end
local project = resolve:GetProjectManager():GetCurrentProject()
if not project then print("MLV Resolve FS: open a project first") return end
local pool = project:GetMediaPool()
local folder = pool:GetCurrentFolder()

-- pair each WAV with the video clip from the same folder
local by_dir = {}
for _, clip in ipairs(folder:GetClipList() or {}) do
    local fp = clip:GetClipProperty("File Path") or ""
    local dir = fp:match("^(.*)/[^/]*$") or fp
    by_dir[dir] = by_dir[dir] or { video = {}, audio = {} }
    if fp:lower():match("%.wav$") then table.insert(by_dir[dir].audio, clip)
    else table.insert(by_dir[dir].video, clip) end
end

local done, failed = 0, 0
for dir, g in pairs(by_dir) do
    if #g.video > 0 and #g.audio > 0 then
        local items = {}
        for _, v in ipairs(g.video) do table.insert(items, v) end
        for _, a in ipairs(g.audio) do table.insert(items, a) end
        local ok, res = pcall(function()
            return pool:AutoSyncAudio(items, {
                [resolve.AUDIO_SYNC_MODE] = resolve.AUDIO_SYNC_TIMECODE,
                [resolve.AUDIO_SYNC_RETAIN_EMBEDDED_AUDIO] = false,
                [resolve.AUDIO_SYNC_RETAIN_VIDEO_METADATA] = false,
            })
        end)
        if ok and res then done = done + 1 else failed = failed + 1 end
    end
end
print(string.format("MLV Resolve FS: audio linked for %d clip(s)", done))
if failed > 0 then
    print("MLV Resolve FS: " .. failed .. " clip(s) need manual sync: select clip + WAV, right-click > Auto Sync Audio > Based on Timecode")
end
