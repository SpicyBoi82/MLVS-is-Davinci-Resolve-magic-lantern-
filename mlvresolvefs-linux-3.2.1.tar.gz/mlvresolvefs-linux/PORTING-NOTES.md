# Linux 3.2.1 port notes

Inputs: MLVResolveFS-v3.2.zip and mlvresolvefs-linux-1.2.1.tar.gz.

## Feature mapping

| Windows feature | Linux implementation |
|---|---|
| 3.2 edge-directed Dual ISO merge | Windows 3.2 Dual ISO algorithm retained unchanged; per-clip bad-pixel routing added |
| 2/4-row groups; per-frame phase classification | Same processing source and expanded `diso_params_t` |
| Clipping pile-up and corrected white level | Windows `clip_pileup`/`detect_levels` merged into Linux indexer |
| Startup mount | GTK checkbox and per-user XDG autostart entry |
| Responsive 90-second mount wait | Detached foreground backend; GTK timer polls without blocking or killing it |
| Keep mount after closing window | Detached process/session, output to files, existing keep-mounted choice |
| Show Log | Full log opened externally as well as live embedded log |
| Simple names | Existing `--plain-naming`, available by unticking Resolve naming |
| Fast Pass / DNG / WAV / timecode / prefetch | Already present; dng.c, wav.c, lj92.c, mlv.h and Makefile identical in inputs |
| Windows drive letters, elevation/UAC, WinFsp | Native folder mount, normal-user check, FUSE3 and Linux installer |

The Windows main.c is not copied over the Linux version: doing that would remove
Linux background indexing/cache and restore read-only open failures in Resolve.
Likewise Linux index.c retains LJ92 offset recovery, diagnostic throttling,
uncompressed fallback, and persistent cache. Cache magic changes MRFSIDX3 → MRFSIDX4
so the first new mount computes levels using the new algorithm. Overrides are
applied after caching automatic values, keeping cache entries independent of settings.

## Checks

* Complete backend compiled and linked against libfuse3 on Ubuntu 24.04 x86-64.
* Backend `--help` smoke test reports 3.2.0-linux and retains Linux options.
* Production index/processing test harness: both group widths, all cyclic phases,
  Preview/Full, clipped frames, non-dual frames, same-colour diagonal choice,
  clipping histogram above/below RAWI, no-pile histogram, generated MLV ingestion,
  cache reuse, manual white override and DNG header creation.
* AddressSanitizer and UndefinedBehaviorSanitizer passed the C tests;
  LeakSanitizer disabled because the container prevents its process inspection.
* Nine headless Python behavioural tests and Python/shell syntax checks.
* Real GTK window opened under Xvfb; options, login-mount toggle and saved settings
  verified. Optional repeat: `python3 tests/test_gtk.py` in a graphical desktop.

No real MLV footage was supplied with these archives. No FUSE device or Resolve is
available here, so mounted playback, audio sync in Resolve, real-footage performance,
and real-footage image quality are not claimed as tested. Windows release notes'
percentage quality improvements have not been independently reproduced.

## Quick acceptance test on your PC

1. Close Resolve; unmount and close the old app; install the new package.
2. Mount a normal clip with processing off and check picture/audio in Resolve.
3. Remount known 2-row and 4-row Dual ISO clips with Full processing; inspect the
   log for group width, ratio and detected clipping. Check skies and diagonal detail.
4. Close the app, choosing Yes to keep mounted; confirm media remains online.
5. Reopen, unmount/remount; confirm the log reports index cache reuse.
6. Enable login mounting, close the app to save, and check it after next login.
   A disconnected source is skipped after 90 seconds, not silently remounted elsewhere.

## 3.2.1 per-file update

`badpix_enabled` is computed for each clip before index/cache use. Fast Pass eligibility,
processing preparation and frame correction all consult that per-clip value. Index
cache contents do not contain processing choices, so changing selections works with
existing cached indexes. CLI selection lists are loaded once before workers start;
matching uses canonical source paths, never basenames. The all-clips flag remains
backwards compatible. No other processing algorithm or strength is changed.

Additional tests passed:

* Genuine synthetic LJ92 MLVs with identical basenames in separate folders: selected
  clip decodes; unselected clip stays Fast Pass. Repeat with cached indexes and changed
  selections, then enable global correction.
* A synthetic persistent hot pixel remains unchanged when unselected and is detected
  and repaired to its neighbours' value when selected.
* Malformed selection list rejection; NUL list serialization including spaces, accents
  and newlines; scanner depth and folder boundaries; per-file launcher arguments.
* Real GTK modal picker: folder tick, individual override, accepted selection, saved
  list and settings reload. Address/undefined-behaviour sanitizers pass C tests
  (LeakSanitizer disabled for the same container restriction noted above).

The full backend was rebuilt for Ubuntu 24.04 x86-64. Real FUSE-mounted playback in
DaVinci Resolve remains untested here; test on your PC with a small sample first.
