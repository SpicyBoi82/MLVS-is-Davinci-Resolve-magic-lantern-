/* Optional raw corrections: vertical stripes, bad pixels, dual ISO, chroma smoothing. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "common.h"

/* The list is loaded once before any scan/worker starts. Exact canonical paths avoid
 * applying a correction to a different clip with the same basename. NUL separators
 * preserve spaces, tabs, newlines and non-ASCII filenames. */
int badpix_load_list(const char *path)
{
    FILE *f = fopen(path, "rb");
    if (!f) return -1;
    char *entry = NULL; size_t cap = 0; ssize_t n;
    while ((n = getdelim(&entry, &cap, '\0', f)) != -1) {
        if (n < 2 || entry[n - 1] != '\0') { free(entry); fclose(f); return -1; }
        char *canonical = realpath(entry, NULL);
        if (!canonical) {
            mrfs_log("selected bad-pixel clip unavailable, skipping: %s\n", entry);
            continue;
        }
        char **next = realloc(g_opt.badpix_files, (g_opt.nbadpix_files + 1) * sizeof(char *));
        if (!next) { free(canonical); free(entry); fclose(f); return -1; }
        g_opt.badpix_files = next;
        g_opt.badpix_files[g_opt.nbadpix_files++] = canonical;
    }
    int failed = ferror(f);
    free(entry); fclose(f);
    return failed ? -1 : 0;
}

int badpix_for_clip(const clip_t *c)
{
    if (g_opt.badpix) return 1;
    if (!g_opt.nbadpix_files || !c->nfiles || !c->paths) return 0;
    char *path = realpath(c->paths[0], NULL);
    if (!path) return 0;
    int enabled = 0;
    for (size_t i = 0; i < g_opt.nbadpix_files; i++)
        if (!strcmp(path, g_opt.badpix_files[i])) { enabled = 1; break; }
    free(path);
    return enabled;
}

int needs_processing(const clip_t *c)
{
    return c->badpix_enabled || g_opt.stripes || g_opt.chroma || g_opt.dualiso;
}

static inline int cfa_color(const clip_t *c, int y, int x)
{
    uint32_t pat = (uint32_t)c->rawi.raw_info.cfa_pattern;
    if (!pat) pat = 0x02010100;
    return (pat >> (8 * (((y & 1) << 1) | (x & 1)))) & 0xFF;   /* 0 R, 1 G, 2 B */
}

static int cmp_u16(const void *a, const void *b) { return *(const uint16_t *)a - *(const uint16_t *)b; }
static int cmp_f(const void *a, const void *b)
{
    float x = *(const float *)a, y = *(const float *)b;
    return x < y ? -1 : x > y;
}

/* ---------- vertical stripes (per column-mod-8 gain) ---------- */
static void stripes_detect(clip_t *c, const uint16_t *img)
{
    int W = c->width, H = c->height, blk = c->black;
    double range = c->white - blk;
    enum { NB = 2048 };
    uint32_t *hist = calloc(8 * NB, sizeof(uint32_t));
    uint32_t cnt[8] = {0};
    for (int y = 2; y < H - 2; y += 3) {
        const uint16_t *r = img + (size_t)y * W;
        for (int x = 2; x < W - 2; x++) {
            double p = r[x] - blk, a = r[x - 2] - blk, b = r[x + 2] - blk;
            if (p < range * 0.02 || p > range * 0.7 || a < range * 0.02 || b < range * 0.02) continue;
            if (fabs(a - b) > 0.04 * (a + b)) continue;
            double ratio = p / ((a + b) * 0.5);
            int bin = (int)((ratio - 0.9) / 0.2 * NB);
            if (bin < 0 || bin >= NB) continue;
            hist[(x & 7) * NB + bin]++;
            cnt[x & 7]++;
        }
    }
    double g[8];
    for (int j = 0; j < 8; j++) {
        g[j] = 1.0;
        if (cnt[j] < 1000) continue;
        uint32_t half = cnt[j] / 2, acc = 0;
        for (int b = 0; b < NB; b++) {
            acc += hist[j * NB + b];
            if (acc >= half) { g[j] = 0.9 + (b + 0.5) / NB * 0.2; break; }
        }
    }
    free(hist);
    /* ratios are relative to neighbours; turn them into gains around 1 per colour column parity */
    int on = 0;
    for (int par = 0; par < 2; par++) {
        double m = 0; for (int j = par; j < 8; j += 2) m += g[j]; m /= 4;
        for (int j = par; j < 8; j += 2) {
            c->stripe_gain[j] = (float)(m / g[j]);
            if (fabs(c->stripe_gain[j] - 1) > 0.002) on = 1;
        }
    }
    c->stripes_on = on;
    if (on)
        mrfs_log("%s: vertical stripe gains %.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f\n", c->base,
                 c->stripe_gain[0], c->stripe_gain[1], c->stripe_gain[2], c->stripe_gain[3],
                 c->stripe_gain[4], c->stripe_gain[5], c->stripe_gain[6], c->stripe_gain[7]);
}

static void stripes_apply(const clip_t *c, uint16_t *img)
{
    if (!c->stripes_on) return;
    int W = c->width, H = c->height, blk = c->black;
    for (int y = 0; y < H; y++) {
        uint16_t *r = img + (size_t)y * W;
        for (int x = 0; x < W; x++) {
            int v = r[x] - blk;
            if (v <= 0 || r[x] >= c->white) continue;
            int o = blk + (int)lrintf(v * c->stripe_gain[x & 7]);
            r[x] = (uint16_t)(o > 65535 ? 65535 : o);
        }
    }
}

/* ---------- bad pixels ---------- */
static void badpix_flags(const clip_t *c, const uint16_t *img, uint8_t *flag)
{
    int W = c->width, H = c->height;
    int T = (c->white - c->black) / 24; if (T < 48) T = 48;
    for (int y = 2; y < H - 2; y++) {
        for (int x = 2; x < W - 2; x++) {
            const uint16_t *p = img + (size_t)y * W + x;
            int v = *p;
            int nb[8] = { p[-2], p[2], p[-2 * W], p[2 * W], p[-2 * W - 2], p[-2 * W + 2], p[2 * W - 2], p[2 * W + 2] };
            int mx = nb[0], mn = nb[0];
            for (int k = 1; k < 8; k++) { if (nb[k] > mx) mx = nb[k]; if (nb[k] < mn) mn = nb[k]; }
            if (v > mx + T && (v - c->black) > 3 * (mx - c->black + 8)) flag[(size_t)y * W + x]++;
            else if (v < mn - T && (mn - c->black) > 3 * (v - c->black + 8)) flag[(size_t)y * W + x]++;
        }
    }
}

static void badpix_apply(const clip_t *c, uint16_t *img)
{
    int W = c->width;
    for (uint32_t i = 0; i < c->nbadpix; i++) {
        uint32_t k = c->badpix[i];
        uint16_t n[4] = { img[k - 2], img[k + 2], img[k - 2 * W], img[k + 2 * W] };
        qsort(n, 4, sizeof(uint16_t), cmp_u16);
        img[k] = (uint16_t)((n[1] + n[2] + 1) / 2);
    }
}

/* ---------- dual ISO ----------
 * v3.1: finds the row pattern instead of assuming it.
 *  - Groups of 2 rows (Canon's layout: one RG+GB pair per ISO, period 4) or 4 rows
 *    (CMOS[0] bit 11, period 8). Both are decided per frame, because the phase can move
 *    between frames (70D 23.976p timing) and a wrong phase turns the merge into stripes.
 *  - Every row is filled from the nearest same-colour rows of the other ISO above and
 *    below (distance 2 for pairs, 2..6 for groups of 4), weighted by distance.
 *  - The real clipping point is measured: 70D LV raw clips well below the white level ML
 *    writes (e.g. 4932 vs 5586), and clipped bright rows read as valid data -> pink
 *    highlights. */

/* mean signal per row phase (y % 8), central area, clipped pixels left out */
static void phase_means8(const clip_t *c, const uint16_t *img, int clip, double m[8])
{
    int W = c->width, H = c->height, blk = c->black;
    double sum[8] = {0}; long n[8] = {0};
    int x0 = W / 8, x1 = W - W / 8;
    for (int y = H / 8; y < H - H / 8; y++) {
        const uint16_t *r = img + (size_t)y * W;
        for (int x = x0; x < x1; x += 3) {
            int v = r[x];
            if (v >= clip) continue;
            sum[y & 7] += v - blk; n[y & 7]++;
        }
    }
    for (int k = 0; k < 8; k++) m[k] = n[k] ? sum[k] / n[k] : 0;
}

/* bright[8] from phase means: within each colour (row parity) two of the four phases must
 * be clearly brighter. Returns rows per group (2 or 4), 0 if no dual ISO pattern. */
static int classify8(const double m[8], int bright[8], double *contrast)
{
    double worst = 1e9;
    for (int par = 0; par < 2; par++) {
        double v[4]; int k;
        for (k = 0; k < 4; k++) v[k] = m[par + 2 * k];
        double mx = v[0], mn = v[0];
        for (k = 1; k < 4; k++) { if (v[k] > mx) mx = v[k]; if (v[k] < mn) mn = v[k]; }
        if (mn <= 0) mn = 1e-3;
        if (mx <= 0) return 0;
        double thr = sqrt(mx * mn);
        int nb = 0;
        double lo_hi = 1e9, hi_lo = 0;   /* darkest bright phase, brightest dark phase */
        for (k = 0; k < 4; k++) {
            int b = v[k] > thr;
            bright[par + 2 * k] = b;
            nb += b;
            if (b && v[k] < lo_hi) lo_hi = v[k];
            if (!b && v[k] > hi_lo) hi_lo = v[k];
        }
        if (nb != 2 || hi_lo <= 0) return 0;
        double ct = lo_hi / hi_lo;
        if (ct < worst) worst = ct;
    }
    *contrast = worst;
    if (worst < 1.4) return 0;
    /* period 4 (pairs): bright[k] == bright[k + 4]; period 8: four in a row */
    int p4 = 1;
    for (int k = 0; k < 4; k++) if (bright[k] != bright[k + 4]) p4 = 0;
    if (p4) return 2;
    int runs = 0;
    for (int k = 0; k < 8; k++) if (bright[k] != bright[(k + 7) & 7]) runs++;
    return runs == 2 ? 4 : 0;
}

/* nearest same-colour row of the other ISO above (-1 if none) and below */
static void other_rows(const int bright[8], int H, int y, int *up, int *dn)
{
    int b = bright[y & 7];
    *up = *dn = -1;
    for (int d = 2; d <= 8; d += 2) {
        if (*up < 0 && y - d >= 0 && bright[(y - d) & 7] != b) *up = y - d;
        if (*dn < 0 && y + d < H && bright[(y + d) & 7] != b) *dn = y + d;
    }
}

/* real clipping point: measured once per clip in index.c (detect_levels / clip_pileup) and
 * stored as c->white; everything at or above it is clipped. */
static int find_clip(const clip_t *c)
{
    return c->white;
}

static void dual_detect(clip_t *c, const uint16_t *img)
{
    int W = c->width, H = c->height, blk = c->black;
    double m[8], contrast = 0;
    c->dual.enabled = 0;
    phase_means8(c, img, c->white - 1, m);
    int group = classify8(m, c->dual.bright, &contrast);
    if (!group) {
        mrfs_log("%s: dual ISO requested but no interlaced ISO pattern found "
                 "(row means %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f); leaving frames as recorded\n",
                 c->base, m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7]);
        return;
    }
    c->dual.group = group;
    c->dual.clip = find_clip(c);
    double range = c->dual.clip - blk;

    /* exposure ratio: bright pixel / interpolated same-colour dark pixel */
    size_t cap = 400000, cntv = 0;
    float *r = malloc(cap * sizeof(float));
    if (!r) return;
    for (int y = 8; y < H - 8 && cntv < cap; y++) {
        if (!c->dual.bright[y & 7]) continue;
        int up, dn;
        other_rows(c->dual.bright, H, y, &up, &dn);
        if (up < 0 || dn < 0) continue;
        double wu = (double)(dn - y) / (dn - up), wd = 1 - wu;
        for (int x = 0; x < W && cntv < cap; x += 3) {
            double b = img[(size_t)y * W + x] - blk;
            double d = wu * img[(size_t)up * W + x] + wd * img[(size_t)dn * W + x] - blk;
            if (b < range * 0.05 || b > range * 0.8 || d < range * 0.01) continue;
            r[cntv++] = (float)(b / d);
        }
    }
    if (cntv < 1000) {
        free(r);
        mrfs_log("%s: dual ISO pattern found but too little usable detail to measure the ratio\n", c->base);
        return;
    }
    qsort(r, cntv, sizeof(float), cmp_f);
    c->dual.ratio = r[cntv / 2];
    free(r);
    if (c->dual.ratio < 1.2) return;
    c->dual.enabled = 1;
    double R = range * c->dual.ratio;
    double S = (65535.0 - blk - 1) / R;
    if (S > 1) S = 1;
    c->out_black = blk;
    c->out_white = blk + (int)floor(R * S);
    mrfs_log("%s: dual ISO detected, %d-row groups, ratio %.2f (%.2f EV), data clips at %d (white %d), output white %d\n",
             c->base, group, c->dual.ratio, log2(c->dual.ratio), c->dual.clip, c->white, c->out_white);
}

static inline float smooth01(float t) { if (t <= 0) return 0; if (t >= 1) return 1; return t * t * (3 - 2 * t); }

/* v3.2: edge-directed fill. The missing exposure of a row is rebuilt from the nearest
 * same-colour rows of the other ISO above (distance du) and below (dd). A plain vertical
 * average turns diagonal edges (zips, hair, leaves) into stair steps, so try five directions
 * (slope -1..1 pixel per row, offsets rounded to even columns to stay on the same colour)
 * and use the one along which the two rows agree best. A diagonal must clearly beat the
 * vertical (score < 0.7x), so flat or noisy areas stay vertical. */
static inline int even_round(float v) { return 2 * (int)lrintf(v * 0.5f); }

static inline void edge_pick(const uint16_t *u, const uint16_t *d, int x, int W, int du, int dd,
                             int *xu_out, int *xd_out)
{
    static const float slopes[5] = { 0.0f, -0.5f, 0.5f, -1.0f, 1.0f };
    int bx_u = x, bx_d = x;
    float best = 0, vert = 0;
    for (int k = 0; k < 5; k++) {
        int xu = x - even_round(slopes[k] * du), xd = x + even_round(slopes[k] * dd);
        if (xu < 2 || xd < 2 || xu >= W - 2 || xd >= W - 2) continue;
        float sc = fabsf((float)u[xu - 2] - d[xd - 2]) + 2.0f * fabsf((float)u[xu] - d[xd])
                 + fabsf((float)u[xu + 2] - d[xd + 2]);
        if (k == 0) { vert = best = sc; continue; }
        if (sc < best && sc < 0.7f * vert) { best = sc; bx_u = xu; bx_d = xd; }
    }
    *xu_out = bx_u; *xd_out = bx_d;
}

static void dual_apply(const clip_t *c, uint16_t *img)
{
    if (!c->dual.enabled) return;
    int W = c->width, H = c->height, blk = c->black;
    int clip = c->dual.clip;
    float range = (float)(clip - blk), ratio = (float)c->dual.ratio;
    float S = (float)(c->out_white - blk) / (range * ratio);

    /* this frame's pattern (the phase may differ from the frame used for detection) */
    int bright[8];
    double m[8], contrast = 0;
    phase_means8(c, img, clip, m);
    if (!classify8(m, bright, &contrast))
        memcpy(bright, c->dual.bright, sizeof(bright));

    uint16_t *src = malloc((size_t)W * H * 2);
    if (!src) return;
    memcpy(src, img, (size_t)W * H * 2);
    int full = g_opt.dualiso >= 2;
    for (int y = 0; y < H; y++) {
        int isb = bright[y & 7];
        int up, dn;
        other_rows(bright, H, y, &up, &dn);
        if (up < 0) up = dn;
        if (dn < 0) dn = up;
        if (up < 0) { up = dn = y; }
        float wu = (dn == up) ? 0.5f : (float)(dn - y) / (dn - up), wd = 1 - wu;
        const uint16_t *r = src + (size_t)y * W, *u = src + (size_t)up * W, *d = src + (size_t)dn * W;
        uint16_t *o = img + (size_t)y * W;
        for (int x = 0; x < W; x++) {
            float own = (float)r[x] - blk;
            int xu = x, xd = x;
            if (up != dn) edge_pick(u, d, x, W, y - up, dn - y, &xu, &xd);
            float other = wu * u[xu] + wd * d[xd] - blk;
            int own_clipped = r[x] >= clip;
            int other_clipped = u[xu] >= clip || d[xd] >= clip;
            float v;
            if (isb) {
                float other_b = other * ratio;          /* interpolated dark rows in bright units */
                if (own_clipped) v = other_b;
                else if (!full) v = own >= range * 0.97f ? other_b : own;
                else {
                    float w = smooth01((own / range - 0.70f) / 0.25f);
                    v = (1 - w) * own + w * other_b;
                }
            } else {
                float own_b = own * ratio;
                if (!full || other_clipped) v = own_b;
                else {
                    float ws = 1 - smooth01((own / range - 0.02f) / 0.08f);   /* as v3.0 */
                    v = ws * other + (1 - ws) * own_b;
                }
            }
            if (v < 0) v = 0;
            int ov = blk + (int)lrintf(v * S);
            o[x] = (uint16_t)(ov > 65535 ? 65535 : ov);
        }
    }
    free(src);
}

/* ---------- chroma smoothing ---------- */
#define SW(a, b) do { if (v[a] > v[b]) { float t_ = v[a]; v[a] = v[b]; v[b] = t_; } } while (0)
static inline float med5(float *v)
{
    SW(0, 1); SW(3, 4); SW(0, 3); SW(1, 4); SW(1, 2); SW(2, 3); SW(1, 2);
    return v[2];
}
static inline float med9(float *v)
{
    SW(1, 2); SW(4, 5); SW(7, 8); SW(0, 1); SW(3, 4); SW(6, 7); SW(1, 2); SW(4, 5); SW(7, 8);
    SW(0, 3); SW(5, 8); SW(4, 7); SW(3, 6); SW(1, 4); SW(2, 5); SW(4, 7); SW(4, 2); SW(6, 4);
    SW(4, 2);
    return v[4];
}
#undef SW
static void chroma_apply(const clip_t *c, uint16_t *img)
{
    int W = c->width, H = c->height, blk = c->out_black;
    int radius = g_opt.chroma >= 3 ? 3 : 2;
    uint16_t *src = malloc((size_t)W * H * 2);
    memcpy(src, img, (size_t)W * H * 2);
    float *chroma = malloc((size_t)W * H * sizeof(float));
    for (int y = 1; y < H - 1; y++)
        for (int x = 1; x < W - 1; x++) {
            size_t k = (size_t)y * W + x;
            if (cfa_color(c, y, x) == 1) { chroma[k] = 0; continue; }
            float g = (src[k - 1] + src[k + 1] + src[k - W] + src[k + W]) * 0.25f;
            chroma[k] = (float)src[k] - g;
        }
    for (int y = 4; y < H - 4; y++)
        for (int x = 4; x < W - 4; x++) {
            if (cfa_color(c, y, x) == 1) continue;
            size_t k = (size_t)y * W + x;
            if (src[k] >= c->out_white) continue;
            float v[9]; int n = 0;
            if (radius == 2) {
                v[n++] = chroma[k];
                v[n++] = chroma[k - 2 * W - 2]; v[n++] = chroma[k - 2 * W + 2];
                v[n++] = chroma[k + 2 * W - 2]; v[n++] = chroma[k + 2 * W + 2];
            } else {
                for (int dy = -2; dy <= 2; dy += 2)
                    for (int dx = -2; dx <= 2; dx += 2) v[n++] = chroma[k + dy * W + dx];
            }
            float m = n == 5 ? med5(v) : med9(v);
            float g = (src[k - 1] + src[k + 1] + src[k - W] + src[k + W]) * 0.25f;
            int o = (int)lrintf(g + m);
            if (o < blk) o = blk;
            if (o > 65535) o = 65535;
            img[k] = (uint16_t)o;
        }
    free(src); free(chroma);
}

void process_prepare(clip_t *c)
{
    size_t n = (size_t)c->width * c->height;
    uint16_t *img = malloc(n * 2);
    if (!img) return;
    c->out_black = c->black;
    c->out_white = c->white;
    if (clip_load_frame_raw(c, c->nframes / 2, img) == 0) {
        if (g_opt.stripes) stripes_detect(c, img);
        if (g_opt.dualiso) { stripes_apply(c, img); dual_detect(c, img); }
    }
    if (c->badpix_enabled) {
        uint8_t *flag = calloc(n, 1);
        uint32_t picks[3] = {0, c->nframes / 2, c->nframes - 1};
        int used = 0;
        for (int k = 0; k < 3; k++) {
            if (k && picks[k] == picks[k - 1]) continue;
            if (clip_load_frame_raw(c, picks[k], img)) continue;
            badpix_flags(c, img, flag);
            used++;
        }
        uint32_t cap = 50000, cnt = 0;
        c->badpix = malloc(cap * sizeof(uint32_t));
        for (size_t i = 0; i < n && cnt < cap; i++)
            if (used && flag[i] == used) c->badpix[cnt++] = (uint32_t)i;
        c->nbadpix = cnt;
        free(flag);
        if (g_opt.verbose || cnt) mrfs_log("%s: %u bad pixels mapped\n", c->base, cnt);
    }
    free(img);
    c->proc_ready = 1;
}

void process_frame(clip_t *c, uint16_t *img)
{
    if (!c->proc_ready) return;
    if (g_opt.stripes) stripes_apply(c, img);
    if (c->badpix_enabled) badpix_apply(c, img);
    if (g_opt.dualiso) dual_apply(c, img);
    if (g_opt.chroma) chroma_apply(c, img);
}
