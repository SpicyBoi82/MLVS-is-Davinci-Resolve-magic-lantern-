/* Broadcast WAV (with bext timecode) generated from MLV AUDF blocks. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "common.h"

static void put32(uint8_t *p, uint32_t v) { memcpy(p, &v, 4); }
static void put16(uint8_t *p, uint16_t v) { memcpy(p, &v, 2); }

void wav_build_header(clip_t *c)
{
    c->wav_hdr_size = 0;
    if (!c->have_wavi || !c->naudio) return;
    uint8_t *h = c->wav_hdr;
    memset(h, 0, sizeof(c->wav_hdr));
    uint32_t fmt_size = 16, bext_size = 602;
    uint32_t align = c->audio_align ? c->audio_align : 4;   /* wav_data_bytes set by audio_align() */
    if (!c->wav_data_bytes) return;
    uint32_t hdr = 12 + 8 + fmt_size + 8 + bext_size + 8;
    if (hdr > sizeof(c->wav_hdr)) return;
    uint64_t riff = hdr - 8 + c->wav_data_bytes;
    if (riff > 0xFFFFFFFFull) riff = 0xFFFFFFFFull;

    memcpy(h, "RIFF", 4); put32(h + 4, (uint32_t)riff); memcpy(h + 8, "WAVE", 4);
    uint8_t *p = h + 12;
    memcpy(p, "fmt ", 4); put32(p + 4, fmt_size);
    put16(p + 8, 1);
    put16(p + 10, c->wavi.channels);
    put32(p + 12, c->wavi.samplingRate);
    put32(p + 16, c->wavi.bytesPerSecond);
    put16(p + 20, (uint16_t)align);
    put16(p + 22, c->wavi.bitsPerSample);
    p += 8 + fmt_size;

    memcpy(p, "bext", 4); put32(p + 4, bext_size);
    uint8_t *b = p + 8;
    snprintf((char *)b, 256, "%s", c->dirname);                 /* Description */
    snprintf((char *)b + 256, 32, "MLV Resolve FS");             /* Originator */
    snprintf((char *)b + 288, 32, "%s", c->base);                /* OriginatorReference */
    if (c->have_rtci) {
        char d[16], t[16];
        snprintf(d, sizeof(d), "%04d-%02d-%02d", c->rtci.tm_year + 1900, c->rtci.tm_mon + 1, c->rtci.tm_mday);
        snprintf(t, sizeof(t), "%02d:%02d:%02d", c->rtci.tm_hour, c->rtci.tm_min, c->rtci.tm_sec);
        memcpy(b + 320, d, 10);
        memcpy(b + 330, t, 8);
    }
    /* TimeReference: samples since midnight matching the DNG start timecode */
    uint64_t tref = (uint64_t)llround((double)c->tc_start_frames * c->wavi.samplingRate *
                                      c->fps_den / (double)c->fps_num);
    put32(b + 338, (uint32_t)(tref & 0xFFFFFFFF));
    put32(b + 342, (uint32_t)(tref >> 32));
    put16(b + 346, 1);                                           /* bext version */
    p += 8 + bext_size;

    memcpy(p, "data", 4);
    put32(p + 4, (uint32_t)(c->wav_data_bytes > 0xFFFFFFFFull ? 0xFFFFFFFFull : c->wav_data_bytes));
    c->wav_hdr_size = hdr;
}

uint64_t wav_file_size(const clip_t *c)
{
    return c->wav_hdr_size ? c->wav_hdr_size + c->wav_data_bytes : 0;
}

int wav_read(clip_t *c, char *buf, size_t size, uint64_t offset)
{
    uint64_t total = wav_file_size(c);
    if (offset >= total) return 0;
    if (offset + size > total) size = (size_t)(total - offset);
    size_t done = 0;
    if (offset < c->wav_hdr_size) {
        size_t n = c->wav_hdr_size - (size_t)offset;
        if (n > size) n = size;
        memcpy(buf, c->wav_hdr + offset, n);
        done = n;
    }
    while (done < size) {
        /* position in the recorded audio stream, after applying the start offset */
        int64_t s = (int64_t)(offset + done - c->wav_hdr_size) - c->audio_lead;
        if (s < 0) {                                   /* leading silence */
            uint64_t n = (uint64_t)(-s);
            if (n > size - done) n = size - done;
            memset(buf + done, 0, (size_t)n);
            done += (size_t)n;
            continue;
        }
        uint64_t v = (uint64_t)s;
        if (v >= c->audio_bytes) { memset(buf + done, 0, size - done); break; }   /* trailing silence */
        uint32_t lo = 0, hi = c->naudio;
        while (hi - lo > 1) {
            uint32_t mid = (lo + hi) / 2;
            if (c->audio[mid].vstart <= v) lo = mid; else hi = mid;
        }
        audio_ref_t *a = &c->audio[lo];
        uint64_t in = v - a->vstart;
        size_t n = a->size - (size_t)in;
        if (n > size - done) n = size - done;
        if (clip_read(c, a->file, a->off + in, buf + done, n)) memset(buf + done, 0, n);
        done += n;
    }
    return (int)size;
}
