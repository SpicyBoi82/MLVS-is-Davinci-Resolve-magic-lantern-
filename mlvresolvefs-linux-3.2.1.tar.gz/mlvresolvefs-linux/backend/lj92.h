#ifndef LJ92_H
#define LJ92_H
#include <stdint.h>
#include <stddef.h>
typedef struct { int precision, width, height, components; } lj92_info_t;
/* Reads the SOF3 header. Returns 0 on success. */
int lj92_probe(const uint8_t *data, size_t len, lj92_info_t *info);
/* Decodes into out (row-major, width*components samples per line). out_samples must
 * equal width*components*height. Returns 0 on success. */
int lj92_decode(const uint8_t *data, size_t len, uint16_t *out, size_t out_samples);
#endif
