/* MLV block structures (Magic Lantern Video format), little-endian, packed. */
#ifndef MLV_H
#define MLV_H
#include <stdint.h>

#pragma pack(push, 1)

typedef struct {
    uint8_t  blockType[4];
    uint32_t blockSize;
    uint64_t timestamp;
} mlv_hdr_t;

typedef struct {
    uint8_t  fileMagic[4];      /* "MLVI" */
    uint32_t blockSize;
    uint8_t  versionString[8];
    uint64_t fileGuid;
    uint16_t fileNum;
    uint16_t fileCount;
    uint32_t fileFlags;
    uint16_t videoClass;
    uint16_t audioClass;
    uint32_t videoFrameCount;
    uint32_t audioFrameCount;
    uint32_t sourceFpsNom;
    uint32_t sourceFpsDenom;
} mlv_file_hdr_t;

#define MLV_VIDEO_CLASS_RAW          0x01
#define MLV_VIDEO_CLASS_FLAG_LZMA    0x80
#define MLV_VIDEO_CLASS_FLAG_DELTA   0x40
#define MLV_VIDEO_CLASS_FLAG_LJ92    0x20

typedef struct {
    int32_t  api_version;
    uint32_t buffer;
    int32_t  height, width, pitch;
    int32_t  frame_size;
    int32_t  bits_per_pixel;
    int32_t  black_level;
    int32_t  white_level;
    int32_t  jpeg_x, jpeg_y, jpeg_w, jpeg_h;
    int32_t  active_y1, active_x1, active_y2, active_x2;
    int32_t  exposure_bias[2];
    int32_t  cfa_pattern;
    int32_t  calibration_illuminant1;
    int32_t  color_matrix1[18];
    int32_t  dynamic_range;
} raw_info_t;

typedef struct {
    mlv_hdr_t h;
    uint16_t xRes, yRes;
    raw_info_t raw_info;
} mlv_rawi_hdr_t;

typedef struct {
    mlv_hdr_t h;
    uint16_t sensor_res_x, sensor_res_y;
    uint16_t sensor_crop;           /* crop factor x100 */
    uint16_t reserved;
    uint8_t  binning_x, skipping_x, binning_y, skipping_y;
    int16_t  offset_x, offset_y;
} mlv_rawc_hdr_t;

typedef struct {
    mlv_hdr_t h;
    uint32_t frameNumber;
    uint16_t cropPosX, cropPosY, panPosX, panPosY;
    uint32_t frameSpace;
} mlv_vidf_hdr_t;

typedef struct {
    mlv_hdr_t h;
    uint32_t frameNumber;
    uint32_t frameSpace;
} mlv_audf_hdr_t;

typedef struct {
    mlv_hdr_t h;
    uint16_t format, channels;
    uint32_t samplingRate, bytesPerSecond;
    uint16_t blockAlign, bitsPerSample;
} mlv_wavi_hdr_t;

typedef struct {
    mlv_hdr_t h;
    uint32_t isoMode, isoValue, isoAnalog, digitalGain;
    uint64_t shutterValue;          /* microseconds */
} mlv_expo_hdr_t;

typedef struct {
    mlv_hdr_t h;
    uint16_t focalLength, focalDist, aperture;
    uint8_t  stabilizerMode, autofocusMode;
    uint32_t flags, lensID;
    uint8_t  lensName[32];
    uint8_t  lensSerial[32];
} mlv_lens_hdr_t;

typedef struct {
    mlv_hdr_t h;
    uint16_t tm_sec, tm_min, tm_hour, tm_mday, tm_mon, tm_year;
    uint16_t tm_wday, tm_yday, tm_isdst, tm_gmtoff;
    uint8_t  tm_zone[8];
} mlv_rtci_hdr_t;

typedef struct {
    mlv_hdr_t h;
    uint8_t  cameraName[32];
    uint32_t cameraModel;
    uint8_t  cameraSerial[32];
} mlv_idnt_hdr_t;

typedef struct {
    mlv_hdr_t h;
    uint32_t wb_mode, kelvin, wbgain_r, wbgain_g, wbgain_b, wbs_gm, wbs_ba;
} mlv_wbal_hdr_t;

typedef struct {
    mlv_hdr_t h;
    uint32_t dualMode, isoValue;
} mlv_diso_hdr_t;

#pragma pack(pop)

#endif
