/* CinemaDNG header generation. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "common.h"

enum { T_BYTE = 1, T_ASCII = 2, T_SHORT = 3, T_LONG = 4, T_RATIONAL = 5, T_UNDEF = 7, T_SRATIONAL = 10 };

typedef struct {
    uint16_t tag, type;
    uint32_t count;
    uint8_t  data[256];
    uint32_t len;
    int      mark;          /* 1 = timecode, 2 = strip byte count, 3 = exif pointer, 4 = strip offset */
} ent_t;

typedef struct { ent_t e[64]; int n; } ifd_t;

static const int type_size[] = {0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8};

static ent_t *add(ifd_t *d, uint16_t tag, uint16_t type, uint32_t count, const void *data)
{
    ent_t *e = &d->e[d->n++];
    memset(e, 0, sizeof(*e));
    e->tag = tag; e->type = type; e->count = count;
    e->len = count * type_size[type];
    if (e->len > sizeof(e->data)) e->len = sizeof(e->data);
    if (data) memcpy(e->data, data, e->len);
    return e;
}
static void add_short(ifd_t *d, uint16_t tag, uint16_t v) { add(d, tag, T_SHORT, 1, &v); }
static void add_long(ifd_t *d, uint16_t tag, uint32_t v) { add(d, tag, T_LONG, 1, &v); }
static void add_ascii(ifd_t *d, uint16_t tag, const char *s)
{
    char buf[250]; snprintf(buf, sizeof(buf), "%s", s);
    add(d, tag, T_ASCII, (uint32_t)strlen(buf) + 1, buf);
}
static void add_rat(ifd_t *d, uint16_t tag, uint16_t type, int n, const int32_t *nd)
{
    add(d, tag, type, (uint32_t)n, nd);
}

static int cmp_ent(const void *a, const void *b)
{
    return ((const ent_t *)a)->tag - ((const ent_t *)b)->tag;
}

static void rational(double v, int32_t *out, int32_t den)
{
    out[0] = (int32_t)llround(v * den);
    out[1] = den;
}

static void clean_str(char *dst, const uint8_t *src, size_t n)
{
    size_t k = 0;
    for (size_t i = 0; i < n && src[i]; i++) if (src[i] >= 32 && src[i] < 127) dst[k++] = (char)src[i];
    dst[k] = 0;
}

/* lay out one IFD; returns bytes used. value area follows the entry table. */
static uint32_t ifd_size(ifd_t *d)
{
    uint32_t s = 2 + 12 * d->n + 4;
    for (int i = 0; i < d->n; i++) if (d->e[i].len > 4) s += (d->e[i].len + 1) & ~1u;
    return s;
}

static uint32_t write_ifd(uint8_t *buf, uint32_t at, ifd_t *d, uint32_t next, clip_t *c,
                          uint32_t exif_at, uint32_t data_off)
{
    qsort(d->e, d->n, sizeof(ent_t), cmp_ent);
    uint16_t n = (uint16_t)d->n;
    memcpy(buf + at, &n, 2);
    uint32_t val = at + 2 + 12 * n + 4;
    for (int i = 0; i < d->n; i++) {
        ent_t *e = &d->e[i];
        uint8_t *p = buf + at + 2 + 12 * i;
        if (e->mark == 3) memcpy(e->data, &exif_at, 4);
        if (e->mark == 4) memcpy(e->data, &data_off, 4);
        memcpy(p, &e->tag, 2); memcpy(p + 2, &e->type, 2); memcpy(p + 4, &e->count, 4);
        if (e->len <= 4) {
            memcpy(p + 8, e->data, e->len);
            if (e->mark == 2) c->off_stripbytes = at + 2 + 12 * i + 8;
        } else {
            memcpy(p + 8, &val, 4);
            memcpy(buf + val, e->data, e->len);
            if (e->mark == 1) c->off_tc = val;
            val += (e->len + 1) & ~1u;
        }
    }
    memcpy(buf + at + 2 + 12 * n, &next, 4);
    return val;
}

int dng_build_template(clip_t *c)
{
    ifd_t ifd0 = {0}, exif = {0};
    raw_info_t *ri = &c->rawi.raw_info;
    char model[64] = "Canon EOS", serial[40] = "";
    if (c->have_idnt) {
        clean_str(model, c->idnt.cameraName, sizeof(c->idnt.cameraName));
        clean_str(serial, c->idnt.cameraSerial, sizeof(c->idnt.cameraSerial));
        if (!model[0]) strcpy(model, "Canon EOS");
    }
    int bits = c->fastpass ? c->bpp : 16;

    add_long(&ifd0, 254, 0);
    add_long(&ifd0, 256, (uint32_t)c->width);
    add_long(&ifd0, 257, (uint32_t)c->height);
    add_short(&ifd0, 258, (uint16_t)bits);
    add_short(&ifd0, 259, c->fastpass ? 7 : 1);
    add_short(&ifd0, 262, 32803);
    add_ascii(&ifd0, 271, "Canon");
    add_ascii(&ifd0, 272, model);
    add(&ifd0, 273, T_LONG, 1, NULL)->mark = 4;
    add_short(&ifd0, 274, 1);
    add_short(&ifd0, 277, 1);
    add_long(&ifd0, 278, (uint32_t)c->height);
    add(&ifd0, 279, T_LONG, 1, NULL)->mark = 2;
    add_short(&ifd0, 284, 1);
    add_ascii(&ifd0, 305, "MLV Resolve FS " MRFS_VERSION " (Linux)");
    char date[32] = "2000:01:01 00:00:00";
    if (c->have_rtci)
        snprintf(date, sizeof(date), "%04d:%02d:%02d %02d:%02d:%02d", c->rtci.tm_year + 1900,
                 c->rtci.tm_mon + 1, c->rtci.tm_mday, c->rtci.tm_hour, c->rtci.tm_min, c->rtci.tm_sec);
    add_ascii(&ifd0, 306, date);
    uint16_t rep[2] = {2, 2};
    add(&ifd0, 33421, T_SHORT, 2, rep);
    uint8_t cfa[4];
    uint32_t pat = (uint32_t)ri->cfa_pattern;
    if (pat == 0) pat = 0x02010100;
    memcpy(cfa, &pat, 4);
    add(&ifd0, 33422, T_BYTE, 4, cfa);
    add(&ifd0, 34665, T_LONG, 1, NULL)->mark = 3;
    uint8_t ver[4] = {1, 4, 0, 0}, bver[4] = {1, 3, 0, 0};
    add(&ifd0, 50706, T_BYTE, 4, ver);
    add(&ifd0, 50707, T_BYTE, 4, bver);
    add_ascii(&ifd0, 50708, model);
    add_long(&ifd0, 50714, (uint32_t)c->out_black);
    add_long(&ifd0, 50717, (uint32_t)c->out_white);

    /* anamorphic / line-skipped modes */
    int32_t scale[4] = {1, 1, 1, 1};
    if (c->have_rawc) {
        int hf = c->rawc.binning_x + c->rawc.skipping_x;
        int vf = c->rawc.binning_y + c->rawc.skipping_y;
        if (hf > 0 && vf > 0 && hf != vf) {
            if (vf > hf) { scale[2] = vf; scale[3] = hf; }
            else { scale[0] = hf; scale[1] = vf; }
        }
    }
    add_rat(&ifd0, 50718, T_RATIONAL, 2, scale);
    uint32_t origin[2] = {0, (uint32_t)c->junk_top};
    uint32_t size[2] = {(uint32_t)c->width, (uint32_t)(c->height - c->junk_top - c->junk_bottom)};
    add(&ifd0, 50719, T_LONG, 2, origin);
    add(&ifd0, 50720, T_LONG, 2, size);

    int32_t cm[18];
    int have_cm = 0;
    for (int i = 0; i < 9; i++) {
        cm[2 * i] = ri->color_matrix1[2 * i];
        cm[2 * i + 1] = ri->color_matrix1[2 * i + 1] ? ri->color_matrix1[2 * i + 1] : 10000;
        if (ri->color_matrix1[2 * i]) have_cm = 1;
    }
    if (!have_cm) { /* generic Canon fallback (5D Mark III, Adobe D65) */
        static const int32_t d[9] = {6722, -635, -963, -4287, 12460, 2028, -908, 2162, 5668};
        for (int i = 0; i < 9; i++) { cm[2 * i] = d[i]; cm[2 * i + 1] = 10000; }
    }
    add_rat(&ifd0, 50721, T_SRATIONAL, 9, cm);

    double nr = 0.5, nb = 0.6;
    if (c->have_wbal && c->wbal.wbgain_g && c->wbal.wbgain_r && c->wbal.wbgain_b) {
        double r = (double)c->wbal.wbgain_r / c->wbal.wbgain_g;
        double b = (double)c->wbal.wbgain_b / c->wbal.wbgain_g;
        if (r > 1) r = 1 / r;
        if (b > 1) b = 1 / b;
        if (r > 0.1 && b > 0.1) { nr = r; nb = b; }
    }
    int32_t neutral[6];
    rational(nr, neutral, 1000000); rational(1, neutral + 2, 1); rational(nb, neutral + 4, 1000000);
    add_rat(&ifd0, 50728, T_RATIONAL, 3, neutral);
    int32_t be[2] = {0, 1};
    add_rat(&ifd0, 50730, T_SRATIONAL, 1, be);
    if (serial[0]) add_ascii(&ifd0, 50735, serial);
    uint16_t ill = (uint16_t)(ri->calibration_illuminant1 ? ri->calibration_illuminant1 : 21);
    add_short(&ifd0, 50778, ill);
    uint32_t aa[4] = {0, 0, (uint32_t)c->height, (uint32_t)c->width};
    add(&ifd0, 50829, T_LONG, 4, aa);
    add(&ifd0, 51043, T_BYTE, 8, NULL)->mark = 1;
    int32_t fr[2] = {(int32_t)c->fps_num, (int32_t)c->fps_den};
    add_rat(&ifd0, 51044, T_SRATIONAL, 1, fr);
    add_ascii(&ifd0, 51081, c->dirname);

    /* EXIF */
    if (c->have_expo) {
        int32_t et[2] = {1, 50};
        uint64_t us = c->expo.shutterValue;
        if (us > 0) {
            if (us < 1000000) { et[0] = 1; et[1] = (int32_t)llround(1e6 / (double)us); }
            else { et[0] = (int32_t)(us / 1000); et[1] = 1000; }
        }
        add_rat(&exif, 33434, T_RATIONAL, 1, et);
        uint16_t iso = (uint16_t)(c->expo.isoValue ? c->expo.isoValue : 100);
        add_short(&exif, 34855, iso);
    }
    if (c->have_lens) {
        if (c->lens.aperture) { int32_t fn[2] = {c->lens.aperture, 100}; add_rat(&exif, 33437, T_RATIONAL, 1, fn); }
        if (c->lens.focalLength) { int32_t fl[2] = {c->lens.focalLength, 1}; add_rat(&exif, 37386, T_RATIONAL, 1, fl); }
        char lens[40]; clean_str(lens, c->lens.lensName, sizeof(c->lens.lensName));
        if (lens[0]) add_ascii(&exif, 42036, lens);
    }
    add(&exif, 36864, T_UNDEF, 4, "0230");

    uint32_t s0 = ifd_size(&ifd0), s1 = ifd_size(&exif);
    uint32_t total = 8 + s0 + s1;
    uint32_t hdr = (total + 511) & ~511u;
    free(c->dng_hdr);
    c->dng_hdr = calloc(1, hdr);
    memcpy(c->dng_hdr, "II*\0", 4);
    uint32_t first = 8;
    memcpy(c->dng_hdr + 4, &first, 4);
    uint32_t exif_at = 8 + s0;
    write_ifd(c->dng_hdr, 8, &ifd0, 0, c, exif_at, hdr);
    write_ifd(c->dng_hdr, exif_at, &exif, 0, c, exif_at, hdr);
    c->dng_hdr_size = hdr;
    return 0;
}

static uint8_t bcd(int v) { return (uint8_t)(((v / 10) << 4) | (v % 10)); }

void dng_patch_header(const clip_t *c, uint32_t frame, uint8_t *out)
{
    memcpy(out, c->dng_hdr, c->dng_hdr_size);
    int base = (int)llround((double)c->fps_num / c->fps_den);
    if (base < 1) base = 1;
    uint64_t t = c->tc_start_frames + frame;
    int ff = (int)(t % base); t /= base;
    int ss = (int)(t % 60); t /= 60;
    int mm = (int)(t % 60); t /= 60;
    int hh = (int)(t % 24);
    uint8_t tc[8] = {bcd(ff), bcd(ss), bcd(mm), bcd(hh), 0, 0, 0, 0};
    memcpy(out + c->off_tc, tc, 8);
    uint32_t sb = c->fastpass ? c->frames[frame].size : (uint32_t)(c->width * c->height * 2);
    memcpy(out + c->off_stripbytes, &sb, 4);
}

uint64_t dng_file_size(const clip_t *c, uint32_t frame)
{
    if (c->fastpass) return c->dng_hdr_size + (uint64_t)c->frames[frame].size;
    return c->dng_hdr_size + (uint64_t)c->width * c->height * 2;
}
