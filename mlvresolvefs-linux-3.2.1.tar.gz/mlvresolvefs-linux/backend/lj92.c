/*
 * Lossless JPEG (ITU T.81 process 14, SOF3) decoder for Magic Lantern LJ92 frames.
 * Written for MLV Resolve FS (Linux). Handles any predictor 1-7, point transform,
 * 1-4 interleaved components and restart intervals.
 */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "lj92.h"

typedef struct {
    uint16_t lut[1 << 16];   /* (len << 8) | ssss, 0 = invalid */
    int present;
} huff_t;

typedef struct {
    const uint8_t *p, *end;
    uint64_t buf;
    int bits;
    int marker;              /* hit a marker: feed zeros */
} bitrd_t;

static inline void br_fill(bitrd_t *b)
{
    while (b->bits <= 56) {
        uint8_t c = 0;
        if (!b->marker && b->p < b->end) {
            c = *b->p;
            if (c == 0xFF) {
                uint8_t n = (b->p + 1 < b->end) ? b->p[1] : 0xD9;
                if (n == 0x00) { b->p += 2; }
                else { b->marker = 1; c = 0; }
            } else {
                b->p++;
            }
        }
        b->buf |= (uint64_t)c << (56 - b->bits);
        b->bits += 8;
    }
}

static inline int br_get(bitrd_t *b, int n)
{
    if (n == 0) return 0;
    if (b->bits < n) br_fill(b);
    int v = (int)(b->buf >> (64 - n));
    b->buf <<= n;
    b->bits -= n;
    return v;
}

static inline int br_huff(bitrd_t *b, const huff_t *h)
{
    if (b->bits < 16) br_fill(b);
    uint16_t e = h->lut[b->buf >> 48];
    if (!e) return -1;
    int len = e >> 8;
    b->buf <<= len;
    b->bits -= len;
    return e & 0xFF;
}

static int build_huff(huff_t *h, const uint8_t *counts, const uint8_t *vals, int nvals)
{
    memset(h->lut, 0, sizeof(h->lut));
    int code = 0, k = 0;
    for (int len = 1; len <= 16; len++) {
        for (int i = 0; i < counts[len - 1]; i++) {
            if (k >= nvals) return -1;
            int shift = 16 - len;
            int start = code << shift, n = 1 << shift;
            if (start + n > 65536) return -1;
            for (int j = 0; j < n; j++) h->lut[start + j] = (uint16_t)((len << 8) | vals[k]);
            code++; k++;
        }
        code <<= 1;
    }
    h->present = 1;
    return 0;
}

int lj92_probe(const uint8_t *d, size_t len, lj92_info_t *info)
{
    memset(info, 0, sizeof(*info));
    if (len < 4 || d[0] != 0xFF || d[1] != 0xD8) return -1;
    size_t i = 2;
    while (i + 4 <= len) {
        if (d[i] != 0xFF) { i++; continue; }
        uint8_t m = d[i + 1];
        if (m == 0xFF) { i++; continue; }
        int L = (d[i + 2] << 8) | d[i + 3];
        if (m == 0xC3) {
            if (i + 2 + L > len || L < 11) return -1;
            info->precision = d[i + 4];
            info->height = (d[i + 5] << 8) | d[i + 6];
            info->width = (d[i + 7] << 8) | d[i + 8];
            info->components = d[i + 9];
            return 0;
        }
        if (m == 0xDA) return -1;
        i += 2 + L;
    }
    return -1;
}

int lj92_decode(const uint8_t *d, size_t len, uint16_t *out, size_t out_samples)
{
    huff_t *tabs = calloc(4, sizeof(huff_t));
    if (!tabs) return -10;
    int ret = -1;
    int P = 0, X = 0, Y = 0, Nf = 0, restart = 0;
    int comp_id[4] = {0}, comp_tab[4] = {0};
    int pred = 1, pt = 0;
    size_t i = 2;

    if (len < 4 || d[0] != 0xFF || d[1] != 0xD8) goto out;

    for (;;) {
        if (i + 4 > len) goto out;
        if (d[i] != 0xFF) { i++; continue; }
        uint8_t m = d[i + 1];
        if (m == 0xFF) { i++; continue; }
        int L = (d[i + 2] << 8) | d[i + 3];
        const uint8_t *s = d + i + 4;
        if (i + 2 + L > len) goto out;
        if (m == 0xC4) {
            int pos = 0;
            while (pos < L - 2) {
                int tc = s[pos] >> 4, th = s[pos] & 15;
                const uint8_t *counts = s + pos + 1;
                int n = 0;
                for (int k = 0; k < 16; k++) n += counts[k];
                if (tc != 0 || th > 3 || pos + 17 + n > L - 2) { ret = -2; goto out; }
                if (build_huff(&tabs[th], counts, s + pos + 17, n)) { ret = -2; goto out; }
                pos += 17 + n;
            }
        } else if (m == 0xC3) {
            P = s[0]; Y = (s[1] << 8) | s[2]; X = (s[3] << 8) | s[4]; Nf = s[5];
            if (Nf < 1 || Nf > 4) { ret = -3; goto out; }
            for (int k = 0; k < Nf; k++) comp_id[k] = s[6 + 3 * k];
        } else if (m == 0xDD) {
            restart = (s[0] << 8) | s[1];
        } else if (m == 0xDA) {
            int Ns = s[0];
            if (Ns != Nf) { ret = -4; goto out; }
            for (int k = 0; k < Ns; k++) {
                int cid = s[1 + 2 * k], td = s[2 + 2 * k] >> 4;
                for (int c = 0; c < Nf; c++) if (comp_id[c] == cid) comp_tab[c] = td;
            }
            pred = s[1 + 2 * Ns];
            pt = s[3 + 2 * Ns] & 15;
            i += 2 + L;
            break;
        } else if (m == 0xD9) {
            goto out;
        }
        i += 2 + L;
    }

    if (!X || !Y || !P) { ret = -3; goto out; }
    for (int c = 0; c < Nf; c++) if (!tabs[comp_tab[c]].present) { ret = -2; goto out; }
    size_t rowlen = (size_t)X * Nf;
    if (rowlen * Y != out_samples) { ret = -5; goto out; }

    bitrd_t br = { d + i, d + len, 0, 0, 0 };
    int init = 1 << (P - pt - 1);
    long mcu = 0;
    int reset = 1;

    for (int y = 0; y < Y; y++) {
        uint16_t *row = out + (size_t)y * rowlen;
        uint16_t *up = y ? row - rowlen : NULL;
        int firstline = (y == 0);
        for (int x = 0; x < X; x++) {
            if (restart && mcu && (mcu % restart) == 0) {
                /* resync on the RSTn marker */
                br.buf = 0; br.bits = 0; br.marker = 0;
                while (br.p + 1 < br.end && !(br.p[0] == 0xFF && br.p[1] >= 0xD0 && br.p[1] <= 0xD7)) br.p++;
                if (br.p + 1 < br.end) br.p += 2;
                reset = 1;
                firstline = 1;
            }
            int first = reset;
            for (int c = 0; c < Nf; c++) {
                int ssss = br_huff(&br, &tabs[comp_tab[c]]);
                if (ssss < 0) { ret = -6; goto out; }
                int diff;
                if (ssss == 0) diff = 0;
                else if (ssss == 16) diff = 32768;
                else {
                    diff = br_get(&br, ssss);
                    if (diff < (1 << (ssss - 1))) diff -= (1 << ssss) - 1;
                }
                int p;
                size_t idx = (size_t)x * Nf + c;
                if (first) p = init;
                else if (firstline) p = row[idx - Nf];
                else if (x == 0) p = up[idx];
                else {
                    int ra = row[idx - Nf], rb = up[idx], rc = up[idx - Nf];
                    switch (pred) {
                    case 1: p = ra; break;
                    case 2: p = rb; break;
                    case 3: p = rc; break;
                    case 4: p = ra + rb - rc; break;
                    case 5: p = ra + ((rb - rc) >> 1); break;
                    case 6: p = rb + ((ra - rc) >> 1); break;
                    case 7: p = (ra + rb) >> 1; break;
                    default: p = ra; break;
                    }
                }
                row[idx] = (uint16_t)(p + diff);
            }
            reset = 0;
            mcu++;
        }
    }
    if (pt) for (size_t k = 0; k < out_samples; k++) out[k] <<= pt;
    ret = 0;
out:
    free(tabs);
    return ret;
}
