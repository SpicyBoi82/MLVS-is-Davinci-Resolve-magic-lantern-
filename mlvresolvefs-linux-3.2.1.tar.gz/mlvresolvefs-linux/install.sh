#!/usr/bin/env bash
# MLV Resolve FS for Linux - installer (Ubuntu 24.04 / Debian-based)
# Installs for the current user only. sudo is used just for apt packages.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SHARE="$HOME/.local/share/mlvresolvefs"
BIN="$HOME/.local/bin"
APPS="$HOME/.local/share/applications"
RESOLVE_SCRIPTS="$HOME/.local/share/DaVinciResolve/Fusion/Scripts/Utility"
DEPS=(build-essential pkg-config libfuse3-dev fuse3 python3-gi gir1.2-gtk-3.0)

say() { printf '\033[1m==> %s\033[0m\n' "$*"; }

if [ "$(id -u)" = 0 ]; then
    echo "Run this as your normal user (not with sudo); it asks for your password when needed."
    exit 1
fi

if grep -q 'fuse.mlvresolvefs' /proc/mounts; then
    echo "Unmount MLV Resolve FS and close its window before updating."
    exit 1
fi

say "Checking packages"
missing=()
for p in "${DEPS[@]}"; do
    dpkg-query -W -f='${Status}' "$p" 2>/dev/null | grep -q "install ok installed" || missing+=("$p")
done
if [ ${#missing[@]} -gt 0 ]; then
    say "Installing: ${missing[*]}"
    sudo apt-get update
    sudo apt-get install -y "${missing[@]}"
fi

say "Building the backend"
make -C "$HERE/backend" clean >/dev/null
make -C "$HERE/backend" -j"$(nproc)"

say "Installing to $SHARE"
mkdir -p "$SHARE/bin" "$SHARE/src" "$BIN" "$APPS"
install -m 755 "$HERE/backend/mlvresolvefs" "$SHARE/bin/mlvresolvefs"
install -m 755 "$HERE/app/mlvresolvefs-gui.py" "$SHARE/mlvresolvefs-gui.py"
install -m 755 "$HERE/app/mlvresolvefs-gui" "$SHARE/mlvresolvefs-gui"
install -m 644 "$HERE/app/mlvresolvefs.svg" "$SHARE/mlvresolvefs.svg"
rm -rf "$SHARE/src/backend" "$SHARE/resolve-scripts"
mkdir -p "$SHARE/src/backend"
cp "$HERE"/backend/*.c "$HERE"/backend/*.h "$HERE/backend/Makefile" "$SHARE/src/backend/"
cp -r "$HERE/resolve-scripts" "$SHARE/resolve-scripts"
ln -sf "$SHARE/bin/mlvresolvefs" "$BIN/mlvresolvefs"
ln -sf "$SHARE/mlvresolvefs-gui" "$BIN/mlvresolvefs-gui"

cat > "$APPS/mlvresolvefs.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=MLV Resolve FS
Comment=Mount Magic Lantern MLV footage as CinemaDNG for DaVinci Resolve
Exec=$SHARE/mlvresolvefs-gui
Icon=$SHARE/mlvresolvefs.svg
Terminal=false
Categories=AudioVideo;Video;
EOF
update-desktop-database "$APPS" >/dev/null 2>&1 || true

say "Installing Resolve scripts (Workspace > Scripts)"
mkdir -p "$RESOLVE_SCRIPTS"
cp "$HERE"/resolve-scripts/*.lua "$RESOLVE_SCRIPTS/"

mkdir -p "$HOME/MLV_Resolve" "$HOME/.config/mlvresolvefs"
[ -f "$HOME/.config/mlvresolvefs/mountpoint" ] || echo "$HOME/MLV_Resolve" > "$HOME/.config/mlvresolvefs/mountpoint"

if [ ! -e /dev/fuse ]; then
    echo "Warning: /dev/fuse is missing. Reboot, then start the app again."
fi

say "Done. Start \"MLV Resolve FS\" from your app menu, or run: mlvresolvefs-gui"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "(Log out and back in so ~/.local/bin is on your PATH.)";; esac
