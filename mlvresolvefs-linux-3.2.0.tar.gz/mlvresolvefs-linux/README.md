# MLV Resolve FS for Linux 3.2.0 (Ubuntu 24.04)

Mount Magic Lantern `.MLV` footage as virtual CinemaDNG folders that DaVinci Resolve
reads directly — no DNG copy on disk. Linux port of the Windows MLV Resolve FS tool,
with its own native backend (no Cygwin, WinFsp or MLVFS patching).

## Install

```bash
tar xzf mlvresolvefs-linux-3.2.0.tar.gz
cd mlvresolvefs-linux
./install.sh          # asks for your password once, for apt packages
```

Then open **MLV Resolve FS** from the app menu (or run `mlvresolvefs-gui`).

## Use

1. Pick the **MLV source folder** (sub-folders are scanned too; spanned `.M00/.M01…`
   chunks are joined automatically).
2. Leave the **mount point** at `~/MLV_Resolve` (any empty folder works).
3. Click **Mount for Resolve**. Each MLV appears as a folder of `…_000000.dng` frames plus
   a `.wav` with matching timecode.
4. In Resolve: **Workspace > Scripts > MLV Resolve FS - Import and Sync Mounted Clips**
   (restart Resolve once after installing), or browse to `~/MLV_Resolve` in the Media page.

The mount survives closing the window. Unmount before unplugging the card/drive.
If Resolve still has clips open, the app offers a lazy unmount.

## New in 3.2.0 — Windows 3.2 functionality port

* Windows 3.2 Dual ISO processing: both 2-row and 4-row gain groups, row-phase
  detection per frame, and edge-directed same-colour interpolation to reduce moiré.
* Clipping pile-up detection handles a real white level above or below RAWI metadata,
  including the 70D crop-mode highlight problem. Explicit white override still wins.
* Automatic mounting at desktop login, using the saved settings. Enable the checkbox;
  changes to source/processing are saved when mounting or closing. The app waits up to
  90 seconds for a removable source folder; if absent it leaves a status message.
* Non-blocking mount startup with a detached backend. A slow start is still monitored
  after 90 seconds; it is never killed just for being slow. Closing the window while
  mounting leaves that startup running. After mounting, choose Yes to keep it mounted.
* Show Log opens the full log, including processing diagnostics from earlier mounts.
* Linux cache format updated so old white-level estimates are recalculated once.

### Update an existing installation

Close Resolve, unmount in the old app, then close the old app. Extract this package
and run `./install.sh` **as your normal user, without sudo**. It rebuilds and replaces
both backend and launcher; your saved settings remain. Start the updated app from
its menu entry and select **Dual ISO → Full processing** for dual-ISO footage.
The installer needs access to Ubuntu package repositories if dependencies are missing.

Keep your existing naming setting to preserve Resolve links. Untick **Resolve naming**
for Windows-style simple names (`CLIP/CLIP_000000.dng`); changing this requires relinking.
The existing Linux default remains enabled for compatibility with your projects.

### Preserved Linux features

Persistent indexing and background warm-up; displaced LJ92 stream detection and
uncompressed fallback; Resolve read/write probe compatibility (actual writes still
refused); paths containing spaces; native FUSE3; GTK controls; Resolve import/audio
sync scripts; FPS/white overrides and 3x3 chroma smoothing.

### Validation and limitations

The complete native backend builds on Ubuntu 24.04 x86-64. Included tests exercise
both ISO group widths and every phase offset in Preview and Full modes, diagonal
interpolation, normal-frame detection, clipping above/below metadata, actual MLV
indexing, cached levels, explicit override and DNG header generation. Six launcher
logic tests cover options, startup failure/timeout and login mounting. See
`PORTING-NOTES.md` for test scope. Run `tests/run.sh` to repeat them.

There is no FUSE device or DaVinci Resolve in the build environment: real mounted
playback and real-footage image quality still need testing on your computer. The
included backend binary is Ubuntu 24.04 x86-64; the installer rebuilds from source
for the host instead of depending on that binary.

## New in 1.2.1

* Source folders whose name starts or ends with a space work (1.2.0 trimmed the space and
  then said the folder does not exist). If a path really is wrong, the message now names
  the missing part and shows similar folder names.

## New in 1.2.0

* **Red / offline clips and no sound in Resolve fixed.** Resolve on Linux opens media
  read/write just to check it. 1.1.0 mounted read-only, so those opens were refused and
  Resolve marked the clips offline. Read/write opens are now accepted; nothing is ever
  written (any write is refused).
* **"LJ92 decode failed on frame N" fixed** for clips whose lossless stream doesn't start
  exactly where the frame header says. The real start is found in each frame, and those
  clips play with Fast Pass again. Clips flagged as lossless that actually contain
  uncompressed frames are detected and read as uncompressed.
* Frames that really are damaged show black (not coloured garbage), and the log shows
  their first bytes, so a card problem is easy to recognise.
* All clips are indexed in the background right after mounting, and the index is saved
  in `~/.cache/mlvresolvefs`, so later mounts are instant even with long clips. Wait for
  **all clips ready** in the log before importing a big folder for the first time.
* The app warns before Unmount/Remount while Resolve is open.

## If clips are red in Resolve

Clips that went offline stay red even after the folder is back. In the Media Pool select
them, right-click > **Relink Selected Clips**, pick `~/MLV_Resolve`, or close and reopen
the project. Keep the folder mounted while Resolve is open.

## Options

| Option | What it does |
|---|---|
| Resolve naming | `NAMEMLV_1_YYYY-MM-DD_0001_C0000_000000.dng`, which Resolve groups reliably |
| Prefetch frames | frames read/decoded ahead in background threads |
| FPS override | use when the MLV's frame rate tag is wrong (e.g. FPS-override clips tagged 29.986) |
| White level | force a white level; leave empty for automatic |
| Bad pixel correction | maps hot/dead pixels from 3 frames per clip and fills them |
| Vertical stripe correction | per-column gain fix (older 5D3/5D2 style stripes) |
| Repair corrupt edge rows | overwrites junk rows at the frame edge (they're always cropped via DNG crop tags anyway) |
| Chroma smoothing | 2x2 / 3x3 median on colour difference — reduces colour aliasing |
| Dual ISO | Preview: scales the dark rows. Full: edge-directed interpolation and exposure blending |

**Fast pass:** with every correction off, lossless (LJ92) frames are passed straight into
the DNG without decoding — byte-identical to MLV App's lossless DNG export. This is the
lightest option for a slow PC. Turning any correction on switches to decoding (16-bit
uncompressed DNGs).

## Command line

```bash
mlvresolvefs [--bad-pixels] [--stripes] [--chroma=2] [--dual-iso=2] [--prefetch=8] \
             [--fps=23.976] [--white=N] [--fix-edges] [--plain-naming] [-f] SOURCE MOUNTPOINT
fusermount3 -u MOUNTPOINT
```

Log: `~/.local/state/mlvresolvefs/mount.log`

## What changed vs the Windows version

* Native C backend using libfuse3 (in Ubuntu by default) instead of building MLVFS under
  Cygwin at install time, so the LJ92 patch failures from the thread can't happen.
* Lossless decoder verified bit-exact against MLV App on the 70D test frames.
* 70D crop recordings: the 8 junk rows at the bottom of 3200×1318 frames (the bright line
  at the bottom in Resolve) are cropped out via DNG `DefaultCrop`.
* White level: detected from a clipping pile-up when available, otherwise metadata/fallback.
* DNG timecode and WAV `bext` time reference both use the camera's time of day, so
  "Auto Sync Audio > Based on Timecode" pairs each clip with its own WAV.

## Limits

* LZMA/delta-compressed MLVs (old mlv_dump output) are not supported; uncompressed and
  lossless MLV are.
* Dual ISO "Full" uses the Windows 3.2 edge-directed blend, not the cr2hdr pipeline.
  Detection is initialised from the middle frame; if no usable pattern is found there,
  processing is left off. Per-frame classification falls back to that initial pattern
  when a frame is ambiguous. This preserves Windows behaviour, including its limits.
* Audio is joined as recorded; with FPS override the audio length won't match a forced
  frame rate (same as MLV App).
* Resolve's free version on Linux reads CinemaDNG and WAV fine; the import script uses
  `AutoSyncAudio`, which older Resolve versions lack — the script then tells you to use
  right-click > Auto Sync Audio > Based on Timecode.

## Uninstall

```bash
./uninstall.sh
```
