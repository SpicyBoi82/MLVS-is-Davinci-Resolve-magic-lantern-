"""Headless launcher behaviour tests; Gtk construction is checked separately."""
import importlib.util
from pathlib import Path
import tempfile
import time
import sys
import types
import unittest
from unittest.mock import Mock, patch

# Import without requiring a display/GTK installation.
gi = types.ModuleType('gi')
gi.require_version = lambda *_: None
repo = types.ModuleType('gi.repository')
repo.Gtk = types.SimpleNamespace(Window=object, ButtonsType=types.SimpleNamespace(OK=1), MessageType=types.SimpleNamespace(ERROR=1))
repo.GLib = types.SimpleNamespace()
with patch.dict(sys.modules, {'gi': gi, 'gi.repository': repo}):
    spec = importlib.util.spec_from_file_location('launcher', Path(__file__).resolve().parents[1] / 'app/mlvresolvefs-gui.py')
    app = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(app)

class LauncherTests(unittest.TestCase):
    def test_source_spaces(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / ' clip '
            p.mkdir()
            self.assertEqual(app.source_path(str(p)), str(p))

    def test_autostart(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(app, 'AUTOSTART', str(Path(tmp)/'autostart/test.desktop')):
            app.set_autostart(True)
            self.assertIn('--automount', Path(app.AUTOSTART).read_text())
            app.set_autostart(False)
            self.assertFalse(Path(app.AUTOSTART).exists())

    def test_options(self):
        w = object.__new__(app.Window)
        for k, v in dict(resolve_naming=False,bad_pixels=True,stripes=True,fix_edges=True).items():
            setattr(w,k,Mock(get_active=lambda v=v: v))
        w.chroma=Mock(get_active=lambda: 2)
        w.dual=Mock(get_active=lambda: 2)
        w.prefetch=Mock(get_value=lambda: 8)
        w.fps=Mock(get_text=lambda: '23,976')
        w.white=Mock(get_text=lambda: '2950')
        self.assertEqual(w.backend_args(), ['--plain-naming','--bad-pixels','--stripes','--fix-edges',
                         '--chroma=3','--dual-iso=2','--prefetch=8','--fps=23.976','--white=2950'])
        w.fps=Mock(get_text=lambda: 'nan')
        with self.assertRaises(ValueError): w.backend_args()

    def test_pending_slow_mount_not_killed(self):
        w=object.__new__(app.Window); p=Mock(poll=lambda: None)
        w.pending=(p,'/mount',time.monotonic()-100); w.busy=True; w.set_status=Mock()
        with patch.object(app,'mounted_at',return_value=False): w.poll_mount()
        self.assertTrue(w.busy); self.assertIsNotNone(w.pending)
        p.kill.assert_not_called(); p.terminate.assert_not_called()
        with patch.object(app,'mounted_at',return_value=True): w.poll_mount()
        self.assertFalse(w.busy); self.assertIsNone(w.pending)

    def test_mount_failure(self):
        w=object.__new__(app.Window); w.pending=(Mock(poll=lambda: 1),'/mount',time.monotonic())
        w.busy=True; w.indexing=True; w.append_log=Mock(); w.message=Mock()
        w.poll_mount()
        self.assertFalse(w.busy); self.assertFalse(w.indexing); w.message.assert_called_once()

    def test_automount_does_not_remount(self):
        w=object.__new__(app.Window); w.cfg={'auto_mount': True}; w.mp=lambda: '/mount'; w.on_mount=Mock()
        with patch.object(app,'mounted_at',return_value=True):
            self.assertFalse(w.auto_mount_when_ready())
        w.on_mount.assert_not_called()

if __name__ == '__main__': unittest.main()
