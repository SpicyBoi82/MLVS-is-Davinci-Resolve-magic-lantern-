import importlib.util
from pathlib import Path
import tempfile
from gi.repository import GLib
spec=importlib.util.spec_from_file_location('app',str(Path(__file__).resolve().parents[1] / 'app/mlvresolvefs-gui.py'))
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
with tempfile.TemporaryDirectory() as tmp:
    a.CONFIG_DIR=tmp;a.SETTINGS=tmp+'/settings.json';a.MOUNTPOINT_FILE=tmp+'/mountpoint'
    a.AUTOSTART=tmp+'/autostart/mlvresolvefs.desktop';a.LOG=tmp+'/mount.log';a.STATE_DIR=tmp
    w=a.Window();w.show_all()
    while a.Gtk.events_pending(): a.Gtk.main_iteration_do(False)
    assert w.get_title().endswith('3.2.0')
    assert not w.auto_mount.get_active()
    w.auto_mount.set_active(True)
    assert Path(a.AUTOSTART).exists()
    w.dual.set_active(2);assert '--dual-iso=2' in w.backend_args()
    w.save_settings()
    assert '"dual_iso": 2' in Path(a.SETTINGS).read_text()
    w.auto_mount.set_active(False);assert not Path(a.AUTOSTART).exists()
    w.destroy()
print('PASS: real GTK window construction, options, autostart toggle and settings save')
