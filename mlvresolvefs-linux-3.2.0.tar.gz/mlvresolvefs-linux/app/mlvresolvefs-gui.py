#!/usr/bin/env python3
"""MLV Resolve FS for Linux - mount Magic Lantern MLV footage as virtual CinemaDNG for DaVinci Resolve."""
import json
import sys
import os
import shutil
import subprocess
import threading
import time

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import GLib, Gtk  # noqa: E402

APP = "MLV Resolve FS"
VERSION = "3.2.0"
HOME = os.path.expanduser("~")
SHARE = os.path.join(HOME, ".local", "share", "mlvresolvefs")
CONFIG_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.join(HOME, ".config")), "mlvresolvefs")
STATE_DIR = os.path.join(os.environ.get("XDG_STATE_HOME", os.path.join(HOME, ".local", "state")), "mlvresolvefs")
SETTINGS = os.path.join(CONFIG_DIR, "settings.json")
MOUNTPOINT_FILE = os.path.join(CONFIG_DIR, "mountpoint")
LOG = os.path.join(STATE_DIR, "mount.log")
STDERR_LOG = os.path.join(STATE_DIR, "mount-stderr.log")
AUTOSTART = os.path.join(os.path.dirname(CONFIG_DIR), "autostart", "mlvresolvefs.desktop")
HERE = os.path.dirname(os.path.realpath(__file__))
RESOLVE_SCRIPT_DIR = os.path.join(HOME, ".local", "share", "DaVinciResolve", "Fusion", "Scripts", "Utility")
APT_DEPS = ["build-essential", "pkg-config", "libfuse3-dev", "fuse3"]

DEFAULTS = {
    "source": os.path.join(HOME, "Videos"),
    "mountpoint": os.path.join(HOME, "MLV_Resolve"),
    "prefetch": 8,
    "fps": "",
    "white": "",
    "resolve_naming": True,
    "bad_pixels": False,
    "stripes": False,
    "fix_edges": False,
    "chroma": 0,
    "dual_iso": 0,
    "auto_mount": False,
}


def desktop_quote(value):
    """Quote one Desktop Entry Exec argument (not a shell command)."""
    value = value.replace("%", "%%")
    for char in ("\\", '"', "`", "$"):
        value = value.replace(char, "\\" + char)
    return '"' + value.replace("\\", "\\\\") + '"'


def set_autostart(enabled):
    if not enabled:
        try:
            os.unlink(AUTOSTART)
        except FileNotFoundError:
            pass
        return
    os.makedirs(os.path.dirname(AUTOSTART), exist_ok=True)
    launcher = os.path.join(SHARE, "mlvresolvefs-gui")
    if not os.path.isfile(launcher):
        launcher = os.path.join(HERE, "mlvresolvefs-gui")
    with open(AUTOSTART, "w") as f:
        f.write("[Desktop Entry]\nType=Application\nName=MLV Resolve FS\n"
                "Exec=" + desktop_quote(launcher) + " --automount\n"
                "Terminal=false\nX-GNOME-Autostart-enabled=true\n")


def find_backend():
    for p in (os.path.join(SHARE, "bin", "mlvresolvefs"),
              os.path.join(HERE, "..", "backend", "mlvresolvefs"),
              shutil.which("mlvresolvefs") or ""):
        if p and os.path.isfile(p) and os.access(p, os.X_OK):
            return os.path.realpath(p)
    return None


def find_backend_source():
    for p in (os.path.join(SHARE, "src", "backend"), os.path.join(HERE, "..", "backend")):
        if os.path.isfile(os.path.join(p, "Makefile")):
            return os.path.realpath(p)
    return None


def find_resolve_scripts():
    for p in (os.path.join(SHARE, "resolve-scripts"), os.path.join(HERE, "..", "resolve-scripts")):
        if os.path.isdir(p):
            return os.path.realpath(p)
    return None


def resolve_running():
    """True when DaVinci Resolve is open (its Linux process is called 'resolve')."""
    try:
        return subprocess.run(["pgrep", "-x", "resolve"], capture_output=True).returncode == 0
    except OSError:
        return False


RELINK_HELP = ("If clips are already red in Resolve: select them in the Media Pool, right-click > "
               "Relink Selected Clips (or Relink Clips for the whole bin) and pick the mount folder, "
               "or close and reopen the project.")


def source_path(text):
    """The folder the user means. Folder names may legitimately start or end with spaces, so the
    text is used exactly as typed/browsed first; trimmed only if the exact text doesn't exist."""
    for cand in (text, text.strip(), text.rstrip("\r\n")):
        p = os.path.expanduser(cand)
        if cand and os.path.isdir(p):
            return os.path.realpath(p)
    return None


def explain_missing(text):
    """Say which part of a path is missing and show similarly named entries, with hidden
    spaces made visible."""
    path = os.path.expanduser(text)
    parts = path.split(os.sep)
    have = os.sep if path.startswith(os.sep) else ""
    for i, part in enumerate(parts):
        if not part:
            continue
        nxt = os.path.join(have, part) if have else part
        if not os.path.exists(nxt):
            where = have or "."
            try:
                names = sorted(os.listdir(where))
            except OSError as e:
                return "%s\n\nCannot read %s: %s" % (text, where, e.strerror)
            key = " ".join(part.lower().split())
            close = [n for n in names if " ".join(n.lower().split()) == key or key[:8] in n.lower()]
            msg = "%s\n\nMissing part: %r inside %s." % (text, part, where)
            if close:
                msg += "\nSimilar names there (quotes show hidden spaces): " + ", ".join(repr(n) for n in close[:6])
                msg += "\n\nUse Browse... to pick the folder."
            elif names:
                msg += "\nThat folder contains: " + ", ".join(repr(n) for n in names[:12])
            return msg
        have = nxt
    if not os.path.isdir(path):
        return "%s\n\nThis is a file, not a folder." % text
    return text


def mounted_at(path):
    path = os.path.realpath(path)
    try:
        with open("/proc/mounts") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 3 and parts[1].replace("\\040", " ") == path and "mlvresolvefs" in (parts[0] + parts[2]):
                    return True
    except OSError:
        pass
    return False


class Window(Gtk.Window):
    def __init__(self):
        super().__init__(title=APP + " " + VERSION)
        self.set_default_size(760, 640)
        self.set_border_width(16)
        self.cfg = dict(DEFAULTS)
        self.load_settings()
        self.busy = False
        self.pending = None

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(outer)

        title = Gtk.Label(xalign=0)
        title.set_markup("<span size='x-large' weight='bold'>Magic Lantern MLV  →  DaVinci Resolve</span>")
        outer.pack_start(title, False, False, 0)
        outer.pack_start(Gtk.Label(label="Mount MLV footage as virtual CinemaDNG without creating a full DNG copy.",
                                   xalign=0), False, False, 0)

        row = Gtk.Box(spacing=8)
        self.backend_label = Gtk.Label(xalign=0)
        row.pack_start(self.backend_label, True, True, 0)
        self.install_btn = Gtk.Button(label="Install / Repair Backend")
        self.install_btn.connect("clicked", self.on_install_backend)
        row.pack_start(self.install_btn, False, False, 0)
        outer.pack_start(row, False, False, 0)

        grid = Gtk.Grid(column_spacing=8, row_spacing=6)
        outer.pack_start(grid, False, False, 0)

        grid.attach(Gtk.Label(label="MLV source folder", xalign=0), 0, 0, 3, 1)
        self.source = Gtk.Entry(text=self.cfg["source"], hexpand=True)
        grid.attach(self.source, 0, 1, 2, 1)
        b = Gtk.Button(label="Browse…")
        b.connect("clicked", self.on_browse, self.source, "Choose the folder with your MLV files")
        grid.attach(b, 2, 1, 1, 1)

        grid.attach(Gtk.Label(label="Mount point (virtual CinemaDNG folders appear here)", xalign=0), 0, 2, 3, 1)
        self.mountpoint = Gtk.Entry(text=self.cfg["mountpoint"], hexpand=True)
        grid.attach(self.mountpoint, 0, 3, 2, 1)
        b = Gtk.Button(label="Browse…")
        b.connect("clicked", self.on_browse, self.mountpoint, "Choose an empty folder to mount into")
        grid.attach(b, 2, 3, 1, 1)

        opts = Gtk.Box(spacing=16)
        outer.pack_start(opts, False, False, 0)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        box.pack_start(Gtk.Label(label="Prefetch frames", xalign=0), False, False, 0)
        self.prefetch = Gtk.SpinButton.new_with_range(0, 64, 1)
        self.prefetch.set_value(self.cfg["prefetch"])
        box.pack_start(self.prefetch, False, False, 0)
        opts.pack_start(box, False, False, 0)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        box.pack_start(Gtk.Label(label="FPS override (optional)", xalign=0), False, False, 0)
        self.fps = Gtk.Entry(text=self.cfg["fps"], width_chars=10, placeholder_text="e.g. 23.976")
        box.pack_start(self.fps, False, False, 0)
        opts.pack_start(box, False, False, 0)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        box.pack_start(Gtk.Label(label="White level (optional)", xalign=0), False, False, 0)
        self.white = Gtk.Entry(text=self.cfg["white"], width_chars=10, placeholder_text="auto")
        box.pack_start(self.white, False, False, 0)
        opts.pack_start(box, False, False, 0)

        frame = Gtk.Frame(label=" MLV processing ")
        outer.pack_start(frame, False, False, 0)
        pg = Gtk.Grid(column_spacing=24, row_spacing=6, margin=10)
        frame.add(pg)
        self.resolve_naming = Gtk.CheckButton(label="Resolve naming", active=self.cfg["resolve_naming"])
        self.bad_pixels = Gtk.CheckButton(label="Bad pixel correction", active=self.cfg["bad_pixels"])
        self.stripes = Gtk.CheckButton(label="Vertical stripe correction", active=self.cfg["stripes"])
        self.fix_edges = Gtk.CheckButton(label="Repair corrupt edge rows", active=self.cfg["fix_edges"])
        self.fix_edges.set_tooltip_text("Some 70D crop recordings end with a band of junk rows. They are always "
                                        "cropped out via the DNG crop tags; this also overwrites them, which "
                                        "needs frame decoding.")
        pg.attach(self.resolve_naming, 0, 0, 1, 1)
        pg.attach(self.bad_pixels, 0, 1, 1, 1)
        pg.attach(self.stripes, 0, 2, 1, 1)
        pg.attach(self.fix_edges, 0, 3, 1, 1)
        hb = Gtk.Box(spacing=6)
        hb.pack_start(Gtk.Label(label="Chroma smoothing"), False, False, 0)
        self.chroma = Gtk.ComboBoxText()
        for t in ("Off", "2x2", "3x3"):
            self.chroma.append_text(t)
        self.chroma.set_active({0: 0, 2: 1, 3: 2}.get(self.cfg["chroma"], 1))
        hb.pack_start(self.chroma, False, False, 0)
        pg.attach(hb, 1, 0, 1, 1)
        hb = Gtk.Box(spacing=6)
        hb.pack_start(Gtk.Label(label="Dual ISO"), False, False, 0)
        self.dual = Gtk.ComboBoxText()
        for t in ("Off", "Preview", "Full processing"):
            self.dual.append_text(t)
        self.dual.set_active(self.cfg["dual_iso"])
        hb.pack_start(self.dual, False, False, 0)
        pg.attach(hb, 1, 1, 1, 1)
        note = Gtk.Label(xalign=0, wrap=True, max_width_chars=40)
        note.set_markup("<small>With every correction off, lossless MLV frames are passed through untouched "
                        "(fast pass): least CPU, best for slow PCs.</small>")
        pg.attach(note, 1, 2, 1, 2)

        self.auto_mount = Gtk.CheckButton(label="Mount automatically when I sign in", active=self.cfg["auto_mount"])
        self.auto_mount.connect("toggled", lambda *_: self.save_settings())
        outer.pack_start(self.auto_mount, False, False, 0)
        self.dual.set_tooltip_text("Detects 2-row and 4-row ISO groups and changing row phase. "
                                   "Full processing uses edge-directed interpolation to reduce moiré.")
        self.resolve_naming.set_tooltip_text("Untick for Windows simple naming: CLIP/CLIP_000000.dng. "
                                             "Changing naming requires relinking existing Resolve projects.")
        self.status = Gtk.Label(xalign=0, wrap=True)
        outer.pack_start(self.status, False, False, 0)

        btns = Gtk.Box(spacing=8)
        outer.pack_start(btns, False, False, 0)
        self.mount_btn = Gtk.Button(label="Mount for Resolve")
        self.mount_btn.connect("clicked", self.on_mount)
        self.unmount_btn = Gtk.Button(label="Unmount")
        self.unmount_btn.connect("clicked", self.on_unmount)
        self.open_btn = Gtk.Button(label="Open Folder")
        self.open_btn.connect("clicked", self.on_open)
        self.scripts_btn = Gtk.Button(label="Install Resolve Scripts")
        self.scripts_btn.connect("clicked", self.on_install_scripts)
        self.log_btn = Gtk.Button(label="Show Log")
        self.log_btn.connect("clicked", self.on_show_log)
        close = Gtk.Button(label="Close")
        close.connect("clicked", lambda *_: self.close())
        for w in (self.mount_btn, self.unmount_btn, self.open_btn, self.scripts_btn, self.log_btn):
            btns.pack_start(w, False, False, 0)
        btns.pack_end(close, False, False, 0)

        exp = Gtk.Expander(label="Log")
        exp.set_expanded(True)
        sw = Gtk.ScrolledWindow(vexpand=True)
        sw.set_min_content_height(140)
        self.logview = Gtk.TextView(editable=False, monospace=True, wrap_mode=Gtk.WrapMode.WORD_CHAR)
        sw.add(self.logview)
        exp.add(sw)
        outer.pack_start(exp, True, True, 0)
        self.log_scroller = sw

        self.connect("delete-event", self.on_delete)
        self._log_pos = 0
        self.indexing = False
        try:
            self._log_pos = os.path.getsize(LOG)   # show only what happens from now on
        except OSError:
            pass
        self.refresh()
        GLib.timeout_add(1000, self.tick)

    # ---------------------------------------------------------------- settings
    def load_settings(self):
        try:
            with open(SETTINGS) as f:
                self.cfg.update(json.load(f))
        except (OSError, ValueError):
            pass

    def save_settings(self):
        self.cfg.update({
            "source": self.source.get_text(),
            "mountpoint": self.mountpoint.get_text().strip(),
            "prefetch": int(self.prefetch.get_value()),
            "fps": self.fps.get_text().strip(),
            "white": self.white.get_text().strip(),
            "resolve_naming": self.resolve_naming.get_active(),
            "bad_pixels": self.bad_pixels.get_active(),
            "stripes": self.stripes.get_active(),
            "fix_edges": self.fix_edges.get_active(),
            "chroma": [0, 2, 3][max(0, self.chroma.get_active())],
            "dual_iso": max(0, self.dual.get_active()),
            "auto_mount": self.auto_mount.get_active(),
        })
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(SETTINGS, "w") as f:
            json.dump(self.cfg, f, indent=2)
        set_autostart(self.cfg["auto_mount"])
        with open(MOUNTPOINT_FILE, "w") as f:
            f.write(os.path.realpath(os.path.expanduser(self.cfg["mountpoint"])) + "\n")

    # ---------------------------------------------------------------- ui helpers
    def append_log(self, text):
        buf = self.logview.get_buffer()
        buf.insert(buf.get_end_iter(), text)
        adj = self.log_scroller.get_vadjustment()
        GLib.idle_add(lambda: adj.set_value(adj.get_upper()))

    def set_status(self, text):
        self.status.set_text("Status: " + text)

    def message(self, kind, text, secondary=None, buttons=Gtk.ButtonsType.OK):
        d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=kind, buttons=buttons, text=text)
        if secondary:
            d.format_secondary_text(secondary)
        r = d.run()
        d.destroy()
        return r

    def mp(self):
        return os.path.realpath(os.path.expanduser(self.mountpoint.get_text().strip() or DEFAULTS["mountpoint"]))

    def refresh(self):
        backend = find_backend()
        if backend:
            self.backend_label.set_markup("<span foreground='#2e7d32'>Backend: installed</span>  <small>%s</small>"
                                          % GLib.markup_escape_text(backend))
        else:
            self.backend_label.set_markup("<span foreground='#c62828'>Backend: not installed / incomplete</span>")
        is_mounted = mounted_at(self.mp())
        self.mount_btn.set_label("Remount with these settings" if is_mounted else "Mount for Resolve")
        self.mount_btn.set_sensitive(bool(backend) and not self.busy)
        self.unmount_btn.set_sensitive(is_mounted and not self.busy)
        self.install_btn.set_sensitive(not self.busy)
        for widget in (self.source, self.mountpoint, self.prefetch, self.fps, self.white,
                       self.resolve_naming, self.bad_pixels, self.stripes, self.fix_edges,
                       self.chroma, self.dual):
            widget.set_sensitive(not self.busy)
        if not self.busy:
            if not backend:
                self.set_status("install / repair the backend first")
            elif is_mounted:
                try:
                    n = len([d for d in os.listdir(self.mp()) if not d.startswith(".")])
                except OSError:
                    n = 0
                if self.indexing:
                    self.set_status("mounted at %s (%d clip%s) - indexing clips in the background. Wait for "
                                    "'all clips ready' in the log before importing into Resolve (only slow the "
                                    "first time; later mounts reuse the saved index)."
                                    % (self.mp(), n, "" if n == 1 else "s"))
                else:
                    self.set_status("mounted at %s (%d clip%s), all clips ready. In Resolve, add this folder in "
                                    "the Media page, or run Workspace > Scripts > MLV Resolve FS - Import and Sync "
                                    "Mounted Clips. Don't unmount while Resolve is open."
                                    % (self.mp(), n, "" if n == 1 else "s"))
            else:
                self.set_status("ready")

    def tick(self):
        self.poll_mount()
        try:
            if os.path.getsize(LOG) < self._log_pos:
                self._log_pos = 0
            with open(LOG) as f:
                f.seek(self._log_pos)
                new = f.read()
                self._log_pos = f.tell()
            if new:
                self.append_log(new)
                if "all clips ready" in new:
                    self.indexing = False
        except OSError:
            pass
        self.refresh()
        return True

    # ---------------------------------------------------------------- actions
    def on_browse(self, _b, entry, title):
        d = Gtk.FileChooserDialog(title=title, transient_for=self, action=Gtk.FileChooserAction.SELECT_FOLDER)
        d.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, "Select", Gtk.ResponseType.OK)
        cur = os.path.expanduser(entry.get_text())
        if os.path.isdir(cur):
            d.set_current_folder(cur)
        if d.run() == Gtk.ResponseType.OK:
            entry.set_text(d.get_filename())
        d.destroy()

    def backend_args(self):
        args = []
        if not self.resolve_naming.get_active():
            args.append("--plain-naming")
        if self.bad_pixels.get_active():
            args.append("--bad-pixels")
        if self.stripes.get_active():
            args.append("--stripes")
        if self.fix_edges.get_active():
            args.append("--fix-edges")
        ch = [0, 2, 3][max(0, self.chroma.get_active())]
        if ch:
            args.append("--chroma=%d" % ch)
        di = max(0, self.dual.get_active())
        if di:
            args.append("--dual-iso=%d" % di)
        args.append("--prefetch=%d" % int(self.prefetch.get_value()))
        fps = self.fps.get_text().strip().replace(",", ".")
        if fps:
            try:
                v = float(fps)
                if not 1 <= v <= 240:
                    raise ValueError
                args.append("--fps=%s" % fps)
            except ValueError:
                raise ValueError("FPS override must be a number such as 23.976, 24 or 25.")
        white = self.white.get_text().strip()
        if white:
            if not white.isdigit():
                raise ValueError("White level must be a whole number, or empty for automatic.")
            args.append("--white=%s" % white)
        return args

    def do_unmount(self, lazy=False):
        tool = shutil.which("fusermount3") or shutil.which("fusermount") or "fusermount3"
        r = subprocess.run([tool, "-uz" if lazy else "-u", self.mp()], capture_output=True, text=True)
        return r.returncode == 0, (r.stderr or r.stdout).strip()

    def on_mount(self, _b):
        if self.busy:
            return
        if os.geteuid() == 0:
            self.message(Gtk.MessageType.ERROR, "Start MLV Resolve FS as your normal user, without sudo.")
            return
        backend = find_backend()
        if not backend:
            self.message(Gtk.MessageType.ERROR, "Install / repair the backend first.")
            return
        src_text = self.source.get_text()
        src = source_path(src_text)
        mp = self.mp()
        try:
            args = self.backend_args()
        except ValueError as e:
            self.message(Gtk.MessageType.ERROR, str(e))
            return
        if not src:
            self.message(Gtk.MessageType.ERROR, "The MLV source folder was not found.", explain_missing(src_text))
            return
        if mp == src or mp.startswith(src + os.sep):
            self.message(Gtk.MessageType.ERROR, "The mount point must not be inside the source folder.")
            return
        if mounted_at(mp):
            if not self.confirm_resolve_unmount("Remount"):
                return
            ok, err = self.do_unmount()
            if not ok:
                self.message(Gtk.MessageType.WARNING, "Could not unmount to apply the new settings.",
                             "Resolve is probably still reading the clips. Close the project (or quit Resolve) "
                             "and try again.\n\n" + err)
                return
            time.sleep(0.3)
        os.makedirs(mp, exist_ok=True)
        if os.listdir(mp):
            self.message(Gtk.MessageType.ERROR, "The mount point folder is not empty.",
                         "Choose an empty folder (default: ~/MLV_Resolve).")
            return
        self.save_settings()
        os.makedirs(STATE_DIR, exist_ok=True)
        cmd = [backend] + args + ["-f", "--log=" + LOG, src, mp]
        self.indexing = True
        self.append_log("$ " + " ".join(cmd) + "\n")
        try:
            # A new session and real files for output let the mount outlive this window.
            with open(STDERR_LOG, "w") as err:
                proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=err, stderr=err,
                                        start_new_session=True, close_fds=True)
        except OSError as e:
            self.message(Gtk.MessageType.ERROR, "Could not start the backend.", str(e))
            return
        self.pending = (proc, mp, time.monotonic())
        self.busy = True
        self.refresh()
        self.set_status("mounting… waiting up to 90 seconds; you can close this window safely")

    def poll_mount(self):
        if not self.pending:
            return
        proc, mp, started = self.pending
        code = proc.poll()
        if code is not None:
            self.pending = None
            self.busy = False
            self.indexing = False
            try:
                with open(STDERR_LOG) as f:
                    detail = f.read()[-8000:]
            except OSError:
                detail = "See Show Log for details."
            self.append_log(detail + "\n")
            self.message(Gtk.MessageType.ERROR, "Backend stopped (exit %s)." % code, detail)
        elif mounted_at(mp):
            self.pending = None
            self.busy = False
        elif time.monotonic() - started >= 90:
            # Keep supervising a slow startup: never kill it or start a duplicate.
            self.set_status("mount is taking longer than 90 seconds; still waiting. See Show Log.")

    def on_show_log(self, _b):
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(LOG, "a"):
            pass
        subprocess.Popen(["xdg-open", LOG])

    def auto_mount_when_ready(self):
        if not self.cfg.get("auto_mount") or mounted_at(self.mp()):
            return False
        if source_path(self.source.get_text()):
            self.on_mount(None)
            return False
        if time.monotonic() < self.auto_deadline:
            self.set_status("waiting for the saved source folder to become available…")
            return True
        self.set_status("automatic mount skipped: source folder unavailable; mount manually when ready")
        return False

    def confirm_resolve_unmount(self, action):
        if not resolve_running():
            return True
        r = self.message(Gtk.MessageType.WARNING, "DaVinci Resolve is open.",
                         "%s takes the virtual folder away for a moment. Resolve then marks every clip from "
                         "it as offline (red clips, no sound) and does not notice when it comes back.\n\n"
                         "Best: close the Resolve project first. Continue anyway?\n\n%s" % (action, RELINK_HELP),
                         buttons=Gtk.ButtonsType.YES_NO)
        return r == Gtk.ResponseType.YES

    def on_unmount(self, _b):
        if not self.confirm_resolve_unmount("Unmounting"):
            return
        ok, err = self.do_unmount()
        if not ok:
            r = self.message(Gtk.MessageType.QUESTION, "The mount is busy.",
                             "Resolve (or a file manager) still has clips open. Detach it anyway? The folder "
                             "disappears now and is released once the files are closed.\n\n" + err,
                             buttons=Gtk.ButtonsType.YES_NO)
            if r == Gtk.ResponseType.YES:
                ok, err = self.do_unmount(lazy=True)
                if not ok:
                    self.message(Gtk.MessageType.ERROR, "Unmount failed.", err)
        self.refresh()

    def on_open(self, _b):
        target = self.mp() if mounted_at(self.mp()) else os.path.expanduser(self.source.get_text())
        subprocess.Popen(["xdg-open", target])

    def on_install_scripts(self, _b):
        src = find_resolve_scripts()
        if not src:
            self.message(Gtk.MessageType.ERROR, "Resolve scripts not found next to the app.")
            return
        self.save_settings()
        os.makedirs(RESOLVE_SCRIPT_DIR, exist_ok=True)
        names = []
        for n in sorted(os.listdir(src)):
            if n.endswith(".lua"):
                shutil.copy2(os.path.join(src, n), os.path.join(RESOLVE_SCRIPT_DIR, n))
                names.append(n[:-4])
        self.message(Gtk.MessageType.INFO, "Resolve scripts installed.",
                     "Restart Resolve, then use Workspace > Scripts:\n  " + "\n  ".join(names) +
                     "\n\nInstalled to " + RESOLVE_SCRIPT_DIR)

    def on_install_backend(self, _b):
        src = find_backend_source()
        if not src:
            self.message(Gtk.MessageType.ERROR, "Backend source not found.",
                         "Re-run install.sh from the MLV Resolve FS folder.")
            return
        self.busy = True
        self.refresh()
        self.set_status("installing backend…")
        threading.Thread(target=self.install_worker, args=(src,), daemon=True).start()

    def install_worker(self, src):
        def log(t):
            GLib.idle_add(self.append_log, t)

        def run(cmd, cwd=None):
            log("$ " + " ".join(cmd) + "\n")
            p = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in p.stdout:
                log(line)
            return p.wait()

        ok = True
        missing = [d for d in APT_DEPS
                   if subprocess.run(["dpkg-query", "-W", "-f=${Status}", d], capture_output=True,
                                     text=True).stdout.find("install ok installed") < 0]
        if missing:
            log("Installing packages: %s\n" % " ".join(missing))
            ok = run(["pkexec", "apt-get", "install", "-y"] + missing) == 0
            if not ok:
                log("Package installation failed or was cancelled. You can run:\n  sudo apt install %s\n"
                    % " ".join(APT_DEPS))
        else:
            log("Build packages already installed.\n")
        if ok:
            ok = run(["make", "clean"], cwd=src) == 0 and run(["make", "-j2"], cwd=src) == 0
        if ok:
            dest = os.path.join(SHARE, "bin")
            os.makedirs(dest, exist_ok=True)
            shutil.copy2(os.path.join(src, "mlvresolvefs"), os.path.join(dest, "mlvresolvefs"))
            log("Backend installed to %s\n" % dest)
        GLib.idle_add(self.install_done, ok)

    def install_done(self, ok):
        self.busy = False
        self.refresh()
        if ok:
            self.set_status("backend installed")
        else:
            self.message(Gtk.MessageType.ERROR, "Backend installation failed.", "See the log for details.")

    def on_delete(self, *_):
        self.save_settings()
        if mounted_at(self.mp()):
            r = self.message(Gtk.MessageType.QUESTION, "Keep the footage mounted?",
                             "Yes: the virtual clips stay available to Resolve after this window closes.\n"
                             "No: unmount now.", buttons=Gtk.ButtonsType.YES_NO)
            if r == Gtk.ResponseType.NO:
                ok, err = self.do_unmount()
                if not ok:
                    self.message(Gtk.MessageType.WARNING, "Could not unmount (busy). It stays mounted.", err)
        Gtk.main_quit()
        return False


def main():
    win = Window()
    win.show_all()
    if "--automount" in sys.argv:
        win.auto_deadline = time.monotonic() + 90
        GLib.timeout_add(1000, win.auto_mount_when_ready)
    Gtk.main()


if __name__ == "__main__":
    main()
