/*
 * MLV Resolve FS - mount Magic Lantern MLV files as virtual CinemaDNG folders.
 *
 *   mlvresolvefs [options] SOURCE_DIR MOUNTPOINT
 *
 * Each MLV (with its .M00/.M01... spanned chunks) appears as a folder of DNG frames plus a
 * broadcast WAV with matching timecode. Nothing is written to disk.
 *
 * Builds against libfuse3 (Linux, default), libfuse 2.x (-DMRFS_FUSE2) or WinFsp's
 * Cygwin FUSE 2.8 layer (cygfuse, Windows).
 */
#ifndef FUSE_USE_VERSION
# if defined(MRFS_FUSE2) || defined(__CYGWIN__)
#  define FUSE_USE_VERSION 26
# else
#  define FUSE_USE_VERSION 31
# endif
#endif
#define _GNU_SOURCE
#if FUSE_USE_VERSION >= 30
# include <fuse3/fuse.h>
# define FILL(buf, name, st) fill(buf, name, st, 0, 0)
#else
# include <fuse.h>
# define FILL(buf, name, st) fill(buf, name, st, 0)
#endif
#include <stdio.h>
#include <strings.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <ctype.h>
#include <sys/stat.h>
#include <pthread.h>
#include <limits.h>
#include "common.h"

#ifndef O_BINARY
# define O_BINARY 0
#endif
#if defined(__CYGWIN__) || defined(_WIN32)
# define MRFS_WINDOWS 1
# define PLATFORM "Windows"
#else
# define MRFS_WINDOWS 0
# define PLATFORM "Linux"
#endif

options_t g_opt = { .resolve_naming = 1, .prefetch = 8, .fastpass = 1, .warmup = 1 };

static pthread_mutex_t log_lock = PTHREAD_MUTEX_INITIALIZER;
void mrfs_log(const char *fmt, ...)
{
    pthread_mutex_lock(&log_lock);
    FILE *f = g_opt.logfile ? fopen(g_opt.logfile, "a") : stderr;
    if (!f) f = stderr;
    time_t t = time(NULL); struct tm tm; localtime_r(&t, &tm);
    fprintf(f, "[%02d:%02d:%02d] ", tm.tm_hour, tm.tm_min, tm.tm_sec);
    va_list ap; va_start(ap, fmt); vfprintf(f, fmt, ap); va_end(ap);
    if (f != stderr) fclose(f); else fflush(f);
    pthread_mutex_unlock(&log_lock);
}

/* ------------------------------------------------------------------ clips */

static clip_t **g_clips; static int g_nclips, g_capclips;
static pthread_rwlock_t g_clips_lock = PTHREAD_RWLOCK_INITIALIZER;
static time_t g_last_scan;
static time_t g_start_time;

static int has_ext(const char *name, const char *ext)
{
    size_t n = strlen(name), e = strlen(ext);
    return n > e && strcasecmp(name + n - e, ext) == 0;
}

static clip_t *find_clip_by_path(const char *path)
{
    for (int i = 0; i < g_nclips; i++)
        if (!strcmp(g_clips[i]->paths[0], path)) return g_clips[i];
    return NULL;
}

static int name_taken(const char *dirname)
{
    for (int i = 0; i < g_nclips; i++) if (!strcmp(g_clips[i]->dirname, dirname)) return 1;
    return 0;
}

static void read_rtci_quick(const char *path, mlv_rtci_hdr_t *rt, int *have)
{
    *have = 0;
    int fd = open(path, O_RDONLY | O_BINARY);
    if (fd < 0) return;
    uint64_t pos = 0;
    for (int n = 0; n < 64; n++) {
        mlv_hdr_t h;
        if (pread(fd, &h, sizeof(h), (off_t)pos) != sizeof(h) || h.blockSize < 16) break;
        if (!memcmp(h.blockType, "RTCI", 4)) {
            if (pread(fd, rt, sizeof(*rt), (off_t)pos) == sizeof(*rt)) *have = 1;
            break;
        }
        if (!memcmp(h.blockType, "VIDF", 4)) break;
        pos += h.blockSize;
    }
    close(fd);
}

static void add_clip(const char *dir, const char *fname)
{
    char path[PATH_MAX];
    snprintf(path, sizeof(path), "%s/%s", dir, fname);
    if (find_clip_by_path(path)) return;

    clip_t *c = calloc(1, sizeof(clip_t));
    pthread_mutex_init(&c->lock, NULL);
    size_t bl = strlen(fname) - 4;
    if (bl >= sizeof(c->base)) bl = sizeof(c->base) - 1;
    memcpy(c->base, fname, bl); c->base[bl] = 0;

    /* spanned chunks: NAME.M00 .. NAME.M99 */
    c->paths = calloc(101, sizeof(char *));
    c->paths[c->nfiles++] = strdup(path);
    for (int k = 0; k < 100; k++) {
        char p2[PATH_MAX]; struct stat st;
        snprintf(p2, sizeof(p2), "%s/%s.M%02d", dir, c->base, k);
        if (stat(p2, &st) != 0) {
            snprintf(p2, sizeof(p2), "%s/%s.m%02d", dir, c->base, k);
            if (stat(p2, &st) != 0) break;
        }
        c->paths[c->nfiles++] = strdup(p2);
    }
    c->fds = malloc(c->nfiles * sizeof(int));
    for (int k = 0; k < c->nfiles; k++) c->fds[k] = -1;
    struct stat st; stat(path, &st); c->mtime = st.st_mtime;

    char name[512];
    if (g_opt.resolve_naming) {
        mlv_rtci_hdr_t rt; int have;
        read_rtci_quick(path, &rt, &have);
        int Y, M, D;
        if (have) { Y = rt.tm_year + 1900; M = rt.tm_mon + 1; D = rt.tm_mday; }
        else { struct tm tm; localtime_r(&c->mtime, &tm); Y = tm.tm_year + 1900; M = tm.tm_mon + 1; D = tm.tm_mday; }
        snprintf(name, sizeof(name), "%sMLV_1_%04d-%02d-%02d_0001_C0000", c->base, Y, M, D);
    } else {
        snprintf(name, sizeof(name), "%s", c->base);
    }
    snprintf(c->dirname, sizeof(c->dirname), "%s", name);
    for (int k = 2; name_taken(c->dirname); k++)
        snprintf(c->dirname, sizeof(c->dirname), "%s_%d", name, k);

    if (g_nclips == g_capclips) {
        g_capclips = g_capclips ? g_capclips * 2 : 64;
        g_clips = realloc(g_clips, g_capclips * sizeof(clip_t *));
    }
    g_clips[g_nclips++] = c;
}

typedef struct { char *dir, *name; } found_t;

static int cmp_found(const void *a, const void *b)
{
    const found_t *x = a, *y = b;
    int r = strcmp(x->dir, y->dir);
    return r ? r : strcmp(x->name, y->name);
}

static int skip_dir(const char *name)
{
    return name[0] == '.' || name[0] == '$' || !strcasecmp(name, "System Volume Information") ||
           has_ext(name, ".MLD") || !strcasecmp(name, "node_modules");
}

/* Walk the source tree (3 levels) collecting *.MLV files. No lock is held here, so a slow
 * disk never stalls file system requests for clips that are already known. */
static void scan_dir(const char *dir, int depth, found_t **out, int *n, int *cap, int *budget)
{
    DIR *d = opendir(dir);
    if (!d) return;
    struct dirent *e;
    char **subs = NULL; int nsub = 0;
    while ((e = readdir(d)) && (*budget)-- > 0) {
        const char *nm = e->d_name;
        if (nm[0] == '.') continue;
        int is_mlv = has_ext(nm, ".mlv");
        int maybe_dir = 1;
#ifdef DT_DIR
        if (e->d_type == DT_REG) maybe_dir = 0;
        else if (e->d_type == DT_DIR) is_mlv = 0;
#endif
        if (!is_mlv && (!maybe_dir || depth >= 3 || skip_dir(nm))) continue;
        char p[PATH_MAX]; struct stat st;
        snprintf(p, sizeof(p), "%s/%s", dir, nm);
        if (stat(p, &st)) continue;
        if (S_ISDIR(st.st_mode)) {
            if (depth < 3 && !skip_dir(nm)) {
                subs = realloc(subs, (nsub + 1) * sizeof(char *)); subs[nsub++] = strdup(p);
            }
        } else if (S_ISREG(st.st_mode) && is_mlv) {
            if (*n == *cap) { *cap = *cap ? *cap * 2 : 64; *out = realloc(*out, *cap * sizeof(found_t)); }
            (*out)[*n].dir = strdup(dir); (*out)[*n].name = strdup(nm); (*n)++;
        }
    }
    closedir(d);
    for (int i = 0; i < nsub; i++) { scan_dir(subs[i], depth + 1, out, n, cap, budget); free(subs[i]); }
    free(subs);
}

static pthread_mutex_t g_scan_lock = PTHREAD_MUTEX_INITIALIZER;

static void rescan(int force)
{
    time_t now = time(NULL);
    if (!force && now - g_last_scan < 5) return;
    if (pthread_mutex_trylock(&g_scan_lock)) {          /* another thread is scanning */
        if (!force) return;
        pthread_mutex_lock(&g_scan_lock);
    }
    g_last_scan = now;
    found_t *f = NULL; int n = 0, cap = 0, budget = 200000;
    scan_dir(g_opt.source, 0, &f, &n, &cap, &budget);
    if (n) qsort(f, n, sizeof(found_t), cmp_found);
    pthread_rwlock_wrlock(&g_clips_lock);
    for (int i = 0; i < n; i++) add_clip(f[i].dir, f[i].name);
    pthread_rwlock_unlock(&g_clips_lock);
    for (int i = 0; i < n; i++) { free(f[i].dir); free(f[i].name); }
    free(f);
    g_last_scan = time(NULL);
    pthread_mutex_unlock(&g_scan_lock);
}

static clip_t *clip_by_dirname(const char *name, size_t len)
{
    clip_t *r = NULL;
    pthread_rwlock_rdlock(&g_clips_lock);
    for (int i = 0; i < g_nclips; i++)
        if (strlen(g_clips[i]->dirname) == len && !strncasecmp(g_clips[i]->dirname, name, len)) { r = g_clips[i]; break; }
    pthread_rwlock_unlock(&g_clips_lock);
    return r;
}

/* path parsing: /DIR, /DIR/DIR_000123.dng, /DIR/DIR.wav */
enum { P_ROOT, P_DIR, P_DNG, P_WAV, P_NONE };
typedef struct { int kind; clip_t *c; uint32_t frame; } vpath_t;

/* Names Windows Explorer and other tools look for in every folder. Never worth a rescan. */
static int looks_like_probe(const char *p, size_t len)
{
    static const char *names[] = { "desktop.ini", "autorun.inf", "thumbs.db", "folder.jpg",
                                   "folder.gif", "albumart", "$recycle.bin", "system volume information" };
    for (size_t i = 0; i < sizeof(names) / sizeof(names[0]); i++)
        if (len >= strlen(names[i]) && !strncasecmp(p, names[i], strlen(names[i]))) return 1;
    return len && p[0] == '.';
}

static vpath_t parse_path(const char *path)
{
    vpath_t v = { P_NONE, NULL, 0 };
    if (!strcmp(path, "/")) { v.kind = P_ROOT; return v; }
    const char *p = path + 1;
    const char *slash = strchr(p, '/');
    size_t dl = slash ? (size_t)(slash - p) : strlen(p);
    v.c = clip_by_dirname(p, dl);
    if (!v.c && !looks_like_probe(p, dl)) { rescan(0); v.c = clip_by_dirname(p, dl); }
    if (!v.c) return v;
    if (!slash || !slash[1]) { v.kind = P_DIR; return v; }
    const char *f = slash + 1;
    if (strncasecmp(f, v.c->dirname, dl)) return v;
    const char *rest = f + dl;
    if (!strcasecmp(rest, ".wav")) { v.kind = P_WAV; return v; }
    if (rest[0] == '_' && strlen(rest) == 11 && !strcasecmp(rest + 7, ".dng")) {
        for (int i = 1; i <= 6; i++) if (!isdigit((unsigned char)rest[i])) return v;
        v.frame = (uint32_t)atoi(rest + 1);
        v.kind = P_DNG;
    }
    return v;
}

/* ------------------------------------------------------------------ frame cache */

typedef struct {
    clip_t  *c;
    uint32_t frame;
    uint8_t *data;
    size_t   size;
    int      state;        /* 0 empty, 1 loading, 2 ready, 3 failed */
    int      refs;
    uint64_t lru;
} centry_t;

static centry_t *g_cache; static int g_ncache;
static pthread_mutex_t g_cache_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t g_cache_cv = PTHREAD_COND_INITIALIZER;
static uint64_t g_tick;

static int produce_frame(clip_t *c, uint32_t frame, uint8_t **data, size_t *size)
{
    if (c->fastpass) {
        frame_ref_t *fr = &c->frames[frame];
        uint8_t *b = malloc(fr->size);
        if (!b) return -ENOMEM;
        int r = clip_read(c, fr->file, fr->off, b, fr->size);
        if (r) { free(b); return r; }
        *data = b; *size = fr->size;
        return 0;
    }
    size_t n = (size_t)c->width * c->height;
    uint16_t *img = malloc(n * 2);
    if (!img) return -ENOMEM;
    int r = clip_load_frame_raw(c, frame, img);
    if (r && r != -EIO) { free(img); return r; }
    if (g_opt.fix_edges && (c->junk_top || c->junk_bottom)) repair_edges(c, img);
    if (needs_processing()) process_frame(c, img);
    *data = (uint8_t *)img; *size = n * 2;
    return 0;
}

/* returns a referenced entry (release with cache_put) or NULL. if !wait and the frame is
 * already present or being loaded, returns NULL immediately. */
static centry_t *cache_get(clip_t *c, uint32_t frame, int wait)
{
    pthread_mutex_lock(&g_cache_lock);
    for (;;) {
        centry_t *hit = NULL;
        for (int i = 0; i < g_ncache; i++)
            if (g_cache[i].state && g_cache[i].c == c && g_cache[i].frame == frame) { hit = &g_cache[i]; break; }
        if (hit) {
            if (!wait) { pthread_mutex_unlock(&g_cache_lock); return NULL; }
            if (hit->state == 1) { pthread_cond_wait(&g_cache_cv, &g_cache_lock); continue; }
            if (hit->state == 3) { hit->state = 0; continue; }   /* retry a failed load */
            hit->refs++; hit->lru = ++g_tick;
            pthread_mutex_unlock(&g_cache_lock);
            return hit;
        }
        centry_t *victim = NULL;
        for (int i = 0; i < g_ncache; i++) {
            centry_t *e = &g_cache[i];
            if (e->state == 1 || e->refs) continue;
            if (!victim || e->state == 0 || (victim->state != 0 && e->lru < victim->lru)) victim = e;
            if (e->state == 0) break;
        }
        if (!victim) {
            if (!wait) { pthread_mutex_unlock(&g_cache_lock); return NULL; }
            pthread_cond_wait(&g_cache_cv, &g_cache_lock);
            continue;
        }
        free(victim->data);
        victim->data = NULL; victim->size = 0;
        victim->c = c; victim->frame = frame; victim->state = 1; victim->refs = 1; victim->lru = ++g_tick;
        pthread_mutex_unlock(&g_cache_lock);

        uint8_t *data = NULL; size_t size = 0;
        int r = produce_frame(c, frame, &data, &size);

        pthread_mutex_lock(&g_cache_lock);
        victim->data = data; victim->size = size;
        victim->state = r ? 3 : 2;
        pthread_cond_broadcast(&g_cache_cv);
        if (r) { victim->refs--; pthread_mutex_unlock(&g_cache_lock); return NULL; }
        pthread_mutex_unlock(&g_cache_lock);
        return victim;
    }
}

static void cache_put(centry_t *e)
{
    pthread_mutex_lock(&g_cache_lock);
    e->refs--;
    pthread_cond_broadcast(&g_cache_cv);
    pthread_mutex_unlock(&g_cache_lock);
}

/* ------------------------------------------------------------------ prefetch */

typedef struct { clip_t *c; uint32_t frame; } job_t;
#define QCAP 256
static job_t g_q[QCAP]; static int g_qh, g_qn;
static pthread_mutex_t g_q_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t g_q_cv = PTHREAD_COND_INITIALIZER;
static int g_stop;

static void prefetch_request(clip_t *c, uint32_t frame)
{
    if (g_opt.prefetch <= 0) return;
    pthread_mutex_lock(&g_q_lock);
    for (int k = 1; k <= g_opt.prefetch; k++) {
        uint32_t f = frame + k;
        if (f >= c->nframes) break;
        int dup = 0;
        for (int i = 0; i < g_qn; i++) {
            job_t *j = &g_q[(g_qh + i) % QCAP];
            if (j->c == c && j->frame == f) { dup = 1; break; }
        }
        if (dup) continue;
        if (g_qn == QCAP) { g_qh = (g_qh + 1) % QCAP; g_qn--; }   /* drop the oldest */
        g_q[(g_qh + g_qn) % QCAP] = (job_t){ c, f };
        g_qn++;
    }
    pthread_cond_broadcast(&g_q_cv);
    pthread_mutex_unlock(&g_q_lock);
}

static void *prefetch_worker(void *arg)
{
    (void)arg;
    for (;;) {
        pthread_mutex_lock(&g_q_lock);
        while (!g_qn && !g_stop) pthread_cond_wait(&g_q_cv, &g_q_lock);
        if (g_stop) { pthread_mutex_unlock(&g_q_lock); return NULL; }
        job_t j = g_q[g_qh]; g_qh = (g_qh + 1) % QCAP; g_qn--;
        pthread_mutex_unlock(&g_q_lock);
        centry_t *e = cache_get(j.c, j.frame, 0);
        if (e) cache_put(e);
    }
}

/* ------------------------------------------------------------------ FUSE ops */

/* Index every clip in the background right after mounting (from the cache when possible),
 * so DaVinci Resolve never has to wait for a first scan when it opens a folder. */
static void *warmup_worker(void *arg)
{
    (void)arg;
    struct timespec t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    int n = 0;
    for (int i = 0; ; i++) {
        clip_t *c = NULL;
        pthread_rwlock_rdlock(&g_clips_lock);
        if (i < g_nclips) c = g_clips[i];
        pthread_rwlock_unlock(&g_clips_lock);
        if (!c) break;
        if (g_stop) return NULL;
        if (!c->indexed && !c->index_failed) { clip_index(c); n++; }
    }
    clock_gettime(CLOCK_MONOTONIC, &t1);
    mrfs_log("all clips ready (%d checked in the background in %.1f s)\n", n,
             (t1.tv_sec - t0.tv_sec) + (t1.tv_nsec - t0.tv_nsec) / 1e9);
    return NULL;
}

static void start_workers(void)
{
    int n = g_opt.threads;
    for (int i = 0; i < n; i++) {
        pthread_t t;
        pthread_create(&t, NULL, prefetch_worker, NULL);
        pthread_detach(t);
    }
    if (g_opt.warmup) {
        pthread_t t;
        pthread_create(&t, NULL, warmup_worker, NULL);
        pthread_detach(t);
    }
    mrfs_log("mounted %s on %s (%d clips, prefetch %d, %d worker threads, index cache %s)\n",
             g_opt.source, g_opt.mountpoint, g_nclips, g_opt.prefetch, n,
             g_opt.cache_dir ? g_opt.cache_dir : "off");
}

#if FUSE_USE_VERSION >= 30
static void *op_init(struct fuse_conn_info *conn, struct fuse_config *cfg)
{
    (void)conn;
    cfg->kernel_cache = 1;
    cfg->entry_timeout = 5;
    cfg->attr_timeout = 5;
    cfg->negative_timeout = 1;
    cfg->use_ino = 0;
    start_workers();
    return NULL;
}
#else
static void *op_init(struct fuse_conn_info *conn)
{
    (void)conn;
    start_workers();
    return NULL;
}
#endif

static void op_destroy(void *p)
{
    (void)p;
    pthread_mutex_lock(&g_q_lock); g_stop = 1; pthread_cond_broadcast(&g_q_cv); pthread_mutex_unlock(&g_q_lock);
    mrfs_log("unmounted %s\n", g_opt.mountpoint);
}

/* NLEs (DaVinci Resolve among them) sometimes open media read/write just to probe it, and
 * treat a refused open as "media offline". The files therefore carry owner-write permission
 * and read/write opens succeed; actual writes are refused. Nothing is ever written. */
#define FILE_MODE 0644
#define DIR_MODE  0755

static void fill_stat(struct stat *st, int kind, clip_t *c, uint32_t frame)
{
    memset(st, 0, sizeof(*st));
    st->st_uid = getuid(); st->st_gid = getgid();
    st->st_nlink = 1;
    switch (kind) {
    case P_ROOT:
        st->st_mode = S_IFDIR | DIR_MODE; st->st_nlink = 2; st->st_mtime = g_start_time;
        break;
    case P_DIR:
        st->st_mode = S_IFDIR | DIR_MODE; st->st_nlink = 2; st->st_mtime = c->mtime;
        break;
    case P_DNG:
        st->st_mode = S_IFREG | FILE_MODE; st->st_mtime = c->mtime;
        st->st_size = (off_t)dng_file_size(c, frame);
        break;
    case P_WAV:
        st->st_mode = S_IFREG | FILE_MODE; st->st_mtime = c->mtime;
        st->st_size = (off_t)wav_file_size(c);
        break;
    }
    st->st_atime = st->st_ctime = st->st_mtime;
#if !defined(__CYGWIN__)
    st->st_blksize = 65536;
#endif
    st->st_blocks = (st->st_size + 511) / 512;
}

static int do_getattr(const char *path, struct stat *st)
{
    vpath_t v = parse_path(path);
    switch (v.kind) {
    case P_ROOT:
    case P_DIR:
        fill_stat(st, v.kind, v.c, 0);
        return 0;
    case P_DNG:
        if (clip_index(v.c) || v.frame >= v.c->nframes) return -ENOENT;
        fill_stat(st, P_DNG, v.c, v.frame);
        return 0;
    case P_WAV:
        if (clip_index(v.c) || !wav_file_size(v.c)) return -ENOENT;
        fill_stat(st, P_WAV, v.c, 0);
        return 0;
    }
    return -ENOENT;
}

static int do_readdir(const char *path, void *buf, fuse_fill_dir_t fill)
{
    struct stat st;
    vpath_t v = parse_path(path);
    if (v.kind == P_ROOT) {
        rescan(0);
        fill_stat(&st, P_ROOT, NULL, 0);
        FILL(buf, ".", &st); FILL(buf, "..", &st);
        pthread_rwlock_rdlock(&g_clips_lock);
        for (int i = 0; i < g_nclips; i++) {
            if (g_clips[i]->index_failed) continue;
            fill_stat(&st, P_DIR, g_clips[i], 0);
            FILL(buf, g_clips[i]->dirname, &st);
        }
        pthread_rwlock_unlock(&g_clips_lock);
        return 0;
    }
    if (v.kind != P_DIR) return -ENOTDIR;
    if (clip_index(v.c)) return -EIO;
    fill_stat(&st, P_DIR, v.c, 0);
    FILL(buf, ".", &st); FILL(buf, "..", &st);
    char name[600];
    for (uint32_t i = 0; i < v.c->nframes; i++) {
        snprintf(name, sizeof(name), "%s_%06u.dng", v.c->dirname, i);
        fill_stat(&st, P_DNG, v.c, i);
        FILL(buf, name, &st);
    }
    if (wav_file_size(v.c)) {
        snprintf(name, sizeof(name), "%s.wav", v.c->dirname);
        fill_stat(&st, P_WAV, v.c, 0);
        FILL(buf, name, &st);
    }
    return 0;
}

#if FUSE_USE_VERSION >= 30
static int op_getattr(const char *path, struct stat *st, struct fuse_file_info *fi)
{ (void)fi; return do_getattr(path, st); }
static int op_readdir(const char *path, void *buf, fuse_fill_dir_t fill, off_t off,
                      struct fuse_file_info *fi, enum fuse_readdir_flags flags)
{ (void)off; (void)fi; (void)flags; return do_readdir(path, buf, fill); }
static int op_truncate(const char *path, off_t size, struct fuse_file_info *fi)
{ (void)path; (void)size; (void)fi; return -EACCES; }
#else
static int op_getattr(const char *path, struct stat *st) { return do_getattr(path, st); }
static int op_readdir(const char *path, void *buf, fuse_fill_dir_t fill, off_t off, struct fuse_file_info *fi)
{ (void)off; (void)fi; return do_readdir(path, buf, fill); }
static int op_truncate(const char *path, off_t size) { (void)path; (void)size; return -EACCES; }
#endif

static int op_open(const char *path, struct fuse_file_info *fi)
{
    if (fi->flags & O_TRUNC) return -EACCES;
    vpath_t v = parse_path(path);
    if (v.kind != P_DNG && v.kind != P_WAV) return -ENOENT;
    if (clip_index(v.c)) return -EIO;
    if (v.kind == P_DNG && v.frame >= v.c->nframes) return -ENOENT;
    vpath_t *h = malloc(sizeof(vpath_t));
    if (!h) return -ENOMEM;
    *h = v;
    fi->fh = (uint64_t)(uintptr_t)h;
    fi->keep_cache = 1;
    return 0;
}

static int op_write(const char *path, const char *buf, size_t size, off_t off, struct fuse_file_info *fi)
{ (void)path; (void)buf; (void)size; (void)off; (void)fi; return -EACCES; }

static int op_flush(const char *path, struct fuse_file_info *fi) { (void)path; (void)fi; return 0; }

static int op_release(const char *path, struct fuse_file_info *fi)
{
    (void)path;
    free((void *)(uintptr_t)fi->fh);
    return 0;
}

static int op_read(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *fi)
{
    (void)path;
    vpath_t *v = (vpath_t *)(uintptr_t)fi->fh;
    clip_t *c = v->c;
    if (v->kind == P_WAV) return wav_read(c, buf, size, (uint64_t)offset);

    uint64_t total = dng_file_size(c, v->frame);
    if (offset < 0 || (uint64_t)offset >= total) return 0;
    if ((uint64_t)offset + size > total) size = (size_t)(total - offset);
    size_t done = 0;
    if ((uint64_t)offset < c->dng_hdr_size) {
        uint8_t *hdr = malloc(c->dng_hdr_size);
        if (!hdr) return -ENOMEM;
        dng_patch_header(c, v->frame, hdr);
        size_t n = c->dng_hdr_size - (size_t)offset;
        if (n > size) n = size;
        memcpy(buf, hdr + offset, n);
        free(hdr);
        done = n;
    }
    if (done < size) {
        centry_t *e = cache_get(c, v->frame, 1);
        if (!e) return done ? (int)done : -EIO;
        uint64_t in = (uint64_t)offset + done - c->dng_hdr_size;
        size_t n = size - done;
        if (in < e->size) {
            size_t avail = e->size - (size_t)in;
            size_t m = n < avail ? n : avail;
            memcpy(buf + done, e->data + in, m);
            if (m < n) memset(buf + done + m, 0, n - m);
        } else memset(buf + done, 0, n);
        cache_put(e);
        done = size;
        if (in == 0 || (uint64_t)offset + size >= total) prefetch_request(c, v->frame);
    }
    return (int)done;
}

static int op_statfs(const char *path, struct statvfs *st)
{
    (void)path;
    memset(st, 0, sizeof(*st));
    st->f_bsize = 4096; st->f_frsize = 4096; st->f_namemax = 255;
    st->f_blocks = (fsblkcnt_t)(256ULL << 20);   /* report 1 TiB, nothing free: it's read-only */
    return 0;
}

static const struct fuse_operations ops = {
    .init = op_init, .destroy = op_destroy, .getattr = op_getattr, .readdir = op_readdir,
    .open = op_open, .release = op_release, .read = op_read, .statfs = op_statfs,
    .write = op_write, .truncate = op_truncate, .flush = op_flush,
};

/* ------------------------------------------------------------------ main */

static void usage(const char *p)
{
    fprintf(stderr,
        "MLV Resolve FS %s (" PLATFORM ")\n"
        "usage: %s [options] SOURCE_DIR MOUNTPOINT\n\n"
        "  --plain-naming       folder/frame names without the Resolve-friendly suffix\n"
        "  --bad-pixels         detect and fix hot/dead pixels\n"
        "  --stripes            vertical stripe correction\n"
        "  --chroma=N           chroma smoothing: 0 off, 2 (2x2) or 3 (3x3)\n"
        "  --dual-iso=N         0 off, 1 preview, 2 full merge\n"
        "  --prefetch=N         frames to read ahead (default 8)\n"
        "  --threads=N          read-ahead worker threads (default: CPU count, max 8)\n"
        "  --fps=F              override the frame rate stored in the MLV\n"
        "  --white=N            force the white level\n"
        "  --fix-edges          repair junk rows at the frame edges (forces decoding)\n"
        "  --no-fastpass        always decode lossless frames (fast pass is used when possible)\n"
        "  --log=FILE           append log messages to FILE\n"
        "  --cache-dir=DIR      where clip indexes are kept (default ~/.cache/mlvresolvefs)\n"
        "  --no-cache           do not keep clip indexes between mounts\n"
        "  --no-warmup          do not index all clips in the background after mounting\n"
        "  -f                   stay in the foreground\n"
        "  -v                   verbose\n"
        "  -o OPT               extra FUSE mount options\n"
        "\nOn Windows MOUNTPOINT is a drive letter such as R: (WinFsp).\n", MRFS_VERSION, p);
}

int main(int argc, char **argv)
{
    char *fargv[64]; int fargc = 0;
    fargv[fargc++] = argv[0];
    char *pos[2]; int npos = 0;
    int foreground = 0;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { usage(argv[0]); return 0; }
        else if (!strcmp(a, "--version")) { printf("mlvresolvefs %s (%s)\n", MRFS_VERSION, PLATFORM); return 0; }
        else if (!strcmp(a, "--plain-naming")) g_opt.resolve_naming = 0;
        else if (!strcmp(a, "--resolve-naming")) g_opt.resolve_naming = 1;
        else if (!strcmp(a, "--bad-pixels")) g_opt.badpix = 1;
        else if (!strcmp(a, "--stripes")) g_opt.stripes = 1;
        else if (!strncmp(a, "--chroma=", 9)) g_opt.chroma = atoi(a + 9);
        else if (!strncmp(a, "--dual-iso=", 11)) g_opt.dualiso = atoi(a + 11);
        else if (!strncmp(a, "--prefetch=", 11)) g_opt.prefetch = atoi(a + 11);
        else if (!strncmp(a, "--threads=", 10)) g_opt.threads = atoi(a + 10);
        else if (!strncmp(a, "--fps=", 6)) g_opt.fps_override = atof(a + 6);
        else if (!strncmp(a, "--white=", 8)) g_opt.white_override = atoi(a + 8);
        else if (!strcmp(a, "--no-fastpass")) g_opt.fastpass = 0;
        else if (!strcmp(a, "--fix-edges")) g_opt.fix_edges = 1;
        else if (!strncmp(a, "--cache-dir=", 12)) g_opt.cache_dir = strdup(a + 12);
        else if (!strcmp(a, "--no-cache")) g_opt.cache_dir = strdup("");
        else if (!strcmp(a, "--no-warmup")) g_opt.warmup = 0;
        else if (!strncmp(a, "--log=", 6)) {
            const char *l = a + 6;
            if (l[0] == '/') g_opt.logfile = strdup(l);
            else { char cwd[PATH_MAX]; if (!getcwd(cwd, sizeof(cwd))) strcpy(cwd, "/tmp");
                   g_opt.logfile = malloc(strlen(cwd) + strlen(l) + 2); sprintf(g_opt.logfile, "%s/%s", cwd, l); }
        }
        else if (!strcmp(a, "-f")) foreground = 1;
        else if (!strcmp(a, "-v")) g_opt.verbose = 1;
        else if (!strcmp(a, "-o") && i + 1 < argc) { fargv[fargc++] = "-o"; fargv[fargc++] = argv[++i]; }
        else if (a[0] == '-') { fprintf(stderr, "unknown option %s\n", a); usage(argv[0]); return 1; }
        else if (npos < 2) pos[npos++] = a;
        else { usage(argv[0]); return 1; }
    }
    if (npos != 2) { usage(argv[0]); return 1; }
    if (g_opt.chroma != 0 && g_opt.chroma != 2 && g_opt.chroma != 3) g_opt.chroma = 2;
    if (g_opt.prefetch < 0) g_opt.prefetch = 0;
    if (g_opt.prefetch > 64) g_opt.prefetch = 64;
    if (g_opt.threads <= 0) {
        long n = sysconf(_SC_NPROCESSORS_ONLN);
        g_opt.threads = n < 1 ? 1 : (n > 8 ? 8 : (int)n);
    }

    g_opt.source = realpath(pos[0], NULL);
    if (!g_opt.source) { fprintf(stderr, "source folder not found: %s\n", pos[0]); return 1; }
    const char *mp = pos[1];
    int drive_mp = (isalpha((unsigned char)mp[0]) && mp[1] == ':' && (mp[2] == 0 || (mp[2] == '\\' && mp[3] == 0)))
                   || !strcmp(mp, "*");
    if (drive_mp || MRFS_WINDOWS) {
        g_opt.mountpoint = strdup(mp);          /* WinFsp: drive letter or path it creates */
        if (drive_mp && mp[2]) g_opt.mountpoint[2] = 0;
    } else {
        g_opt.mountpoint = realpath(mp, NULL);
        if (!g_opt.mountpoint) { fprintf(stderr, "mount point not found: %s\n", mp); return 1; }
        size_t sl = strlen(g_opt.source);
        if (!strncmp(g_opt.mountpoint, g_opt.source, sl) &&
            (g_opt.mountpoint[sl] == '/' || g_opt.mountpoint[sl] == 0)) {
            fprintf(stderr, "the mount point must not be inside the source folder\n");
            return 1;
        }
    }
    g_start_time = time(NULL);

    /* index cache directory */
    if (!g_opt.cache_dir) {
        const char *x = getenv("XDG_CACHE_HOME"), *home = getenv("HOME");
        char d[PATH_MAX] = "";
        if (x && x[0]) snprintf(d, sizeof(d), "%s/mlvresolvefs", x);
        else if (home && home[0]) snprintf(d, sizeof(d), "%s/.cache/mlvresolvefs", home);
        if (d[0]) g_opt.cache_dir = strdup(d);
    }
    if (g_opt.cache_dir && g_opt.cache_dir[0]) {
        char d[PATH_MAX];
        snprintf(d, sizeof(d), "%s", g_opt.cache_dir);
        for (char *p = d + 1; *p; p++) if (*p == '/') { *p = 0; mkdir(d, 0755); *p = '/'; }
        mkdir(d, 0755);
        if (access(d, W_OK) != 0) { free(g_opt.cache_dir); g_opt.cache_dir = NULL; }
    } else {
        g_opt.cache_dir = NULL;
    }

    g_ncache = g_opt.prefetch + g_opt.threads + 4;
    if (g_ncache < 6) g_ncache = 6;
    g_cache = calloc(g_ncache, sizeof(centry_t));

    rescan(1);
    mrfs_log("found %d MLV clip(s) in %s\n", g_nclips, g_opt.source);

    fargv[fargc++] = g_opt.mountpoint;
    if (foreground) fargv[fargc++] = "-f";
#if !MRFS_WINDOWS
    fargv[fargc++] = "-o";
# if FUSE_USE_VERSION >= 30
    fargv[fargc++] = "fsname=mlvresolvefs,subtype=mlvresolvefs,default_permissions,auto_unmount";
# else
    fargv[fargc++] = "fsname=mlvresolvefs,subtype=mlvresolvefs,default_permissions,auto_unmount,"
                     "kernel_cache,entry_timeout=5,attr_timeout=5,negative_timeout=1";
# endif
#endif
    /* WinFsp options (uid/gid, volume name, caching) are passed by the launcher with -o. */
    int r = fuse_main(fargc, fargv, &ops, NULL);
    if (r) mrfs_log("file system exited with code %d\n", r);
    return r;
}
