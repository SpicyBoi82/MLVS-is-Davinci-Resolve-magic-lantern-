[CmdletBinding()]
param(
    [switch]$AutoMount
)

# MLV Resolve FS v3.2 - Windows launcher.
#
# Fixes compared with v2.8:
#  * the backend is started detached in its own hidden window, so closing this window or a
#    PowerShell console no longer kills the mount;
#  * mounting waits up to 90 s without freezing the window and never kills a backend that is
#    merely slow to start (v2.8 gave up and killed it after 6 s);
#  * the drive letter of an existing mount is always offered and selected, so reopening the
#    launcher no longer reports a working mount as "not available";
#  * the launcher refuses to mount from an elevated (Administrator) session, because such a
#    drive letter is invisible to Explorer and DaVinci Resolve;
#  * the PID file is checked against the process name and start time (no PID reuse mix-ups);
#  * optional automatic mount when you sign in to Windows.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ErrorActionPreference = 'Stop'

$Version = '3.2'
$InstallDir = Join-Path $env:ProgramFiles 'MLV Resolve FS'
$RepairInstaller = Join-Path $InstallDir 'installer\Install-MLVResolveFS.ps1'
$CygwinRoot = 'C:\cygwin64'
$CygwinBin = Join-Path $CygwinRoot 'bin'
$BackendExe = Join-Path $CygwinRoot 'opt\mlvresolvefs\bin\mlvresolvefs.exe'
$CygpathExe = Join-Path $CygwinBin 'cygpath.exe'
$StateDir = Join-Path $env:LOCALAPPDATA 'MLVResolveFS'
$PidFile = Join-Path $StateDir 'backend.json'
$LegacyPidFile = Join-Path $StateDir 'mlvfs.pid'
$ConfigFile = Join-Path $StateDir 'config.json'
$MountLog = Join-Path $StateDir 'mount.log'
$MountLogOut = Join-Path $StateDir 'mount-stdout.log'
$MountLogErr = Join-Path $StateDir 'mount-stderr.log'
$StartupShortcut = Join-Path ([Environment]::GetFolderPath('Startup')) 'MLV Resolve FS (auto mount).lnk'
$MountTimeoutSeconds = 90
New-Item -ItemType Directory -Force -Path $StateDir | Out-Null

# WinFsp options. FileInfoTimeout=-1 lets Windows cache file data (the virtual files never
# change); if this WinFsp build rejects an option the launcher retries with the basic set.
$WinFspOptions = 'uid=-1,gid=-1,volname=MLVRESOLVE,FileInfoTimeout=-1,DirInfoTimeout=5000'
$WinFspBasicOptions = 'uid=-1,gid=-1'

# ------------------------------------------------------------------ helpers

function Write-LauncherLog([string]$Message) {
    try {
        Add-Content -Path $MountLog -Value ('[{0}] launcher: {1}' -f (Get-Date -Format 'HH:mm:ss'), $Message)
    } catch {}
}

function Test-IsElevated {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-Config {
    $cfg = [ordered]@{
        source = ''; drive = 'R:'; prefetch = 8; fps = ''
        resolveNaming = $true; badPixels = $false; stripes = $false; cs2x2 = $false
        dualPreview = $false; dualFull = $false; fixEdges = $false; autoMount = $false
    }
    if (Test-Path $ConfigFile) {
        try {
            $saved = Get-Content $ConfigFile -Raw | ConvertFrom-Json
            foreach ($key in @($cfg.Keys)) {
                $prop = $saved.PSObject.Properties[$key]
                if ($null -ne $prop -and $null -ne $prop.Value) { $cfg[$key] = $prop.Value }
            }
        } catch {}
    }
    return $cfg
}

function Save-Config($cfg) {
    try { ([pscustomobject]$cfg) | ConvertTo-Json | Set-Content -Encoding UTF8 $ConfigFile } catch {}
}

# Returns the running backend as @{ Process; Drive } or $null.
function Get-MountedBackend {
    if (-not (Test-Path $PidFile)) { return $null }
    try {
        $info = Get-Content $PidFile -Raw | ConvertFrom-Json
        $proc = Get-Process -Id ([int]$info.pid) -ErrorAction SilentlyContinue
        if (-not $proc) { return $null }
        if ($proc.ProcessName -ne 'mlvresolvefs') { return $null }
        try {
            if ($info.started -and ([long]$proc.StartTime.Ticks -ne [long]$info.started)) { return $null }
        } catch {}
        return @{ Process = $proc; Drive = [string]$info.drive }
    } catch { return $null }
}

function Save-MountedBackend($proc, [string]$drive) {
    $started = 0
    try { $started = [long]$proc.StartTime.Ticks } catch {}
    [pscustomobject]@{ pid = $proc.Id; drive = $drive; started = $started } |
        ConvertTo-Json | Set-Content -Encoding ASCII $PidFile
}

function Test-DriveReady([string]$drive) {
    if (-not $drive) { return $false }
    try { return [System.IO.Directory]::Exists($drive + '\') } catch { return $false }
}

function Get-UsedDriveLetters {
    $used = New-Object System.Collections.Generic.HashSet[string]
    foreach ($d in [System.IO.DriveInfo]::GetDrives()) { [void]$used.Add($d.Name.Substring(0, 1).ToUpperInvariant()) }
    foreach ($d in @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) { [void]$used.Add($d.Name.ToUpperInvariant()) }
    # Remembered network drives that are currently disconnected still own their letter.
    foreach ($k in @(Get-ChildItem 'HKCU:\Network' -ErrorAction SilentlyContinue)) { [void]$used.Add($k.PSChildName.ToUpperInvariant()) }
    return ,$used
}

function Get-DriveChoices([string]$mountedDrive) {
    $used = Get-UsedDriveLetters
    $choices = New-Object System.Collections.Generic.List[string]
    foreach ($letter in @('R','S','T','U','V','W','X','Y','Z','Q','P','O','N','M')) {
        $drive = "$letter`:"
        if ($drive -eq $mountedDrive -or -not $used.Contains($letter)) { $choices.Add($drive) }
    }
    return $choices
}

function Convert-ToCygwinPath([string]$Path) {
    if (-not (Test-Path $CygpathExe)) { throw 'Cygwin is not installed yet. Click Install / Repair Backend.' }
    $result = & $CygpathExe -u $Path
    if ($LASTEXITCODE -ne 0 -or -not $result) { throw ('Could not convert this path for the backend: {0}' -f $Path) }
    return ([string]($result | Select-Object -First 1)).Trim()
}

function Quote-ProcessArgument([string]$Value) {
    if ($Value -notmatch '[\s"]') { return $Value }
    return '"' + ($Value -replace '"', '\"') + '"'
}

function Get-BackendArguments($cfg, [string]$drive, [string]$winfspOptions) {
    $list = New-Object System.Collections.Generic.List[string]
    if ($cfg.resolveNaming) { $list.Add('--plain-naming') } else { $list.Add('--resolve-naming') }
    if ($cfg.badPixels) { $list.Add('--bad-pixels') }
    if ($cfg.stripes) { $list.Add('--stripes') }
    if ($cfg.cs2x2) { $list.Add('--chroma=2') }
    if ($cfg.dualFull) { $list.Add('--dual-iso=2') } elseif ($cfg.dualPreview) { $list.Add('--dual-iso=1') }
    if ($cfg.fixEdges) { $list.Add('--fix-edges') }
    $list.Add(('--prefetch={0}' -f [int]$cfg.prefetch))
    if (-not [string]::IsNullOrWhiteSpace([string]$cfg.fps)) {
        $fps = 0.0
        if (-not [double]::TryParse(([string]$cfg.fps).Replace(',', '.'), [Globalization.NumberStyles]::Float,
                [Globalization.CultureInfo]::InvariantCulture, [ref]$fps) -or $fps -lt 1 -or $fps -gt 240) {
            throw 'FPS override must be a number such as 23.976, 25 or 50.'
        }
        $list.Add(('--fps={0}' -f $fps.ToString([Globalization.CultureInfo]::InvariantCulture)))
    }
    $list.Add('--log=' + (Convert-ToCygwinPath $MountLog))
    $list.Add('-f')
    $list.Add('-o')
    $list.Add($winfspOptions)
    $list.Add((Convert-ToCygwinPath ([string]$cfg.source)))
    $list.Add($drive)
    return (($list | ForEach-Object { Quote-ProcessArgument $_ }) -join ' ')
}

# Starts the backend detached in its own hidden console. Returns the process.
function Start-Backend($cfg, [string]$drive, [string]$winfspOptions) {
    if (-not (Test-Path $BackendExe)) { throw 'The MLV Resolve FS backend is missing. Click Install / Repair Backend.' }
    $argString = Get-BackendArguments $cfg $drive $winfspOptions
    Remove-Item $MountLogOut, $MountLogErr -Force -ErrorAction SilentlyContinue
    Write-LauncherLog ('starting: mlvresolvefs.exe {0}' -f $argString)
    $oldPath = $env:PATH
    try {
        $env:PATH = $CygwinBin + ';' + $oldPath
        $proc = Start-Process -FilePath $BackendExe -ArgumentList $argString -WorkingDirectory $StateDir `
            -WindowStyle Hidden -PassThru -RedirectStandardOutput $MountLogOut -RedirectStandardError $MountLogErr
    } finally {
        $env:PATH = $oldPath
    }
    if (-not $proc) { throw 'Could not start the MLV Resolve FS backend.' }
    $null = $proc.Handle    # keep the handle so ExitCode is available after it exits
    return $proc
}

function Get-BackendErrorText {
    $lines = @()
    foreach ($f in @($MountLogErr, $MountLogOut)) {
        if (Test-Path $f) { $lines += @(Get-Content $f -Tail 12 -ErrorAction SilentlyContinue) }
    }
    if (Test-Path $MountLog) { $lines += @(Get-Content $MountLog -Tail 6 -ErrorAction SilentlyContinue) }
    return (($lines | Where-Object { $_ -and $_.Trim() }) -join "`n")
}

# Errors where retrying with other WinFsp options cannot help.
function Test-FatalError([string]$text) {
    return ($text -match '(?i)source folder not found|No such file or directory|cannot open shared object|cygwin1\.dll|winfsp.*not (found|installed)')
}

function Validate-Mount($cfg, [string]$drive) {
    if (-not (Test-Path $BackendExe)) { throw 'The MLV Resolve FS backend is missing. Click Install / Repair Backend.' }
    if (Test-IsElevated) {
        throw ('MLV Resolve FS is running as Administrator. A drive mounted from here would be invisible ' +
               'to Explorer and DaVinci Resolve. Close it and start it normally from the Start Menu.')
    }
    if (-not $cfg.source -or -not (Test-Path -LiteralPath ([string]$cfg.source) -PathType Container)) {
        throw 'Choose a valid folder containing MLV footage.'
    }
    if (-not $drive) { throw 'No free drive letter is available.' }
    if (Test-DriveReady $drive) { throw ('Drive {0} is already in use. Choose another drive letter.' -f $drive) }
    if ($cfg.dualPreview -and $cfg.dualFull) { $cfg.dualPreview = $false }
}

function Stop-Backend {
    $m = Get-MountedBackend
    if ($m) {
        Write-LauncherLog ('stopping backend PID {0}' -f $m.Process.Id)
        Stop-Process -Id $m.Process.Id -Force -ErrorAction SilentlyContinue
        try { $m.Process.WaitForExit(5000) | Out-Null } catch {}
    }
    Remove-Item $PidFile -Force -ErrorAction SilentlyContinue
}

function Set-AutoMountShortcut([bool]$enabled) {
    if ($enabled) {
        $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $launcher = $PSCommandPath
        $ws = New-Object -ComObject WScript.Shell
        $lnk = $ws.CreateShortcut($StartupShortcut)
        $lnk.TargetPath = $powershell
        $lnk.Arguments = ('-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "{0}" -AutoMount' -f $launcher)
        $lnk.WorkingDirectory = $StateDir
        $lnk.WindowStyle = 7
        $lnk.Description = 'Mount MLV footage for DaVinci Resolve at sign-in'
        $lnk.Save()
    } else {
        Remove-Item $StartupShortcut -Force -ErrorAction SilentlyContinue
    }
}

# Old v2.8 backend still running (mlvfs.exe)? It cannot be managed by this launcher.
function Stop-LegacyBackend {
    if (-not (Test-Path $LegacyPidFile)) { return }
    try {
        $legacyPid = [int](Get-Content $LegacyPidFile -ErrorAction Stop | Select-Object -First 1)
        $p = Get-Process -Id $legacyPid -ErrorAction SilentlyContinue
        if ($p -and $p.ProcessName -eq 'mlvfs') { Stop-Process -Id $legacyPid -Force -ErrorAction SilentlyContinue }
    } catch {}
    Remove-Item $LegacyPidFile -Force -ErrorAction SilentlyContinue
}

# ------------------------------------------------------------------ unattended mount at sign-in

if ($AutoMount) {
    $cfg = Get-Config
    try {
        if (Get-MountedBackend) { exit 0 }
        Stop-LegacyBackend
        $drive = [string]$cfg.drive
        Validate-Mount $cfg $drive
        $options = $WinFspOptions
        for ($attempt = 0; $attempt -lt 2; $attempt++) {
            $proc = Start-Backend $cfg $drive $options
            $deadline = (Get-Date).AddSeconds($MountTimeoutSeconds)
            while ((Get-Date) -lt $deadline -and -not $proc.HasExited -and -not (Test-DriveReady $drive)) {
                Start-Sleep -Milliseconds 250
            }
            if (-not $proc.HasExited) {
                Save-MountedBackend $proc $drive
                Write-LauncherLog ('auto mount on {0} (PID {1})' -f $drive, $proc.Id)
                exit 0
            }
            $err = Get-BackendErrorText
            if ($attempt -eq 0 -and -not (Test-FatalError $err)) { $options = $WinFspBasicOptions; continue }
            throw ('backend exited with code {0}: {1}' -f $proc.ExitCode, $err)
        }
    } catch {
        Write-LauncherLog ('auto mount failed: ' + $_.Exception.Message)
        exit 1
    }
    exit 0
}

# ------------------------------------------------------------------ elevation guard

if (Test-IsElevated) {
    $msg = "MLV Resolve FS was started as Administrator.`n`n" +
           "A drive mounted from an Administrator window is invisible to Explorer and DaVinci Resolve " +
           "(this is what makes R: show as 'not available').`n`n" +
           "Restart MLV Resolve FS as your normal user now?"
    $answer = [System.Windows.Forms.MessageBox]::Show($msg, 'MLV Resolve FS', 'YesNo', 'Warning')
    if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
        $lnk = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\MLV Resolve FS.lnk'
        if (Test-Path $lnk) {
            # Explorer runs as the signed-in user without elevation.
            Start-Process -FilePath (Join-Path $env:SystemRoot 'explorer.exe') -ArgumentList ('"{0}"' -f $lnk)
        } else {
            [System.Windows.Forms.MessageBox]::Show('Start "MLV Resolve FS" from the Start Menu.', 'MLV Resolve FS', 'OK', 'Information') | Out-Null
        }
        exit 0
    }
}

# ------------------------------------------------------------------ window

$cfg = Get-Config
$script:elevated = Test-IsElevated

$form = New-Object System.Windows.Forms.Form
$form.Text = "MLV Resolve FS v$Version"
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(660, 700)
$form.MinimumSize = New-Object System.Drawing.Size(660, 700)
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'Magic Lantern MLV -> DaVinci Resolve'
$title.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 15)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(20, 18)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = 'Mount MLV footage as cleanly named virtual CinemaDNG + WAV media.'
$subtitle.AutoSize = $true
$subtitle.Location = New-Object System.Drawing.Point(22, 55)
$form.Controls.Add($subtitle)

$backendStatus = New-Object System.Windows.Forms.Label
$backendStatus.AutoSize = $true
$backendStatus.Location = New-Object System.Drawing.Point(22, 83)
$form.Controls.Add($backendStatus)

$repairButton = New-Object System.Windows.Forms.Button
$repairButton.Text = 'Install / Repair Backend'
$repairButton.Location = New-Object System.Drawing.Point(420, 75)
$repairButton.Size = New-Object System.Drawing.Size(200, 32)
$form.Controls.Add($repairButton)

$sourceLabel = New-Object System.Windows.Forms.Label
$sourceLabel.Text = 'MLV source folder'
$sourceLabel.AutoSize = $true
$sourceLabel.Location = New-Object System.Drawing.Point(22, 122)
$form.Controls.Add($sourceLabel)

$sourceBox = New-Object System.Windows.Forms.TextBox
$sourceBox.Location = New-Object System.Drawing.Point(22, 146)
$sourceBox.Size = New-Object System.Drawing.Size(500, 28)
$form.Controls.Add($sourceBox)

$browseButton = New-Object System.Windows.Forms.Button
$browseButton.Text = 'Browse...'
$browseButton.Location = New-Object System.Drawing.Point(530, 144)
$browseButton.Size = New-Object System.Drawing.Size(90, 31)
$form.Controls.Add($browseButton)

$driveLabel = New-Object System.Windows.Forms.Label
$driveLabel.Text = 'Virtual drive'
$driveLabel.AutoSize = $true
$driveLabel.Location = New-Object System.Drawing.Point(22, 190)
$form.Controls.Add($driveLabel)

$driveCombo = New-Object System.Windows.Forms.ComboBox
$driveCombo.DropDownStyle = 'DropDownList'
$driveCombo.Location = New-Object System.Drawing.Point(22, 214)
$driveCombo.Size = New-Object System.Drawing.Size(100, 28)
$form.Controls.Add($driveCombo)

$prefetchLabel = New-Object System.Windows.Forms.Label
$prefetchLabel.Text = 'Prefetch frames'
$prefetchLabel.AutoSize = $true
$prefetchLabel.Location = New-Object System.Drawing.Point(150, 190)
$form.Controls.Add($prefetchLabel)

$prefetch = New-Object System.Windows.Forms.NumericUpDown
$prefetch.Minimum = 0
$prefetch.Maximum = 64
$prefetch.Value = 8
$prefetch.Location = New-Object System.Drawing.Point(150, 214)
$prefetch.Size = New-Object System.Drawing.Size(100, 28)
$form.Controls.Add($prefetch)

$fpsLabel = New-Object System.Windows.Forms.Label
$fpsLabel.Text = 'FPS override (optional)'
$fpsLabel.AutoSize = $true
$fpsLabel.Location = New-Object System.Drawing.Point(280, 190)
$form.Controls.Add($fpsLabel)

$fpsBox = New-Object System.Windows.Forms.TextBox
$fpsBox.Location = New-Object System.Drawing.Point(280, 214)
$fpsBox.Size = New-Object System.Drawing.Size(125, 28)
$form.Controls.Add($fpsBox)

$optionsGroup = New-Object System.Windows.Forms.GroupBox
$optionsGroup.Text = 'MLV processing (leave all off for Fast Pass: fastest, least CPU)'
$optionsGroup.Location = New-Object System.Drawing.Point(22, 260)
$optionsGroup.Size = New-Object System.Drawing.Size(598, 165)
$form.Controls.Add($optionsGroup)

$resolveNaming = New-Object System.Windows.Forms.CheckBox
$resolveNaming.Text = 'Simple Resolve naming'
$resolveNaming.Location = New-Object System.Drawing.Point(18, 30)
$resolveNaming.AutoSize = $true
$optionsGroup.Controls.Add($resolveNaming)

$badPixels = New-Object System.Windows.Forms.CheckBox
$badPixels.Text = 'Bad pixel correction'
$badPixels.Location = New-Object System.Drawing.Point(18, 62)
$badPixels.AutoSize = $true
$optionsGroup.Controls.Add($badPixels)

$stripes = New-Object System.Windows.Forms.CheckBox
$stripes.Text = 'Vertical stripe correction'
$stripes.Location = New-Object System.Drawing.Point(18, 94)
$stripes.AutoSize = $true
$optionsGroup.Controls.Add($stripes)

$fixEdges = New-Object System.Windows.Forms.CheckBox
$fixEdges.Text = 'Repair corrupt edge rows'
$fixEdges.Location = New-Object System.Drawing.Point(18, 126)
$fixEdges.AutoSize = $true
$optionsGroup.Controls.Add($fixEdges)

$cs2x2 = New-Object System.Windows.Forms.CheckBox
$cs2x2.Text = '2x2 chroma smoothing'
$cs2x2.Location = New-Object System.Drawing.Point(300, 30)
$cs2x2.AutoSize = $true
$optionsGroup.Controls.Add($cs2x2)

$dualPreview = New-Object System.Windows.Forms.CheckBox
$dualPreview.Text = 'Dual ISO preview'
$dualPreview.Location = New-Object System.Drawing.Point(300, 62)
$dualPreview.AutoSize = $true
$optionsGroup.Controls.Add($dualPreview)

$dualFull = New-Object System.Windows.Forms.CheckBox
$dualFull.Text = 'Dual ISO full processing'
$dualFull.Location = New-Object System.Drawing.Point(300, 94)
$dualFull.AutoSize = $true
$optionsGroup.Controls.Add($dualFull)

$autoMountBox = New-Object System.Windows.Forms.CheckBox
$autoMountBox.Text = 'Mount automatically when I sign in to Windows (before Resolve starts)'
$autoMountBox.Location = New-Object System.Drawing.Point(22, 436)
$autoMountBox.AutoSize = $true
$form.Controls.Add($autoMountBox)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Location = New-Object System.Drawing.Point(22, 470)
$statusLabel.Size = New-Object System.Drawing.Size(598, 64)
$form.Controls.Add($statusLabel)

$mountButton = New-Object System.Windows.Forms.Button
$mountButton.Text = 'Mount for Resolve'
$mountButton.Location = New-Object System.Drawing.Point(22, 545)
$mountButton.Size = New-Object System.Drawing.Size(170, 42)
$form.Controls.Add($mountButton)

$unmountButton = New-Object System.Windows.Forms.Button
$unmountButton.Text = 'Unmount'
$unmountButton.Location = New-Object System.Drawing.Point(202, 545)
$unmountButton.Size = New-Object System.Drawing.Size(110, 42)
$form.Controls.Add($unmountButton)

$openButton = New-Object System.Windows.Forms.Button
$openButton.Text = 'Open Drive'
$openButton.Location = New-Object System.Drawing.Point(322, 545)
$openButton.Size = New-Object System.Drawing.Size(110, 42)
$form.Controls.Add($openButton)

$logButton = New-Object System.Windows.Forms.Button
$logButton.Text = 'Show Log'
$logButton.Location = New-Object System.Drawing.Point(442, 545)
$logButton.Size = New-Object System.Drawing.Size(85, 42)
$form.Controls.Add($logButton)

$closeButton = New-Object System.Windows.Forms.Button
$closeButton.Text = 'Close'
$closeButton.Location = New-Object System.Drawing.Point(537, 545)
$closeButton.Size = New-Object System.Drawing.Size(83, 42)
$form.Controls.Add($closeButton)

$hint = New-Object System.Windows.Forms.Label
$hint.Text = 'Closing this window keeps the drive mounted. Use Unmount before removing the card or drive.'
$hint.ForeColor = [System.Drawing.Color]::DimGray
$hint.AutoSize = $true
$hint.Location = New-Object System.Drawing.Point(22, 600)
$form.Controls.Add($hint)

$folderDialog = New-Object System.Windows.Forms.FolderBrowserDialog
$folderDialog.Description = 'Choose the folder containing your Magic Lantern MLV clips'

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 250

# Mount attempt in progress: @{ Process; Drive; Deadline; Options; Attempt; Config }
$script:pending = $null

# ------------------------------------------------------------------ ui logic

function Show-Message([string]$text, [string]$icon = 'Information') {
    [System.Windows.Forms.MessageBox]::Show($text, 'MLV Resolve FS', 'OK', $icon) | Out-Null
}

function Get-UiConfig {
    $c = Get-Config
    $c.source = $sourceBox.Text.Trim()
    if ($driveCombo.SelectedItem) { $c.drive = [string]$driveCombo.SelectedItem }
    $c.prefetch = [int]$prefetch.Value
    $c.fps = $fpsBox.Text.Trim()
    $c.resolveNaming = $resolveNaming.Checked
    $c.badPixels = $badPixels.Checked
    $c.stripes = $stripes.Checked
    $c.cs2x2 = $cs2x2.Checked
    $c.dualPreview = $dualPreview.Checked
    $c.dualFull = $dualFull.Checked
    $c.fixEdges = $fixEdges.Checked
    $c.autoMount = $autoMountBox.Checked
    return $c
}

function Fill-DriveCombo([string]$preferred) {
    $mounted = Get-MountedBackend
    $mountedDrive = ''
    if ($mounted) { $mountedDrive = $mounted.Drive }
    $driveCombo.Items.Clear()
    foreach ($d in (Get-DriveChoices $mountedDrive)) { [void]$driveCombo.Items.Add($d) }
    $want = $preferred
    if ($mountedDrive) { $want = $mountedDrive }
    if ($want -and $driveCombo.Items.Contains($want)) { $driveCombo.SelectedItem = $want }
    elseif ($driveCombo.Items.Count -gt 0) { $driveCombo.SelectedIndex = 0 }
}

function Refresh-Status {
    $backendReady = (Test-Path $BackendExe) -and (Test-Path $CygpathExe)
    if ($backendReady) {
        $backendStatus.Text = 'Backend: Ready'
        $backendStatus.ForeColor = [System.Drawing.Color]::DarkGreen
    } else {
        $backendStatus.Text = 'Backend: Not installed / incomplete'
        $backendStatus.ForeColor = [System.Drawing.Color]::DarkRed
    }

    if ($script:pending) { return }   # the mount timer owns the status line

    $m = Get-MountedBackend
    $locked = $false
    if ($m) {
        $locked = $true
        if (Test-DriveReady $m.Drive) {
            $statusLabel.Text = ("Status: Mounted on {0} (PID {1}). In Resolve, import the clip folders from {0}\  " +
                                 "If Resolve was already open, use File > Import > Media or restart Resolve once.") -f $m.Drive, $m.Process.Id
            $statusLabel.ForeColor = [System.Drawing.Color]::DarkGreen
            $openButton.Enabled = $true
        } else {
            $statusLabel.Text = ("Status: The backend is running (PID {0}) but {1} is not visible in this session. " +
                                 "Click Unmount, then Mount again. See Show Log for details.") -f $m.Process.Id, $m.Drive
            $statusLabel.ForeColor = [System.Drawing.Color]::DarkOrange
            $openButton.Enabled = $false
        }
        $mountButton.Enabled = $false
        $unmountButton.Enabled = $true
    } else {
        Remove-Item $PidFile -Force -ErrorAction SilentlyContinue
        if ($backendReady) { $statusLabel.Text = 'Status: Ready to mount' } else { $statusLabel.Text = 'Status: Install / repair the backend first' }
        $statusLabel.ForeColor = [System.Drawing.Color]::Black
        $mountButton.Enabled = $backendReady
        $unmountButton.Enabled = $false
        $openButton.Enabled = $false
    }
    if ($script:elevated) {
        $mountButton.Enabled = $false
        if (-not $m) {
            $statusLabel.Text = 'Status: Running as Administrator - mounting is disabled. Start MLV Resolve FS normally from the Start Menu.'
            $statusLabel.ForeColor = [System.Drawing.Color]::DarkRed
        }
    }
    $driveCombo.Enabled = -not $locked
    $sourceBox.Enabled = -not $locked
    $browseButton.Enabled = -not $locked
    $optionsGroup.Enabled = -not $locked
    $prefetch.Enabled = -not $locked
    $fpsBox.Enabled = -not $locked
}

function Finish-Pending([bool]$success, [string]$message) {
    $timer.Stop()
    $p = $script:pending
    $script:pending = $null
    $form.UseWaitCursor = $false
    $repairButton.Enabled = $true
    if ($success) {
        Save-MountedBackend $p.Process $p.Drive
        Write-LauncherLog ('mounted on {0} (PID {1})' -f $p.Drive, $p.Process.Id)
    }
    Fill-DriveCombo $p.Drive
    Refresh-Status
    if ($message) {
        if ($success) { Show-Message $message 'Information' } else { Show-Message $message 'Error' }
    }
}

$timer.Add_Tick({
    $p = $script:pending
    if (-not $p) { $timer.Stop(); return }
    $elapsed = [int]((Get-Date) - $p.Started).TotalSeconds

    if (Test-DriveReady $p.Drive) {
        if ($p.Process.HasExited) {
            Finish-Pending $false ("Drive {0} appeared but the backend exited (code {1}).`n`n{2}" -f $p.Drive, $p.Process.ExitCode, (Get-BackendErrorText))
        } else {
            Finish-Pending $true ''
        }
        return
    }

    if ($p.Process.HasExited) {
        $err = Get-BackendErrorText
        if ($p.Attempt -eq 0 -and -not (Test-FatalError $err)) {
            Write-LauncherLog 'first start failed; retrying with the basic WinFsp option set used by v2.8'
            try {
                $p.Process = Start-Backend $p.Config $p.Drive $WinFspBasicOptions
                $p.Attempt = 1
                $p.Started = Get-Date
                return
            } catch {
                Finish-Pending $false $_.Exception.Message
                return
            }
        }
        $text = 'The backend stopped before the drive appeared (exit code {0}).' -f $p.Process.ExitCode
        if ($err) { $text += "`n`n" + $err }
        $text += "`n`nFull log: $MountLog"
        Finish-Pending $false $text
        return
    }

    if ($elapsed -ge $MountTimeoutSeconds) {
        # Do NOT kill it: a slow disk or a first-time WinFsp start can take this long.
        Save-MountedBackend $p.Process $p.Drive
        Finish-Pending $false (("The backend is running, but {0} has not appeared after {1} seconds.`n`n" +
            "It has been left running; it may still appear. If it does not:`n" +
            " - make sure this window is not running as Administrator`n" +
            " - check that no other program owns {0} (try another letter)`n" +
            " - reinstall WinFsp, or use Install / Repair Backend`n`nLog: {2}") -f $p.Drive, $elapsed, $MountLog)
        return
    }

    $statusLabel.Text = ('Status: Mounting on {0}... ({1} s)' -f $p.Drive, $elapsed)
    $statusLabel.ForeColor = [System.Drawing.Color]::DarkOrange
})

$browseButton.Add_Click({
    if ($sourceBox.Text -and (Test-Path -LiteralPath $sourceBox.Text)) { $folderDialog.SelectedPath = $sourceBox.Text }
    if ($folderDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $sourceBox.Text = $folderDialog.SelectedPath
    }
})

$dualPreview.Add_CheckedChanged({ if ($dualPreview.Checked) { $dualFull.Checked = $false } })
$dualFull.Add_CheckedChanged({ if ($dualFull.Checked) { $dualPreview.Checked = $false } })

$autoMountBox.Add_CheckedChanged({
    try {
        Set-AutoMountShortcut $autoMountBox.Checked
        Save-Config (Get-UiConfig)
    } catch {
        Show-Message ('Could not change the sign-in shortcut: ' + $_.Exception.Message) 'Warning'
    }
})

$repairButton.Add_Click({
    try {
        if (-not (Test-Path $RepairInstaller)) { throw "Backend installer was not found at $RepairInstaller" }
        if (Get-MountedBackend) {
            $answer = [System.Windows.Forms.MessageBox]::Show('Repairing the backend unmounts the virtual drive first. Continue?', 'MLV Resolve FS', 'OKCancel', 'Question')
            if ($answer -ne [System.Windows.Forms.DialogResult]::OK) { return }
            Stop-Backend
        }
        $repairButton.Enabled = $false
        $backendStatus.Text = 'Backend: Installing / repairing...'
        $backendStatus.ForeColor = [System.Drawing.Color]::DarkOrange
        $form.Refresh()

        $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $installerArgs = '-NoProfile -ExecutionPolicy Bypass -File "{0}" -BackendOnly' -f $RepairInstaller
        $repairProc = Start-Process -FilePath $powershell -Verb RunAs -ArgumentList $installerArgs -Wait -PassThru
        if ($repairProc.ExitCode -ne 0) {
            throw ('Backend installer exited with code {0}. Check C:\ProgramData\MLVResolveFS\logs for the latest log.' -f $repairProc.ExitCode)
        }
        if (-not (Test-Path $BackendExe)) { throw 'The installer finished, but the backend is still missing. Check the latest install log.' }
        Show-Message 'Backend installation completed successfully. MLV Resolve FS is ready to mount footage.'
    } catch {
        Show-Message $_.Exception.Message 'Error'
    } finally {
        $repairButton.Enabled = $true
        Refresh-Status
    }
})

$mountButton.Add_Click({
    try {
        if ($script:pending) { return }
        if (Get-MountedBackend) { throw 'MLV Resolve FS is already mounted.' }
        Stop-LegacyBackend
        $c = Get-UiConfig
        $drive = [string]$c.drive
        Validate-Mount $c $drive
        Save-Config $c
        if ($c.autoMount) { Set-AutoMountShortcut $true }
        $proc = Start-Backend $c $drive $WinFspOptions
        $script:pending = @{ Process = $proc; Drive = $drive; Started = (Get-Date); Attempt = 0; Config = $c }
        $mountButton.Enabled = $false
        $repairButton.Enabled = $false
        $form.UseWaitCursor = $true
        $statusLabel.Text = ('Status: Mounting on {0}...' -f $drive)
        $statusLabel.ForeColor = [System.Drawing.Color]::DarkOrange
        $timer.Start()
    } catch {
        $script:pending = $null
        Show-Message $_.Exception.Message 'Error'
        Refresh-Status
    }
})

$unmountButton.Add_Click({
    try {
        if ($script:pending) { return }
        $resolve = @(Get-Process -Name 'Resolve' -ErrorAction SilentlyContinue)
        if ($resolve.Count -gt 0) {
            $answer = [System.Windows.Forms.MessageBox]::Show('DaVinci Resolve is running. Clips on the virtual drive will go offline. Unmount anyway?', 'MLV Resolve FS', 'YesNo', 'Question')
            if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        }
        Stop-Backend
        Start-Sleep -Milliseconds 500
        Fill-DriveCombo ([string]$driveCombo.SelectedItem)
        Refresh-Status
    } catch {
        Show-Message $_.Exception.Message 'Error'
    }
})

$openButton.Add_Click({
    $m = Get-MountedBackend
    if ($m -and (Test-DriveReady $m.Drive)) {
        Start-Process -FilePath (Join-Path $env:SystemRoot 'explorer.exe') -ArgumentList ($m.Drive + '\')
    } else {
        Show-Message 'The virtual drive is not mounted. Click Mount for Resolve first.' 'Warning'
        Refresh-Status
    }
})

$logButton.Add_Click({
    if (-not (Test-Path $MountLog)) { Set-Content -Path $MountLog -Value '' }
    Start-Process -FilePath 'notepad.exe' -ArgumentList ('"{0}"' -f $MountLog)
})

$closeButton.Add_Click({ $form.Close() })

$form.Add_FormClosing({
    if (-not $script:pending) { Save-Config (Get-UiConfig) }
})

# Refresh every few seconds so a crashed backend or an external unmount shows up.
$refreshTimer = New-Object System.Windows.Forms.Timer
$refreshTimer.Interval = 3000
$refreshTimer.Add_Tick({ if (-not $script:pending) { Refresh-Status } })

# ------------------------------------------------------------------ initial state

if ($cfg.source -and (Test-Path -LiteralPath ([string]$cfg.source))) { $sourceBox.Text = [string]$cfg.source }
try { $prefetch.Value = [decimal][Math]::Max(0, [Math]::Min(64, [int]$cfg.prefetch)) } catch {}
$fpsBox.Text = [string]$cfg.fps
$resolveNaming.Checked = [bool]$cfg.resolveNaming
$badPixels.Checked = [bool]$cfg.badPixels
$stripes.Checked = [bool]$cfg.stripes
$cs2x2.Checked = [bool]$cfg.cs2x2
$dualPreview.Checked = [bool]$cfg.dualPreview
$dualFull.Checked = [bool]$cfg.dualFull
$fixEdges.Checked = [bool]$cfg.fixEdges
$autoMountBox.Checked = (Test-Path $StartupShortcut)
Fill-DriveCombo ([string]$cfg.drive)
Refresh-Status
$refreshTimer.Start()


[void]$form.ShowDialog()
$refreshTimer.Stop()
$timer.Stop()
