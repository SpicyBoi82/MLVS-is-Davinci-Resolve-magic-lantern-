MLV RESOLVE FS v3.2 - LESS MOIRE IN DUAL ISO
============================================

v3.2: dual ISO rebuilds the missing exposure of each row along the direction of the
detail (vertical or one of four diagonals) instead of always straight down. Diagonal
edges (zips, hair, leaves) no longer turn into stair steps, and fine diagonal texture
keeps its pattern instead of turning into moire. Test with known truth: moire on fine
texture -78 to -85 %, edge errors -40 %. Everything else as v3.1.2.
Tip: on the camera, Canon row layout (2-row groups) gives less moire than bit 11
(4-row groups): the rebuilt rows are 2 rows from real data instead of up to 6.

----------------------------------------------------------------------------------

MLV RESOLVE FS v3.1.2 - DUAL ISO, CLIPPING AND WINDOW FIXES
===========================================================

v3.1.2: pink skies and remaining lines in 5x crop clips. The camera writes a white level
(2761) below where the data really clips (about 2950). v3.1.1 then switched to the full
14-bit scale (16383): nothing counted as clipped (pink sky in Resolve) and the dual ISO
merge could not measure the exposure ratio and stayed off (lines). v3.1.2 finds where
clipped pixels pile up and uses that as the white level, above or below the file's value.
Mount log: "data clips at 2949 (pile-up), RAWI white level is 2761; using 2949".
Tested on the user clips M31-1561 (1832x766, 2-row groups) and M31-1407 (3136x1318,
4-row groups, pattern moves every frame).

v3.1.1: the MLV Resolve FS window did not open (it crashed while being built, with
"Cannot convert value System.Windows.Forms.CheckBox to type SwitchParameter"). The
"Mount automatically" tick box had the same name as the launcher's -AutoMount switch;
PowerShell names are case-insensitive, so they collided. Renamed. Nothing else changed.

v3.1 changes only the dual ISO processing (backend/process.c). Everything else is v3.0.

WHAT WAS WRONG
--------------
- Only Canon's 2-row dual ISO pattern was recognised. Clips recorded with 4-row groups
  (CMOS[0] bit 11 / "long groups") were reported as "no interlaced ISO pattern" and
  passed through untouched -> fine horizontal stripes over the whole picture in Resolve.
- The pattern was measured on one frame and used for the whole clip. If the row phase
  moves between frames (70D 23.976p timing), every frame with the other phase came out
  badly striped.
- The real clipping point was not used: 70D LiveView raw clips well below the white level
  in the file (about 4932 vs 5586). Clipped bright rows were blended in as if they were
  valid -> pink/magenta highlights.

WHAT v3.1 DOES
--------------
- Detects 2-row and 4-row dual ISO groups, per frame.
- Fills each row from the nearest same-colour rows of the other ISO above and below.
- Measures where the data really clips and treats those pixels as clipped.
- The mount log says what it found, e.g.
    M31-2201: dual ISO detected, 2-row groups, ratio 8.03 (3.01 EV), data clips at 4930
- Tested on synthetic 70D-style frames (both patterns, phase change between frames,
  blown highlights); not yet on a real clip.

UPDATE FROM v3.0
----------------
1. Close DaVinci Resolve. In MLV Resolve FS click Unmount, then Close.
2. Run INSTALL-MLV-RESOLVE-FS.cmd (or REPAIR-OR-UPDATE.cmd) and approve UAC.
   It rebuilds the backend from this package (about a minute).
3. Tick "Dual ISO full processing", mount, start Resolve.
4. If the picture is still striped, click Show Log and send the dual ISO line.

----------------------------------------------------------------------------------

MLV RESOLVE FS v3.0 - RELIABLE MOUNT
====================================

v3.0 fixes "Mounting timed out" and "R: is not mounted / not available" when
using the virtual drive in DaVinci Resolve.

INSTALL / UPDATE FROM v2.x
--------------------------
1. Close DaVinci Resolve. In MLV Resolve FS click Unmount, then Close.
2. Run INSTALL-MLV-RESOLVE-FS.cmd and approve UAC.
   It keeps WinFsp and Cygwin, builds the new backend (about a minute) and
   opens MLV Resolve FS for you as your normal user.
3. Choose your MLV folder, click "Mount for Resolve", then start Resolve.

Tip: tick "Mount automatically when I sign in to Windows" so the drive is
already there whenever Resolve starts.

WHAT WAS WRONG IN v2.8
----------------------
- Updating with UPDATE-TO-V2.8 / FIX-LAUNCHER-ONLY opened the launcher as
  Administrator. A drive mounted from an Administrator window exists only for
  Administrator programs, so Explorer and Resolve said "R:\ is unavailable".
  v3.0 never starts the launcher elevated, and refuses to mount if you start it
  as Administrator yourself (it offers to restart normally).
- The launcher gave the backend 6 seconds to create the drive, then killed it
  and reported a failure. On a slow PC, a USB card reader or the first start
  after boot, that is not enough. v3.0 waits up to 90 seconds without freezing
  the window and never kills a backend that is only slow.
- The backend ran inside the launcher's PowerShell console window. Closing
  that black window killed the mount, and Resolve then reported the media as
  offline. v3.0 starts the backend detached and hidden; closing the launcher
  keeps the drive mounted.
- After reopening the launcher, the drive list left out the letter that was
  already mounted, so a working mount was shown as "not available". Fixed.
- Reading the WAV re-scanned every frame header of the MLV on every read,
  and every DNG read reopened the MLV files. Resolve could time out waiting.
  The new backend indexes each clip once, keeps the files open, reads ahead
  on several threads and has a frame cache.

WHAT ELSE CHANGED
-----------------
- New backend written for MLV Resolve FS (no upstream MLVFS clone, no Python
  patch step, nothing downloaded from GitHub at install time).
- Lossless (LJ92) Fast Pass is byte-identical to MLV App's lossless DNG export.
- 70D crop recordings: the junk rows at the bottom of the frame (the white line
  in Resolve) are cropped out automatically.
- The virtual WAV is placed on the video time axis from the camera timestamps
  and is exactly as long as the video, as in v2.8. DNG timecode and WAV
  timecode both use the camera's time of day.
- Naming is unchanged with "Simple Resolve naming" ticked:
      R:\M22-1423\M22-1423_000000.dng ... M22-1423.wav
  so existing Resolve projects relink to the same paths.
- Processing options (bad pixels, stripes, chroma smoothing, dual ISO, edge
  row repair) now actually work on lossless clips too. They decode every frame,
  so leave them all off on a slow PC (Fast Pass).
- "Show Log" button opens the mount log.

IF RESOLVE STILL CANNOT SEE THE DRIVE
-------------------------------------
- Start Resolve after mounting, or use File > Import > Media and browse to R:.
- Do not run Resolve or MLV Resolve FS as Administrator.
- Click Show Log and look at the last lines.

LOGS
----
Mount log:       %LOCALAPPDATA%\MLVResolveFS\mount.log
Backend output:  %LOCALAPPDATA%\MLVResolveFS\mount-stderr.log
Installer logs:  C:\ProgramData\MLVResolveFS\logs\

UNINSTALL
---------
Run UNINSTALL-MLV-RESOLVE-FS.cmd. WinFsp and Cygwin are left installed.
