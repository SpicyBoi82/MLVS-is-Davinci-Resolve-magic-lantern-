[CmdletBinding()]
param(
    [switch]$NoDesktopShortcut,
    [switch]$BackendOnly
)

# MLV Resolve FS v3.2 installer.
# v3.0 builds its own backend (bundled in .\backend) under Cygwin against WinFsp's FUSE layer.
# It no longer clones and patches upstream MLVFS, so there is nothing to download from GitHub
# and no patch step that can fail.

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $PSCommandPath + '"'))
    if ($NoDesktopShortcut) { $argList += '-NoDesktopShortcut' }
    if ($BackendOnly) { $argList += '-BackendOnly' }
    try {
        $p = Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argList -Wait -PassThru
        exit $p.ExitCode
    } catch {
        Write-Host 'Administrator approval was declined; nothing was installed.' -ForegroundColor Yellow
        exit 1
    }
}

$Version = '3.2'
$PackageRoot = Split-Path -Parent $PSScriptRoot
$InstallDir = Join-Path $env:ProgramFiles 'MLV Resolve FS'
$InstallAppDir = Join-Path $InstallDir 'app'
$InstallInstallerDir = Join-Path $InstallDir 'installer'
$InstallBackendSrc = Join-Path $InstallDir 'backend'
$DataDir = Join-Path $env:ProgramData 'MLVResolveFS'
$CygwinRoot = 'C:\cygwin64'
$CygwinBin = Join-Path $CygwinRoot 'bin'
$BashExe = Join-Path $CygwinBin 'bash.exe'
$BackendDir = Join-Path $CygwinRoot 'opt\mlvresolvefs\bin'
$BackendExe = Join-Path $BackendDir 'mlvresolvefs.exe'
$LogDir = Join-Path $DataDir 'logs'
$LogFile = Join-Path $LogDir ('install-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
$StartMenuShortcut = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\MLV Resolve FS.lnk'

New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = [ConsoleColor]::Gray)
    $line = ('[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $Message)
    Write-Host $line -ForegroundColor $Color
    Add-Content -Path $LogFile -Value $line
}

function Copy-IfDifferent {
    param([Parameter(Mandatory=$true)][string]$Source, [Parameter(Mandatory=$true)][string]$Destination)
    $srcFull = [System.IO.Path]::GetFullPath($Source).TrimEnd('\')
    $dstFull = [System.IO.Path]::GetFullPath($Destination).TrimEnd('\')
    if ([string]::Equals($srcFull, $dstFull, [System.StringComparison]::OrdinalIgnoreCase)) { return }
    if (-not (Test-Path $Source)) { throw ('Required installer file not found: {0}' -f $Source) }
    Copy-Item $Source $Destination -Force
}

# Where the backend sources come from: the extracted package, or the installed copy (repair).
function Get-BackendSourceDir {
    foreach ($candidate in @((Join-Path $PackageRoot 'backend'), $InstallBackendSrc)) {
        if (Test-Path (Join-Path $candidate 'Makefile')) { return $candidate }
    }
    throw 'Backend source folder (backend\Makefile) was not found next to the installer.'
}

function New-LauncherShortcut([string]$Path, [string]$Launcher) {
    $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut($Path)
    $lnk.TargetPath = $powershell
    # -WindowStyle Hidden: no console window that could be closed by accident.
    $lnk.Arguments = ('-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "{0}"' -f $Launcher)
    $lnk.WorkingDirectory = $InstallDir
    $lnk.WindowStyle = 7
    $lnk.Description = 'Mount Magic Lantern MLV footage as virtual CinemaDNG for DaVinci Resolve'
    $lnk.Save()
}

function Install-LauncherFirst {
    Write-Log 'Installing the launcher and shortcuts first...' Cyan
    foreach ($d in @($InstallDir, $InstallAppDir, $InstallInstallerDir)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }

    Copy-IfDifferent (Join-Path $PackageRoot 'app\MLVResolveFS-Launcher.ps1') (Join-Path $InstallAppDir 'MLVResolveFS-Launcher.ps1')
    Copy-IfDifferent (Join-Path $PackageRoot 'installer\Install-MLVResolveFS.ps1') (Join-Path $InstallInstallerDir 'Install-MLVResolveFS.ps1')
    Copy-IfDifferent (Join-Path $PackageRoot 'installer\Uninstall-MLVResolveFS.ps1') (Join-Path $InstallInstallerDir 'Uninstall-MLVResolveFS.ps1')
    $readmeSource = Join-Path $PackageRoot 'README-FIRST.txt'
    if (Test-Path $readmeSource) { Copy-IfDifferent $readmeSource (Join-Path $InstallDir 'README.txt') }

    # Keep a copy of the backend source so "Install / Repair Backend" works without the package.
    $src = Join-Path $PackageRoot 'backend'
    if ((Test-Path (Join-Path $src 'Makefile')) -and
        -not [string]::Equals([System.IO.Path]::GetFullPath($src).TrimEnd('\'), [System.IO.Path]::GetFullPath($InstallBackendSrc).TrimEnd('\'), [System.StringComparison]::OrdinalIgnoreCase)) {
        Remove-Item $InstallBackendSrc -Recurse -Force -ErrorAction SilentlyContinue
        New-Item -ItemType Directory -Force -Path $InstallBackendSrc | Out-Null
        Copy-Item (Join-Path $src '*') $InstallBackendSrc -Recurse -Force
    }

    # Remove files from older versions.
    Remove-Item (Join-Path $InstallInstallerDir 'patch_mlvfs_fastpass.py') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $InstallInstallerDir 'Fix-Launcher.ps1') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $InstallDir 'resolve') -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $InstallDir 'UPDATE-SEAMLESS-IMPORT-ONLY.cmd') -Force -ErrorAction SilentlyContinue
    $legacyCommonResolveScripts = Join-Path $env:ProgramData 'Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Utility'
    foreach ($scriptName in @('MLV Resolve FS - Import and Sync Mounted Clips.lua','MLV Resolve FS - Import and Sync Mounted Clips.py','MLV Resolve FS - Sync Audio.py')) {
        Remove-Item (Join-Path $legacyCommonResolveScripts $scriptName) -Force -ErrorAction SilentlyContinue
    }

    @'
@echo off
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0app\MLVResolveFS-Launcher.ps1"
'@ | Set-Content -Encoding ASCII (Join-Path $InstallDir 'MLV Resolve FS.cmd')

    @'
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\Install-MLVResolveFS.ps1" -BackendOnly
'@ | Set-Content -Encoding ASCII (Join-Path $InstallDir 'REPAIR-OR-UPDATE.cmd')

    @'
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\Uninstall-MLVResolveFS.ps1"
'@ | Set-Content -Encoding ASCII (Join-Path $InstallDir 'UNINSTALL.cmd')

    $launcher = Join-Path $InstallAppDir 'MLVResolveFS-Launcher.ps1'
    New-LauncherShortcut $StartMenuShortcut $launcher
    if (-not $NoDesktopShortcut) {
        $desktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
        New-LauncherShortcut (Join-Path $desktop 'MLV Resolve FS.lnk') $launcher
    }
    Write-Log 'MLV Resolve FS launcher is now available from Desktop/Start Menu.' Green
}

function Test-WinFspInstalled {
    foreach ($path in @('HKLM:\SOFTWARE\WOW6432Node\WinFsp','HKLM:\SOFTWARE\WinFsp')) {
        if (Test-Path $path) { return $true }
    }
    return $false
}

function Install-WinFsp {
    if (Test-WinFspInstalled) { Write-Log 'WinFsp is already installed.' Green; return }
    Write-Log 'Installing WinFsp...' Cyan

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        $wargs = @('install','--id','WinFsp.WinFsp','-e','--source','winget','--accept-source-agreements','--accept-package-agreements','--silent')
        $p = Start-Process -FilePath $winget.Source -ArgumentList $wargs -Wait -PassThru -WindowStyle Hidden
        if ($p.ExitCode -eq 0 -and (Test-WinFspInstalled)) { Write-Log 'WinFsp installed via Windows Package Manager.' Green; return }
        Write-Log ('WinGet WinFsp install returned code {0}; trying official MSI.' -f $p.ExitCode) Yellow
    }

    $tmpMsi = Join-Path $env:TEMP 'winfsp-latest.msi'
    $release = Invoke-RestMethod -Uri 'https://api.github.com/repos/winfsp/winfsp/releases/latest' -Headers @{ 'User-Agent' = 'MLVResolveFS-Installer' }
    $asset = $release.assets | Where-Object { $_.name -match '^winfsp-.*\.msi$' } | Select-Object -First 1
    if (-not $asset) { throw 'Could not find a WinFsp MSI in the latest official release.' }
    Invoke-WebRequest -UseBasicParsing -Uri $asset.browser_download_url -OutFile $tmpMsi
    $msi = Start-Process -FilePath 'msiexec.exe' -ArgumentList @('/i', ('"{0}"' -f $tmpMsi), '/qn', '/norestart') -Wait -PassThru
    if ($msi.ExitCode -notin @(0,3010,1641)) { throw ('WinFsp MSI installation failed with exit code {0}.' -f $msi.ExitCode) }
    if (-not (Test-WinFspInstalled)) { throw 'WinFsp installation completed but WinFsp was not detected.' }
    Write-Log 'WinFsp installed.' Green
}

function Install-CygwinAndBuildTools {
    $needed = @('gcc.exe','make.exe','pkg-config.exe','cygfuse-2.8.dll')
    $have = $true
    foreach ($t in $needed) { if (-not (Test-Path (Join-Path $CygwinBin $t))) { $have = $false } }
    if ($have -and (Test-Path $BashExe) -and (Test-Path (Join-Path $CygwinRoot 'usr\include\fuse\fuse.h'))) {
        Write-Log 'Cygwin with compiler and cygfuse is already installed.' Green
        return
    }

    $setupExe = Join-Path $env:TEMP 'cygwin-setup-x86_64.exe'
    Write-Log 'Downloading the official Cygwin setup program...' Cyan
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -UseBasicParsing -Uri 'https://cygwin.com/setup-x86_64.exe' -OutFile $setupExe
    $packages = 'gcc-core,make,cygfuse,pkg-config'
    $mirrors = @('https://mirrors.kernel.org/sourceware/cygwin/','https://mirrorservice.org/sites/sourceware.org/pub/cygwin/')
    $success = $false
    foreach ($mirror in $mirrors) {
        Write-Log ('Installing/updating Cygwin packages from {0}' -f $mirror) Cyan
        $cargs = @('-q','-R',$CygwinRoot,'-s',$mirror,'-P',$packages,'-d','-N')
        $p = Start-Process -FilePath $setupExe -ArgumentList $cargs -Wait -PassThru
        if ($p.ExitCode -eq 0 -and (Test-Path $BashExe)) { $success = $true; break }
        Write-Log ('Cygwin setup returned code {0} using this mirror.' -f $p.ExitCode) Yellow
    }
    if (-not $success) { throw 'Cygwin setup did not complete successfully.' }
    foreach ($t in @('bash.exe','gcc.exe','make.exe')) {
        if (-not (Test-Path (Join-Path $CygwinBin $t))) { throw ('Required Cygwin tool is missing: {0}' -f (Join-Path $CygwinBin $t)) }
    }
    Write-Log 'Cygwin, compiler, Make and cygfuse are installed.' Green
}

# The backend executable cannot be replaced while a mount is using it.
function Stop-RunningBackends {
    $stopped = 0
    foreach ($name in @('mlvresolvefs','mlvfs')) {
        foreach ($p in @(Get-Process -Name $name -ErrorAction SilentlyContinue)) {
            $path = ''
            try { $path = $p.Path } catch {}
            if (-not $path -or $path -like "$CygwinRoot\*") {
                Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
                $stopped++
            }
        }
    }
    if ($stopped) {
        Write-Log ('Unmounted {0} running MLV Resolve FS drive(s) so the backend can be updated.' -f $stopped) Yellow
        Start-Sleep -Seconds 1
    }
}

function Build-Backend {
    Write-Log 'Building the MLV Resolve FS backend...' Cyan
    $srcDir = Get-BackendSourceDir
    $buildDir = Join-Path $CygwinRoot 'usr\local\src\mlvresolvefs'
    Remove-Item $buildDir -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $buildDir | Out-Null
    Copy-Item (Join-Path $srcDir '*') $buildDir -Recurse -Force
    New-Item -ItemType Directory -Force -Path $BackendDir | Out-Null

    $buildScriptWindows = Join-Path $CygwinRoot 'tmp\mlvresolvefs-build.sh'
    $buildStdout = Join-Path $env:TEMP 'mlvresolvefs-build-stdout.txt'
    $buildStderr = Join-Path $env:TEMP 'mlvresolvefs-build-stderr.txt'
    $buildScript = @'
set -euo pipefail
export PATH=/usr/local/bin:/usr/bin:/bin:$PATH
cd /usr/local/src/mlvresolvefs
echo "Cygwin FUSE: $(pkg-config --modversion fuse 2>/dev/null || echo 'pkg-config entry missing, using defaults')"
make clean >/dev/null 2>&1 || true
make
install -m 0755 mlvresolvefs.exe /opt/mlvresolvefs/bin/mlvresolvefs.exe
/opt/mlvresolvefs/bin/mlvresolvefs.exe --version
'@
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($buildScriptWindows, ($buildScript -replace "`r`n", "`n"), $utf8NoBom)

    # Run bash through Start-Process and judge success by its exit code only: gcc and make
    # write normal progress to stderr, which PowerShell 5 would otherwise treat as errors.
    Remove-Item $buildStdout, $buildStderr -Force -ErrorAction SilentlyContinue
    $p = Start-Process -FilePath $BashExe -ArgumentList @('--login','-c','/tmp/mlvresolvefs-build.sh') `
        -RedirectStandardOutput $buildStdout -RedirectStandardError $buildStderr -Wait -PassThru -NoNewWindow
    foreach ($f in @($buildStdout, $buildStderr)) {
        if (Test-Path $f) {
            Get-Content $f | ForEach-Object { Write-Host $_ -ForegroundColor DarkGray; Add-Content -Path $LogFile -Value $_ }
        }
    }
    if ($p.ExitCode -ne 0) { throw ('Backend build failed with exit code {0}. See {1}' -f $p.ExitCode, $LogFile) }
    if (-not (Test-Path $BackendExe)) { throw ('Build reported success but the backend is missing: {0}' -f $BackendExe) }
    Write-Log 'MLV Resolve FS backend built successfully.' Green
}

try {
    Write-Log ('MLV Resolve FS v{0} installer started.' -f $Version) Cyan
    Write-Log ('Installer log: {0}' -f $LogFile)
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'This installer currently supports 64-bit Windows only.' }

    if (-not $BackendOnly) {
        Install-LauncherFirst
    } else {
        Write-Log 'Backend-only repair mode: leaving installed launcher files untouched.' Cyan
    }
    Install-WinFsp
    Install-CygwinAndBuildTools
    Stop-RunningBackends
    Build-Backend

    Write-Log 'Installation complete.' Green
    Write-Host ''
    Write-Host 'MLV Resolve FS is installed and ready.' -ForegroundColor Green
    if (-not $BackendOnly) {
        Write-Host ''
        Write-Host 'Opening MLV Resolve FS as your normal user (not as Administrator)...' -ForegroundColor Yellow
        # explorer.exe starts the shortcut in the signed-in user's normal, non-elevated session,
        # which is the only session where the mounted drive is visible to Resolve.
        if (Test-Path $StartMenuShortcut) {
            Start-Process -FilePath (Join-Path $env:SystemRoot 'explorer.exe') -ArgumentList ('"{0}"' -f $StartMenuShortcut)
        }
        Write-Host 'You can close this window.' -ForegroundColor Yellow
        Start-Sleep -Seconds 4
    }
    exit 0
}
catch {
    Write-Log ('ERROR: {0}' -f $_.Exception.Message) Red
    Write-Host ''
    Write-Host 'The backend installation did not finish.' -ForegroundColor Red
    Write-Host ('Log: {0}' -f $LogFile) -ForegroundColor Cyan
    Read-Host 'Press Enter to close'
    exit 1
}
