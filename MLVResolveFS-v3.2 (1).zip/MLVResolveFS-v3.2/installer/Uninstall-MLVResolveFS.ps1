$ErrorActionPreference = 'Stop'

# Clean up the signed-in user's own state before elevating: the elevated session may belong to
# a different account when a standard user approves UAC with an administrator password.
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $userStartup = Join-Path ([Environment]::GetFolderPath('Startup')) 'MLV Resolve FS (auto mount).lnk'
    Remove-Item $userStartup -Force -ErrorAction SilentlyContinue
    $userState = Join-Path $env:LOCALAPPDATA 'MLVResolveFS'
    foreach ($f in @('backend.json','mlvfs.pid')) {
        $pf = Join-Path $userState $f
        if (Test-Path $pf) {
            try {
                $raw = Get-Content $pf -Raw
                $id = 0
                if ($raw.TrimStart().StartsWith('{')) { $id = [int](($raw | ConvertFrom-Json).pid) } else { $id = [int]$raw.Trim() }
                Stop-Process -Id $id -Force -ErrorAction SilentlyContinue
            } catch {}
        }
    }
    Remove-Item $userState -Recurse -Force -ErrorAction SilentlyContinue
    $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $PSCommandPath + '"'))
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argList
    exit
}

$InstallDir = Join-Path $env:ProgramFiles 'MLV Resolve FS'
$DataDir = Join-Path $env:ProgramData 'MLVResolveFS'
$StateDir = Join-Path $env:LOCALAPPDATA 'MLVResolveFS'
$CygwinRoot = 'C:\cygwin64'
$BackendDir = Join-Path $CygwinRoot 'opt\mlvresolvefs'

try {
    foreach ($name in @('mlvresolvefs','mlvfs')) {
        foreach ($p in @(Get-Process -Name $name -ErrorAction SilentlyContinue)) {
            $path = ''
            try { $path = $p.Path } catch {}
            if (-not $path -or $path -like "$CygwinRoot\*") { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
        }
    }
    Start-Sleep -Milliseconds 500

    Remove-Item (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\MLV Resolve FS.lnk') -Force -ErrorAction SilentlyContinue
    $commonDesktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
    Remove-Item (Join-Path $commonDesktop 'MLV Resolve FS.lnk') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path ([Environment]::GetFolderPath('Startup')) 'MLV Resolve FS (auto mount).lnk') -Force -ErrorAction SilentlyContinue

    foreach ($scriptName in @('MLV Resolve FS - Import and Sync Mounted Clips.lua','MLV Resolve FS - Sync Audio.py','MLV Resolve FS - Import and Sync Mounted Clips.py')) {
        Remove-Item (Join-Path $env:ProgramData ('Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Utility\' + $scriptName)) -Force -ErrorAction SilentlyContinue
        Remove-Item (Join-Path $env:APPDATA ('Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts\Utility\' + $scriptName)) -Force -ErrorAction SilentlyContinue
    }

    Remove-Item $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item $BackendDir -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $CygwinRoot 'usr\local\src\mlvresolvefs') -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item $DataDir -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item $StateDir -Recurse -Force -ErrorAction SilentlyContinue

    Write-Host 'MLV Resolve FS has been removed. Your MLV files were not touched.' -ForegroundColor Green
    Write-Host 'WinFsp and Cygwin were left installed because other programs may use them.' -ForegroundColor Yellow
    Start-Sleep -Seconds 3
} catch {
    Write-Host ('Uninstall error: ' + $_.Exception.Message) -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}
