@echo off
setlocal
cd /d "%~dp0"

rem Installs or updates MLV Resolve FS v3.2 (asks for Administrator approval).
rem Remove Resolve helper scripts left by older versions for the CURRENT user before elevation.
set "RESOLVE_SCRIPT_DIR=%APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts\Utility"
for %%F in (
  "MLV Resolve FS - Import and Sync Mounted Clips.lua"
  "MLV Resolve FS - Import and Sync Mounted Clips.py"
  "MLV Resolve FS - Sync Audio.py"
) do (
  if exist "%RESOLVE_SCRIPT_DIR%\%%~F" del /Q "%RESOLVE_SCRIPT_DIR%\%%~F" >nul 2>&1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\Install-MLVResolveFS.ps1"
