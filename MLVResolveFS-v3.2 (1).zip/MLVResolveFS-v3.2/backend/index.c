/* MLV indexing, frame loading and level detection. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <math.h>
#include <errno.h>
#include "common.h"
#include "lj92.h"

#ifndef O_BINARY
# define O_BINARY 0
#endif

int clip_read(clip_t *c, uint16_t file, uint64_t off, void *buf, size_t len)
{
    if (file >= c->nfiles || c->fds[file] < 0) return -EIO;
    size_t done = 0;
    while (done < len) {
        ssize_t r = pread(c->fds[file], (char *)buf + done, len - done, (off_t)(off + done));
        if (r < 0) { if (errno == EINTR) continue; return -errno; }
        if (r == 0) return -EIO;
        done += (size_t)r;
    }
    return 0;
}

static int cmp_frames(const void *a, const void *b)
{
    const frame_ref_t *x = a, *y = b;
    if (x->frameNumber != y->frameNumber) return x->frameNumber < y->frameNumber ? -1 : 1;
    return 0;
}

static int cmp_audio(const void *a, const void *b)
{
    const audio_ref_t *x = a, *y = b;
    if (x->frameNumber != y->frameNumber) return x->frameNumber < y->frameNumber ? -1 : 1;
    return 0;
}

#define GRAB(name, type) do { \
        if (!c->have_##name && hdr.blockSize >= sizeof(type)) { \
            if (clip_read(c, (uint16_t)f, pos, &c->name, sizeof(type)) == 0) c->have_##name = 1; \
        } } while (0)

static int scan_chunk(clip_t *c, int f, size_t *cap_v, size_t *cap_a)
{
    off_t end = lseek(c->fds[f], 0, SEEK_END);
    uint64_t pos = 0;
    while (pos + sizeof(mlv_hdr_t) <= (uint64_t)end) {
        mlv_hdr_t hdr;
        if (clip_read(c, (uint16_t)f, pos, &hdr, sizeof(hdr))) break;
        if (hdr.blockSize < sizeof(mlv_hdr_t) || pos + hdr.blockSize > (uint64_t)end) {
            if (g_opt.verbose) mrfs_log("%s: chunk %d truncated/invalid block at %llu\n",
                                        c->base, f, (unsigned long long)pos);
            break;
        }
        const char *t = (const char *)hdr.blockType;
        if (!memcmp(t, "MLVI", 4)) {
            if (f == 0) clip_read(c, 0, pos, &c->mlvi, sizeof(c->mlvi));
        } else if (!memcmp(t, "VIDF", 4)) {
            mlv_vidf_hdr_t v;
            if (clip_read(c, (uint16_t)f, pos, &v, sizeof(v)) == 0 &&
                hdr.blockSize > sizeof(v) + v.frameSpace) {
                if (c->nframes == *cap_v) {
                    *cap_v = *cap_v ? *cap_v * 2 : 1024;
                    c->frames = realloc(c->frames, *cap_v * sizeof(frame_ref_t));
                }
                frame_ref_t *fr = &c->frames[c->nframes++];
                fr->file = (uint16_t)f;
                fr->off = pos + sizeof(v) + v.frameSpace;
                fr->size = hdr.blockSize - (uint32_t)sizeof(v) - v.frameSpace;
                fr->frameNumber = v.frameNumber;
                fr->timestamp = hdr.timestamp;
            }
        } else if (!memcmp(t, "AUDF", 4)) {
            mlv_audf_hdr_t a;
            if (clip_read(c, (uint16_t)f, pos, &a, sizeof(a)) == 0 &&
                hdr.blockSize > sizeof(a) + a.frameSpace) {
                if (c->naudio == *cap_a) {
                    *cap_a = *cap_a ? *cap_a * 2 : 256;
                    c->audio = realloc(c->audio, *cap_a * sizeof(audio_ref_t));
                }
                audio_ref_t *ar = &c->audio[c->naudio++];
                ar->file = (uint16_t)f;
                ar->off = pos + sizeof(a) + a.frameSpace;
                ar->size = hdr.blockSize - (uint32_t)sizeof(a) - a.frameSpace;
                ar->frameNumber = a.frameNumber;
                ar->timestamp = hdr.timestamp;
            }
        } else if (!memcmp(t, "RAWI", 4)) GRAB(rawi, mlv_rawi_hdr_t);
        else if (!memcmp(t, "RAWC", 4)) GRAB(rawc, mlv_rawc_hdr_t);
        else if (!memcmp(t, "IDNT", 4)) GRAB(idnt, mlv_idnt_hdr_t);
        else if (!memcmp(t, "EXPO", 4)) GRAB(expo, mlv_expo_hdr_t);
        else if (!memcmp(t, "LENS", 4)) GRAB(lens, mlv_lens_hdr_t);
        else if (!memcmp(t, "RTCI", 4)) GRAB(rtci, mlv_rtci_hdr_t);
        else if (!memcmp(t, "WBAL", 4)) GRAB(wbal, mlv_wbal_hdr_t);
        else if (!memcmp(t, "WAVI", 4)) GRAB(wavi, mlv_wavi_hdr_t);
        else if (!memcmp(t, "DISO", 4)) GRAB(diso, mlv_diso_hdr_t);
        pos += hdr.blockSize;
    }
    return 0;
}

/* ML packs pixels MSB-first into a stream of little-endian 16-bit words. */
static void unpack_bits(const uint8_t *src, size_t srclen, uint16_t *dst, size_t n, int bpp)
{
    uint64_t acc = 0; int have = 0; size_t si = 0;
    uint32_t mask = (1u << bpp) - 1;
    for (size_t i = 0; i < n; i++) {
        while (have < bpp) {
            uint16_t w = 0;
            if (si + 1 < srclen) w = (uint16_t)(src[si] | (src[si + 1] << 8));
            si += 2;
            acc = (acc << 16) | w;
            have += 16;
        }
        dst[i] = (uint16_t)((acc >> (have - bpp)) & mask);
        have -= bpp;
    }
}

int clip_load_frame_raw(clip_t *c, uint32_t idx, uint16_t *out)
{
    if (idx >= c->nframes) return -EINVAL;
    frame_ref_t *fr = &c->frames[idx];
    uint8_t *buf = malloc(fr->size + 16);
    if (!buf) return -ENOMEM;
    int r = clip_read(c, fr->file, fr->off, buf, fr->size);
    if (r) { free(buf); return r; }
    size_t n = (size_t)c->width * c->height;
    if (c->compressed) {
        r = lj92_decode(buf, fr->size, out, n);
        if (r) {
            mrfs_log("%s: LJ92 decode failed on frame %u (error %d)\n", c->base, idx, r);
            memset(out, 0, n * 2);
            r = -EIO;
        }
    } else {
        unpack_bits(buf, fr->size, out, n, c->bpp);
    }
    free(buf);
    return r;
}

/* Rows at the top/bottom edge that hold junk instead of image data. Seen on 70D crop
 * recordings: the last 8 lines of a 3200x1318 frame are a constant/garbage band, which
 * Resolve shows as a bright line at the bottom of the picture. */
static void row_stats(const uint16_t *r, int W, double *mean, double *sd)
{
    double s = 0, s2 = 0; int n = 0;
    for (int x = 0; x < W; x += 2) { s += r[x]; s2 += (double)r[x] * r[x]; n++; }
    *mean = s / n; *sd = sqrt(fmax(0, s2 / n - *mean * *mean));
}

static int junk_rows(const clip_t *c, const uint16_t *img, int from_bottom)
{
    int W = c->width, H = c->height;
    if (H < 128) return 0;
    double rm = 0, rs = 0;
    for (int k = 0; k < 8; k++) {
        int y = from_bottom ? H - 48 + k : 40 + k;
        double m, sd; row_stats(img + (size_t)y * W, W, &m, &sd); rm += m / 8; rs += sd / 8;
    }
    double range = c->white > c->black ? c->white - c->black : 1;
    int n = 0;
    for (int k = 0; k < 32; k++) {
        int y = from_bottom ? H - 1 - k : k;
        double m, sd; row_stats(img + (size_t)y * W, W, &m, &sd);
        int junk = fabs(m - rm) > 0.35 * range + 4 * rs || (sd < 0.5 && rs > 4) || sd > 6 * rs + 0.1 * range;
        if (!junk) break;
        n++;
    }
    return (n + 1) & ~1;    /* keep the CFA phase */
}

/* Real clipping point from a histogram: clipped pixels form a pile of counts at the top of the
 * data, often smeared over a few values (2950..2964 in a 70D crop clip). Returns the value
 * just below where the pile starts (everything >= it is clipped), or 0 if there is no pile.
 * A few hot pixels above the pile are ignored. */
static int clip_pileup(const uint32_t *hist, int black, size_t counted)
{
    uint32_t need = (uint32_t)(counted / 1000000); if (need < 4) need = 4;
    int top = 0;
    for (int v = 65535; v > black; v--) if (hist[v] >= need) { top = v; break; }
    if (top <= black + 128) return 0;
    int p = top;
    for (int v = top; v >= top - 96 && v > black; v--) if (hist[v] > hist[p]) p = v;
    /* baseline: median count well below the pile */
    uint32_t tmp[141]; int n = 0;
    for (int v = p - 200; v <= p - 60; v++) if (v > black) tmp[n++] = hist[v];
    if (n < 20) return 0;
    for (int i = 1; i < n; i++) { uint32_t t = tmp[i]; int j = i - 1; while (j >= 0 && tmp[j] > t) { tmp[j + 1] = tmp[j]; j--; } tmp[j + 1] = t; }
    double base = tmp[n / 2];
    if (hist[p] < 40.0 * (base + 1)) return 0;
    double thr = 4.0 * (base + 1); if (thr < hist[p] / 50.0) thr = hist[p] / 50.0;
    int v0 = p;
    while (v0 - 1 > black && hist[v0 - 1] > thr) v0--;
    uint64_t mass = 0;
    for (int v = v0; v <= top; v++) mass += hist[v];
    if (mass < counted / 20000) return 0;
    return v0 - 1;
}

/* Find the real clipping point and junk edge rows. Some ML builds write a RAWI white
 * level that the data provably exceeds; then full scale is used. Junk rows are ignored so
 * they cannot fake a clipping point. */
static void detect_levels(clip_t *c)
{
    int W = c->width, H = c->height;
    size_t n = (size_t)W * H;
    uint16_t *img = malloc(n * 2);
    uint32_t *hist = calloc(65536, sizeof(uint32_t));
    if (!img || !hist) { free(img); free(hist); return; }
    uint32_t picks[3] = { 0, c->nframes / 2, c->nframes ? c->nframes - 1 : 0 };
    int used = 0, jt = 0, jb = 0;
    size_t counted = 0;
    for (int k = 0; k < 3; k++) {
        if (k && picks[k] == picks[k - 1]) continue;
        if (clip_load_frame_raw(c, picks[k], img)) continue;
        int t = junk_rows(c, img, 0), b = junk_rows(c, img, 1);
        if (t > jt) jt = t;
        if (b > jb) jb = b;
        for (int y = 32; y < H - 32; y++)
            for (int x = 0; x < W; x++) hist[img[(size_t)y * W + x]]++;
        counted += (size_t)(H - 64) * W;
        used++;
    }
    if (jt + jb >= H / 4) jt = jb = 0;
    c->junk_top = jt; c->junk_bottom = jb;
    if (jt || jb)
        mrfs_log("%s: %d junk row(s) at the top and %d at the bottom; cropped via DefaultCrop%s\n",
                 c->base, jt, jb, g_opt.fix_edges ? " and repaired" : "");
    if (used) {
        uint32_t need = (uint32_t)(counted / 20000); if (need < 16) need = 16;
        int hi = 0;
        for (int v = 65535; v > 0; v--) if (hist[v] >= need) { hi = v; break; }
        int rawi_white = c->white;
        int limit = (1 << c->bpp) - 1;
        int pile = clip_pileup(hist, c->black, counted);
        if (pile > c->black + 64) {
            /* v3.1.2: clipped pixels pile up just below the real clipping point. Use where the
             * pile starts, whether that is above the RAWI white (70D crop modes: data to 2964,
             * RAWI 2761) or below it (70D LV: data to ~4932, RAWI 5586). Values at or above it
             * are clipped, so Resolve's highlight handling sees them as clipped. */
            if (pile != rawi_white)
                mrfs_log("%s: data clips at %d (pile-up), RAWI white level is %d; using %d\n",
                         c->base, pile, rawi_white, pile);
            c->white = pile;
        } else if (hi > rawi_white + (rawi_white - c->black) / 50 + 4) {
            int w = hi > limit ? hi : limit;
            mrfs_log("%s: data goes up to %d but RAWI white level is %d and no clipping point is visible; using %d\n",
                     c->base, hi, rawi_white, w);
            c->white = w;
        }
        if (c->white > limit && c->bpp < 16) c->white = limit;
    }
    free(img); free(hist);
}

void repair_edges(const clip_t *c, uint16_t *img)
{
    /* copy the nearest good row of the same CFA phase over each junk row */
    int W = c->width, H = c->height, jb = c->junk_bottom, jt = c->junk_top;
    for (int y = H - jb; y < H; y++) {
        int src = y - 2;
        while (src >= H - jb) src -= 2;
        if (src >= 0) memcpy(img + (size_t)y * W, img + (size_t)src * W, (size_t)W * 2);
    }
    for (int y = 0; y < jt; y++) {
        int src = y + 2;
        while (src < jt) src += 2;
        if (src < H) memcpy(img + (size_t)y * W, img + (size_t)src * W, (size_t)W * 2);
    }
}

/* Place the audio on the video time axis (first AUDF vs first VIDF timestamp) and make the
 * WAV exactly as long as the video, like the camera's own clock says. Computed once. */
static void audio_align(clip_t *c)
{
    c->audio_lead = 0;
    c->wav_data_bytes = 0;
    if (!c->have_wavi || !c->naudio || !c->wavi.bytesPerSecond) return;
    uint32_t align = c->wavi.blockAlign ? c->wavi.blockAlign
                   : (uint32_t)(c->wavi.channels ? c->wavi.channels : 2) * ((c->wavi.bitsPerSample + 7) / 8);
    if (!align) align = 4;
    c->audio_align = align;

    uint64_t v0 = c->frames[0].timestamp, a0 = c->audio[0].timestamp;
    for (uint32_t i = 1; i < c->nframes && i < 16; i++) if (c->frames[i].timestamp < v0) v0 = c->frames[i].timestamp;
    int64_t delta_us = (int64_t)a0 - (int64_t)v0;
    if (delta_us > -2000000 && delta_us < 2000000) {
        int64_t b = delta_us * (int64_t)c->wavi.bytesPerSecond / 1000000;
        b -= b % (int64_t)align;
        c->audio_lead = b;                 /* >0: silence first, <0: skip leading audio */
    }

    /* duration of the recording itself (not an FPS override) */
    uint64_t num = c->mlvi.sourceFpsNom, den = c->mlvi.sourceFpsDenom;
    if (!num || !den) { num = c->fps_num; den = c->fps_den; }
    uint64_t bytes = ((uint64_t)c->nframes * den * c->wavi.bytesPerSecond + num - 1) / num;
    bytes += (align - bytes % align) % align;
    if (!bytes) bytes = c->audio_bytes - c->audio_bytes % align;
    c->wav_data_bytes = bytes;
    if (g_opt.verbose)
        mrfs_log("%s: audio offset %lld bytes, WAV data %llu bytes (recorded %llu)\n", c->base,
                 (long long)c->audio_lead, (unsigned long long)bytes, (unsigned long long)c->audio_bytes);
}

int clip_index(clip_t *c)
{
    pthread_mutex_lock(&c->lock);
    if (c->indexed || c->index_failed) {
        int r = c->indexed ? 0 : -EIO;
        pthread_mutex_unlock(&c->lock);
        return r;
    }
    size_t cap_v = 0, cap_a = 0;
    for (int f = 0; f < c->nfiles; f++) {
        if (c->fds[f] < 0) c->fds[f] = open(c->paths[f], O_RDONLY | O_BINARY);
        if (c->fds[f] < 0) continue;
        scan_chunk(c, f, &cap_v, &cap_a);
    }
    if (!c->have_rawi || !c->nframes) {
        mrfs_log("%s: no RAWI block or no video frames, skipping\n", c->base);
        c->index_failed = 1;
        pthread_mutex_unlock(&c->lock);
        return -EIO;
    }
    qsort(c->frames, c->nframes, sizeof(frame_ref_t), cmp_frames);
    /* drop duplicate frame numbers (can happen with BKUP or re-written blocks) */
    uint32_t w = 0;
    for (uint32_t i = 0; i < c->nframes; i++) {
        if (w && c->frames[w - 1].frameNumber == c->frames[i].frameNumber) continue;
        c->frames[w++] = c->frames[i];
    }
    c->nframes = w;

    if (c->naudio) {
        qsort(c->audio, c->naudio, sizeof(audio_ref_t), cmp_audio);
        uint64_t v = 0;
        for (uint32_t i = 0; i < c->naudio; i++) { c->audio[i].vstart = v; v += c->audio[i].size; }
        c->audio_bytes = v;
    }

    raw_info_t *ri = &c->rawi.raw_info;
    c->width = c->rawi.xRes;
    c->height = c->rawi.yRes;
    c->bpp = ri->bits_per_pixel ? ri->bits_per_pixel : 14;
    c->black = ri->black_level;
    c->white = ri->white_level;
    c->compressed = (c->mlvi.videoClass & MLV_VIDEO_CLASS_FLAG_LJ92) != 0;
    if (c->mlvi.videoClass & (MLV_VIDEO_CLASS_FLAG_LZMA | MLV_VIDEO_CLASS_FLAG_DELTA)) {
        mrfs_log("%s: LZMA/delta compressed MLV (video class 0x%x) is not supported; "
                 "convert it with mlv_dump first\n", c->base, c->mlvi.videoClass);
        c->index_failed = 1;
        pthread_mutex_unlock(&c->lock);
        return -EIO;
    }

    /* Some cameras write lossless frames without the flag; sniff the payload. */
    uint8_t sniff[2] = {0};
    clip_read(c, c->frames[0].file, c->frames[0].off, sniff, 2);
    if (!c->compressed && sniff[0] == 0xFF && sniff[1] == 0xD8) c->compressed = 1;

    c->fastpass = 0;
    if (c->compressed) {
        uint8_t head[1024];
        uint32_t hl = c->frames[0].size < sizeof(head) ? c->frames[0].size : sizeof(head);
        lj92_info_t li;
        if (clip_read(c, c->frames[0].file, c->frames[0].off, head, hl) == 0 &&
            lj92_probe(head, hl, &li) == 0) {
            if (li.width * li.components == c->width && li.height == c->height &&
                li.components <= 2 && g_opt.fastpass && !needs_processing())
                c->fastpass = 1;
            if (g_opt.verbose)
                mrfs_log("%s: LJ92 %d-bit %dx%d x%d components -> %s\n", c->base, li.precision,
                         li.width, li.height, li.components, c->fastpass ? "fast pass" : "decode");
        }
    }

    if (g_opt.white_override > 0) c->white = g_opt.white_override;
    else detect_levels(c);
    c->out_black = c->black;
    c->out_white = c->white;
    if (c->fastpass && g_opt.fix_edges && (c->junk_top || c->junk_bottom)) c->fastpass = 0;

    /* frame rate */
    if (g_opt.fps_override > 0) {
        c->fps_num = (uint32_t)llround(g_opt.fps_override * 1000.0);
        c->fps_den = 1000;
    } else if (c->mlvi.sourceFpsNom && c->mlvi.sourceFpsDenom) {
        c->fps_num = c->mlvi.sourceFpsNom;
        c->fps_den = c->mlvi.sourceFpsDenom;
    } else { c->fps_num = 24000; c->fps_den = 1001; }
    /* normalise the usual NTSC rates so Resolve sees 23.976/29.97/59.94 exactly */
    double fps = (double)c->fps_num / c->fps_den;
    static const struct { double f; uint32_t n, d; } std[] = {
        {23.976, 24000, 1001}, {29.97, 30000, 1001}, {59.94, 60000, 1001}, {47.952, 48000, 1001},
        {24, 24, 1}, {25, 25, 1}, {30, 30, 1}, {48, 48, 1}, {50, 50, 1}, {60, 60, 1}};
    for (size_t k = 0; k < sizeof(std) / sizeof(std[0]); k++)
        if (fabs(fps - std[k].f) < 0.0105) { c->fps_num = std[k].n; c->fps_den = std[k].d; break; }

    int base = (int)llround((double)c->fps_num / c->fps_den);
    if (base < 1) base = 1;
    if (c->have_rtci)
        c->tc_start_frames = ((uint64_t)c->rtci.tm_hour * 3600 + c->rtci.tm_min * 60 + c->rtci.tm_sec) * base;
    else
        c->tc_start_frames = 0;

    audio_align(c);
    if (needs_processing()) process_prepare(c);
    dng_build_template(c);
    wav_build_header(c);
    c->indexed = 1;
    mrfs_log("%s: %u frames %dx%d %d-bit%s%s, %.3f fps, levels %d/%d, audio %s\n",
             c->dirname, c->nframes, c->width, c->height, c->bpp,
             c->compressed ? " lossless" : "", c->fastpass ? " (fast pass)" : "",
             (double)c->fps_num / c->fps_den, c->out_black, c->out_white,
             c->naudio && c->have_wavi ? "yes" : "no");
    pthread_mutex_unlock(&c->lock);
    return 0;
}
