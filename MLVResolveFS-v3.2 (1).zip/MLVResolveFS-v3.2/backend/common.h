#ifndef MRFS_COMMON_H
#define MRFS_COMMON_H

#include <stdint.h>
#include <stddef.h>
#include <pthread.h>
#include "mlv.h"

#define MRFS_VERSION "3.2.0"

typedef struct {
    uint16_t file;          /* chunk index */
    uint64_t off;           /* payload offset in chunk */
    uint32_t size;          /* payload size */
    uint32_t frameNumber;
    uint64_t timestamp;
} frame_ref_t;

typedef struct {
    uint16_t file;
    uint64_t off;
    uint32_t size;
    uint64_t vstart;        /* start offset inside the virtual data stream */
    uint32_t frameNumber;
    uint64_t timestamp;
} audio_ref_t;

typedef struct {
    int      enabled;
    double   ratio;         /* bright / dark exposure ratio */
    int      bright[8];     /* 1 if row (y % 8) is the bright ISO (2-row pairs or 4-row groups) */
    int      group;         /* rows per gain group: 2 or 4 */
    int      clip;          /* where the data really clips (<= white) */
} diso_params_t;

typedef struct clip {
    char     dirname[512];  /* virtual folder name */
    char     base[256];     /* file base name, e.g. M22-1423 */
    char   **paths;
    int      nfiles;
    int     *fds;
    time_t   mtime;

    pthread_mutex_t lock;
    int      indexed;
    int      index_failed;

    mlv_file_hdr_t mlvi;
    mlv_rawi_hdr_t rawi; int have_rawi;
    mlv_rawc_hdr_t rawc; int have_rawc;
    mlv_idnt_hdr_t idnt; int have_idnt;
    mlv_expo_hdr_t expo; int have_expo;
    mlv_lens_hdr_t lens; int have_lens;
    mlv_rtci_hdr_t rtci; int have_rtci;
    mlv_wbal_hdr_t wbal; int have_wbal;
    mlv_wavi_hdr_t wavi; int have_wavi;
    mlv_diso_hdr_t diso; int have_diso;

    frame_ref_t *frames; uint32_t nframes;
    audio_ref_t *audio;  uint32_t naudio;
    uint64_t audio_bytes;        /* sum of AUDF payloads */
    int64_t  audio_lead;         /* bytes of silence (>0) or bytes skipped (<0) */
    uint32_t audio_align;
    uint64_t wav_data_bytes;

    int      width, height;
    int      compressed;         /* LJ92 */
    int      fastpass;           /* serve the LJ92 payload untouched */
    int      bpp;
    int      black, white;       /* levels in the source data */
    int      out_black, out_white;
    int      junk_top, junk_bottom;   /* corrupt edge rows */
    uint32_t fps_num, fps_den;
    uint64_t tc_start_frames;    /* timecode of frame 0, in nominal frames */

    uint32_t dng_hdr_size;
    uint8_t *dng_hdr;            /* template */
    uint32_t off_tc, off_stripbytes; /* patch offsets in template */

    uint8_t  wav_hdr[1024];       /* RIFF + fmt + bext(602) + data = 654 bytes */
    uint32_t wav_hdr_size;

    /* processing state, computed once per clip */
    int      proc_ready;
    uint32_t *badpix; uint32_t nbadpix;
    float    stripe_gain[8]; int stripes_on;
    diso_params_t dual;
} clip_t;

typedef struct {
    char    *source;
    char    *mountpoint;
    int      resolve_naming;
    int      badpix;
    int      stripes;
    int      chroma;        /* 0, 2 (2x2) or 3 (3x3) */
    int      dualiso;       /* 0 off, 1 preview, 2 full */
    int      prefetch;
    int      threads;
    double   fps_override;
    int      fastpass;      /* 1 auto (default), 0 always decode */
    int      white_override;
    int      fix_edges;
    char    *logfile;
    int      verbose;
} options_t;

extern options_t g_opt;

void mrfs_log(const char *fmt, ...) __attribute__((format(printf, 1, 2)));

/* index.c */
int  clip_index(clip_t *c);
int  clip_read(clip_t *c, uint16_t file, uint64_t off, void *buf, size_t len);
int  clip_load_frame_raw(clip_t *c, uint32_t idx, uint16_t *out);  /* decoded samples */
void repair_edges(const clip_t *c, uint16_t *img);

/* dng.c */
int  dng_build_template(clip_t *c);
void dng_patch_header(const clip_t *c, uint32_t frame, uint8_t *hdr_out);
uint64_t dng_file_size(const clip_t *c, uint32_t frame);

/* wav.c */
void wav_build_header(clip_t *c);
int  wav_read(clip_t *c, char *buf, size_t size, uint64_t offset);
uint64_t wav_file_size(const clip_t *c);

/* process.c */
int  needs_processing(void);
void process_prepare(clip_t *c);
void process_frame(clip_t *c, uint16_t *img);

#endif
