# MLV Resolve FS v3.2 - Source

## Files

- `app/MLVResolveFS-Launcher.ps1` - Windows GUI launcher: mount/unmount, drive detection, auto-mount at sign-in.
- `installer/Install-MLVResolveFS.ps1` - installer: WinFsp, Cygwin (gcc, make, cygfuse, pkg-config), backend build, shortcuts.
- `installer/Uninstall-MLVResolveFS.ps1` - uninstaller.
- `backend/` - the file system itself (C). Same source builds on:
  - Windows: Cygwin + WinFsp `cygfuse` (FUSE 2.8 API) -> `C:\cygwin64\opt\mlvresolvefs\bin\mlvresolvefs.exe`
  - Linux: libfuse3 (`make`) or libfuse 2.9 (`make FUSE=2`)
- `*.cmd` - Explorer entry points.

## Backend layout

| File | Purpose |
|---|---|
| `main.c` | FUSE operations, clip discovery, frame cache, read-ahead workers, command line |
| `index.c` | MLV block index (once per clip), spanned `.M00` chunks, white level / junk row detection, audio alignment |
| `lj92.c` | Lossless JPEG decoder (used only when processing is enabled) |
| `dng.c` | CinemaDNG header (Fast Pass: original LJ92 payload; otherwise 16-bit uncompressed) |
| `wav.c` | Broadcast WAV with `bext` time reference |
| `process.c` | Bad pixels, vertical stripes, chroma smoothing, dual ISO |

## Command line

```
mlvresolvefs.exe [--plain-naming] [--bad-pixels] [--stripes] [--chroma=2] [--dual-iso=1|2]
                 [--fix-edges] [--prefetch=N] [--fps=F] [--white=N] [--log=FILE]
                 -f -o uid=-1,gid=-1,volname=MLVRESOLVE,FileInfoTimeout=-1,DirInfoTimeout=5000
                 /cygdrive/d/MLV R:
```

## Verification done for v3.0

- Fast Pass DNG payloads are byte-identical to MLV App's lossless export (70D test frames).
- LJ92 decoder is bit-exact against MLV App's uncompressed export.
- FUSE 2 and FUSE 3 builds produce byte-identical files; AddressSanitizer clean with all
  processing options; 24-thread random-read stress test without errors.
- Backend compiles warning-free against WinFsp 2.1's FUSE headers in Cygwin mode; the WinFsp
  mount options used were checked against the option table in `winfsp-x64.dll`.
- Not run on Windows itself by the author of this build: please report the log if anything fails.
