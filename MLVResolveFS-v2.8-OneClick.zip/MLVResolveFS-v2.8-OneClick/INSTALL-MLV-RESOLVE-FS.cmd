@echo off
setlocal
cd /d "%~dp0"

rem v2.8 no longer installs Resolve scripts. Remove helpers left by older versions
rem from the CURRENT Windows user's Resolve Utility folder before UAC elevation.
set "RESOLVE_SCRIPT_DIR=%APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts\Utility"
for %%F in (
  "MLV Resolve FS - Import and Sync Mounted Clips.lua"
  "MLV Resolve FS - Import and Sync Mounted Clips.py"
  "MLV Resolve FS - Sync Audio.py"
) do (
  if exist "%RESOLVE_SCRIPT_DIR%\%%~F" del /Q "%RESOLVE_SCRIPT_DIR%\%%~F" >nul 2>&1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\Install-MLVResolveFS.ps1"
