@echo off
set "APP=C:\Program Files\MLV Resolve FS\app\MLVResolveFS-Launcher.ps1"
if exist "%APP%" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%APP%"
) else (
  call "%~dp0INSTALL-MLV-RESOLVE-FS.cmd"
)
