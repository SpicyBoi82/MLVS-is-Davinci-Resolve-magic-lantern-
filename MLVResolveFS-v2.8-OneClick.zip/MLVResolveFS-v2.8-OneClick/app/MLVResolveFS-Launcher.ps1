Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ErrorActionPreference = 'Stop'

$InstallDir = Join-Path $env:ProgramFiles 'MLV Resolve FS'
$RepairInstaller = Join-Path $InstallDir 'installer\Install-MLVResolveFS.ps1'
$CygwinRoot = 'C:\cygwin64'
$BackendExe = Join-Path $CygwinRoot 'opt\mlvresolvefs\bin\mlvfs.exe'
$CygpathExe = Join-Path $CygwinRoot 'bin\cygpath.exe'
$StateDir = Join-Path $env:LOCALAPPDATA 'MLVResolveFS'
$PidFile = Join-Path $StateDir 'mlvfs.pid'
$ConfigFile = Join-Path $StateDir 'config.json'
$MountLogOut = Join-Path $StateDir 'mount-stdout.log'
$MountLogErr = Join-Path $StateDir 'mount-stderr.log'
New-Item -ItemType Directory -Force -Path $StateDir | Out-Null

function Get-MountedProcess {
    if (-not (Test-Path $PidFile)) { return $null }
    try {
        $processId = [int](Get-Content $PidFile -ErrorAction Stop | Select-Object -First 1)
        return Get-Process -Id $processId -ErrorAction SilentlyContinue
    } catch { return $null }
}

function Get-AvailableDriveLetters {
    $used = @(Get-PSDrive -PSProvider FileSystem | ForEach-Object { $_.Name.ToUpperInvariant() })
    $preferred = @('R','S','T','U','V','W','X','Y','Z')
    return @($preferred | Where-Object { $used -notcontains $_ })
}

function Convert-ToCygwinPath([string]$Path) {
    if (-not (Test-Path $CygpathExe)) { throw 'Cygwin is not installed yet. Click Install / Repair Backend.' }
    $result = & $CygpathExe -u $Path
    if ($LASTEXITCODE -ne 0 -or -not $result) { throw 'Could not convert the source folder to a Cygwin path.' }
    return ($result | Select-Object -First 1).Trim()
}

function Quote-ProcessArgument([string]$Value) {
    return '"' + ($Value -replace '"','\"') + '"'
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'MLV Resolve FS v2.8'
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(640, 610)
$form.MinimumSize = New-Object System.Drawing.Size(640, 610)
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'Magic Lantern MLV -> DaVinci Resolve'
$title.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 15)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(20, 18)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = 'Mount MLV footage as cleanly named virtual CinemaDNG + WAV media.'
$subtitle.AutoSize = $true
$subtitle.Location = New-Object System.Drawing.Point(22, 55)
$form.Controls.Add($subtitle)

$backendStatus = New-Object System.Windows.Forms.Label
$backendStatus.AutoSize = $true
$backendStatus.Location = New-Object System.Drawing.Point(22, 83)
$form.Controls.Add($backendStatus)

$repairButton = New-Object System.Windows.Forms.Button
$repairButton.Text = 'Install / Repair Backend'
$repairButton.Location = New-Object System.Drawing.Point(405, 75)
$repairButton.Size = New-Object System.Drawing.Size(195, 32)
$form.Controls.Add($repairButton)

$sourceLabel = New-Object System.Windows.Forms.Label
$sourceLabel.Text = 'MLV source folder'
$sourceLabel.AutoSize = $true
$sourceLabel.Location = New-Object System.Drawing.Point(22, 122)
$form.Controls.Add($sourceLabel)

$sourceBox = New-Object System.Windows.Forms.TextBox
$sourceBox.Location = New-Object System.Drawing.Point(22, 146)
$sourceBox.Size = New-Object System.Drawing.Size(485, 28)
$form.Controls.Add($sourceBox)

$browseButton = New-Object System.Windows.Forms.Button
$browseButton.Text = 'Browse...'
$browseButton.Location = New-Object System.Drawing.Point(515, 144)
$browseButton.Size = New-Object System.Drawing.Size(85, 31)
$form.Controls.Add($browseButton)

$driveLabel = New-Object System.Windows.Forms.Label
$driveLabel.Text = 'Virtual drive'
$driveLabel.AutoSize = $true
$driveLabel.Location = New-Object System.Drawing.Point(22, 190)
$form.Controls.Add($driveLabel)

$driveCombo = New-Object System.Windows.Forms.ComboBox
$driveCombo.DropDownStyle = 'DropDownList'
$driveCombo.Location = New-Object System.Drawing.Point(22, 214)
$driveCombo.Size = New-Object System.Drawing.Size(100, 28)
foreach ($letter in (Get-AvailableDriveLetters)) { [void]$driveCombo.Items.Add("$letter`:") }
if ($driveCombo.Items.Count -gt 0) { $driveCombo.SelectedIndex = 0 }
$form.Controls.Add($driveCombo)

$prefetchLabel = New-Object System.Windows.Forms.Label
$prefetchLabel.Text = 'Prefetch frames'
$prefetchLabel.AutoSize = $true
$prefetchLabel.Location = New-Object System.Drawing.Point(150, 190)
$form.Controls.Add($prefetchLabel)

$prefetch = New-Object System.Windows.Forms.NumericUpDown
$prefetch.Minimum = 0
$prefetch.Maximum = 64
$prefetch.Value = 8
$prefetch.Location = New-Object System.Drawing.Point(150, 214)
$prefetch.Size = New-Object System.Drawing.Size(100, 28)
$form.Controls.Add($prefetch)

$fpsLabel = New-Object System.Windows.Forms.Label
$fpsLabel.Text = 'FPS override (optional)'
$fpsLabel.AutoSize = $true
$fpsLabel.Location = New-Object System.Drawing.Point(280, 190)
$form.Controls.Add($fpsLabel)

$fpsBox = New-Object System.Windows.Forms.TextBox
$fpsBox.Location = New-Object System.Drawing.Point(280, 214)
$fpsBox.Size = New-Object System.Drawing.Size(125, 28)
$form.Controls.Add($fpsBox)

$optionsGroup = New-Object System.Windows.Forms.GroupBox
$optionsGroup.Text = 'MLV processing (ignored for lossless Fast Pass clips)'
$optionsGroup.Location = New-Object System.Drawing.Point(22, 260)
$optionsGroup.Size = New-Object System.Drawing.Size(578, 155)
$form.Controls.Add($optionsGroup)

$resolveNaming = New-Object System.Windows.Forms.CheckBox
$resolveNaming.Text = 'Simple Resolve naming'
$resolveNaming.Checked = $true
$resolveNaming.Location = New-Object System.Drawing.Point(18, 30)
$resolveNaming.AutoSize = $true
$optionsGroup.Controls.Add($resolveNaming)

$badPixels = New-Object System.Windows.Forms.CheckBox
$badPixels.Text = 'Bad pixel correction'
$badPixels.Location = New-Object System.Drawing.Point(18, 62)
$badPixels.AutoSize = $true
$optionsGroup.Controls.Add($badPixels)

$stripes = New-Object System.Windows.Forms.CheckBox
$stripes.Text = 'Vertical stripe correction'
$stripes.Location = New-Object System.Drawing.Point(18, 94)
$stripes.AutoSize = $true
$optionsGroup.Controls.Add($stripes)

$cs2x2 = New-Object System.Windows.Forms.CheckBox
$cs2x2.Text = '2x2 chroma smoothing'
$cs2x2.Location = New-Object System.Drawing.Point(290, 30)
$cs2x2.AutoSize = $true
$optionsGroup.Controls.Add($cs2x2)

$dualPreview = New-Object System.Windows.Forms.CheckBox
$dualPreview.Text = 'Dual ISO preview'
$dualPreview.Location = New-Object System.Drawing.Point(290, 62)
$dualPreview.AutoSize = $true
$optionsGroup.Controls.Add($dualPreview)

$dualFull = New-Object System.Windows.Forms.CheckBox
$dualFull.Text = 'Dual ISO full processing'
$dualFull.Location = New-Object System.Drawing.Point(290, 94)
$dualFull.AutoSize = $true
$optionsGroup.Controls.Add($dualFull)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.AutoSize = $true
$statusLabel.Location = New-Object System.Drawing.Point(22, 438)
$form.Controls.Add($statusLabel)

$mountButton = New-Object System.Windows.Forms.Button
$mountButton.Text = 'Mount for Resolve'
$mountButton.Location = New-Object System.Drawing.Point(22, 475)
$mountButton.Size = New-Object System.Drawing.Size(170, 42)
$form.Controls.Add($mountButton)

$unmountButton = New-Object System.Windows.Forms.Button
$unmountButton.Text = 'Unmount'
$unmountButton.Location = New-Object System.Drawing.Point(205, 475)
$unmountButton.Size = New-Object System.Drawing.Size(120, 42)
$form.Controls.Add($unmountButton)

$openButton = New-Object System.Windows.Forms.Button
$openButton.Text = 'Open Drive'
$openButton.Location = New-Object System.Drawing.Point(338, 475)
$openButton.Size = New-Object System.Drawing.Size(120, 42)
$openButton.Enabled = $false
$form.Controls.Add($openButton)

$closeButton = New-Object System.Windows.Forms.Button
$closeButton.Text = 'Close'
$closeButton.Location = New-Object System.Drawing.Point(471, 475)
$closeButton.Size = New-Object System.Drawing.Size(129, 42)
$form.Controls.Add($closeButton)

$folderDialog = New-Object System.Windows.Forms.FolderBrowserDialog
$folderDialog.Description = 'Choose the folder containing your Magic Lantern MLV clips'

$browseButton.Add_Click({
    if ($folderDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $sourceBox.Text = $folderDialog.SelectedPath
    }
})

function Test-SelectedDriveMounted {
    if (-not $driveCombo.SelectedItem) { return $false }
    $driveRoot = ([string]$driveCombo.SelectedItem) + '\'
    try { return (Test-Path -LiteralPath $driveRoot) } catch { return $false }
}

function Refresh-Status {
    $backendReady = (Test-Path $BackendExe) -and (Test-Path $CygpathExe)
    if ($backendReady) {
        $backendStatus.Text = 'Backend: Ready'
        $backendStatus.ForeColor = [System.Drawing.Color]::DarkGreen
    } else {
        $backendStatus.Text = 'Backend: Not installed / incomplete'
        $backendStatus.ForeColor = [System.Drawing.Color]::DarkRed
    }

    $proc = Get-MountedProcess
    $driveReady = Test-SelectedDriveMounted
    if ($proc -and $driveReady) {
        $statusLabel.Text = "Status: Mounted (PID $($proc.Id))"
        $mountButton.Enabled = $false
        $unmountButton.Enabled = $true
        $openButton.Enabled = $true
    } elseif ($proc -and -not $driveReady) {
        $statusLabel.Text = 'Status: Backend is running, but the virtual drive is not available'
        $mountButton.Enabled = $false
        $unmountButton.Enabled = $true
        $openButton.Enabled = $false
    } else {
        if (Test-Path $PidFile) { Remove-Item $PidFile -Force -ErrorAction SilentlyContinue }
        $statusLabel.Text = if ($backendReady) { 'Status: Ready to mount' } else { 'Status: Install / repair the backend first' }
        $mountButton.Enabled = $backendReady
        $unmountButton.Enabled = $false
        $openButton.Enabled = $false
    }
}

$repairButton.Add_Click({
    try {
        if (-not (Test-Path $RepairInstaller)) { throw "Backend installer was not found at $RepairInstaller" }

        $repairButton.Enabled = $false
        $backendStatus.Text = 'Backend: Installing / repairing...'
        $backendStatus.ForeColor = [System.Drawing.Color]::DarkOrange
        $form.Refresh()

        $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $installerArgs = '-NoProfile -ExecutionPolicy Bypass -File "{0}" -BackendOnly' -f $RepairInstaller
        $repairProc = Start-Process -FilePath $powershell -Verb RunAs -ArgumentList $installerArgs -Wait -PassThru

        if ($repairProc.ExitCode -ne 0) {
            throw ('Backend installer exited with code {0}. Check C:\ProgramData\MLVResolveFS\logs for the latest log.' -f $repairProc.ExitCode)
        }

        Refresh-Status
        if ((Test-Path $BackendExe) -and (Test-Path $CygpathExe)) {
            [System.Windows.Forms.MessageBox]::Show('Backend installation completed successfully. MLV Resolve FS is ready to mount footage.', 'MLV Resolve FS', 'OK', 'Information') | Out-Null
        } else {
            throw 'The installer finished, but the backend is still incomplete. Check the latest install log.'
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'MLV Resolve FS', 'OK', 'Error') | Out-Null
    } finally {
        $repairButton.Enabled = $true
        Refresh-Status
    }
})

$mountButton.Add_Click({
    try {
        if (-not (Test-Path $BackendExe)) { throw 'MLVFS backend is missing. Click Install / Repair Backend.' }
        if (-not $sourceBox.Text -or -not (Test-Path $sourceBox.Text)) { throw 'Choose a valid folder containing MLV footage.' }
        if (-not $driveCombo.SelectedItem) { throw 'No free virtual drive letter is available.' }
        if (Get-MountedProcess) { throw 'MLV Resolve FS is already mounted.' }

        $mountPoint = [string]$driveCombo.SelectedItem
        $driveRoot = $mountPoint + '\'
        if (Test-Path -LiteralPath $driveRoot) { throw ("The selected drive {0} is already in use. Choose another drive letter." -f $mountPoint) }
        $sourceUnix = Convert-ToCygwinPath $sourceBox.Text

        $args = New-Object System.Collections.Generic.List[string]
        $args.Add($mountPoint)
        $args.Add("--mlv_dir=$sourceUnix")
        $args.Add('-f')
        $args.Add('-o')
        $args.Add('uid=-1,gid=-1')
        if ($resolveNaming.Checked) { $args.Add('--resolve-naming') }
        if ($badPixels.Checked) { $args.Add('--bad-pix') }
        if ($stripes.Checked) { $args.Add('--stripes') }
        if ($cs2x2.Checked) { $args.Add('--cs2x2') }
        if ($dualPreview.Checked) { $args.Add('--dual-iso-preview') }
        if ($dualFull.Checked) { $args.Add('--dual-iso') }
        if ([int]$prefetch.Value -gt 0) { $args.Add(('--prefetch={0}' -f [int]$prefetch.Value)) }
        if (-not [string]::IsNullOrWhiteSpace($fpsBox.Text)) {
            $fps = 0.0
            if (-not [double]::TryParse($fpsBox.Text, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$fps)) {
                throw 'FPS override must be a number such as 23.976, 25 or 50.'
            }
            $args.Add(('--fps={0}' -f $fps.ToString([Globalization.CultureInfo]::InvariantCulture)))
        }

        Remove-Item $MountLogOut, $MountLogErr -Force -ErrorAction SilentlyContinue
        $quotedArgs = (($args | ForEach-Object { Quote-ProcessArgument $_ }) -join ' ')
        $oldPath = $env:PATH
        try {
            $env:PATH = ((Join-Path $CygwinRoot 'bin') + ';' + $oldPath)
            $proc = Start-Process -FilePath $BackendExe -ArgumentList $quotedArgs -PassThru -NoNewWindow `
                -RedirectStandardOutput $MountLogOut -RedirectStandardError $MountLogErr
        } finally {
            $env:PATH = $oldPath
        }
        if (-not $proc) { throw 'Could not start the MLVFS backend.' }

        $mounted = $false
        for ($i = 0; $i -lt 30; $i++) {
            Start-Sleep -Milliseconds 200
            if ($proc.HasExited) { break }
            if (Test-Path -LiteralPath $driveRoot) { $mounted = $true; break }
        }

        if (-not $mounted) {
            $exitText = if ($proc.HasExited) { "MLVFS exited with code $($proc.ExitCode)." } else { 'MLVFS stayed running, but WinFsp did not create the selected drive.' }
            if (-not $proc.HasExited) { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
            $detail = ''
            if (Test-Path $MountLogErr) {
                $tail = @(Get-Content $MountLogErr -Tail 12 -ErrorAction SilentlyContinue)
                if ($tail.Count -gt 0) { $detail = "`n`nBackend output:`n" + ($tail -join "`n") }
            }
            throw ($exitText + "`n`nMount log: $MountLogErr" + $detail)
        }

        $proc.Id | Set-Content -Encoding ASCII $PidFile
        $config = [pscustomobject]@{
            source = $sourceBox.Text; drive = $mountPoint; prefetch = [int]$prefetch.Value
            resolveNaming = $resolveNaming.Checked; badPixels = $badPixels.Checked
            stripes = $stripes.Checked; cs2x2 = $cs2x2.Checked
            dualPreview = $dualPreview.Checked; dualFull = $dualFull.Checked; fps = $fpsBox.Text
        }
        $config | ConvertTo-Json | Set-Content -Encoding UTF8 $ConfigFile
        Refresh-Status
        [System.Windows.Forms.MessageBox]::Show("Mounted successfully on $mountPoint. Open Resolve and import the simply named clip from the virtual drive.", 'MLV Resolve FS', 'OK', 'Information') | Out-Null
    } catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'MLV Resolve FS', 'OK', 'Error') | Out-Null
        Refresh-Status
    }
})

$unmountButton.Add_Click({
    try {
        $proc = Get-MountedProcess
        if ($proc) { Stop-Process -Id $proc.Id -Force; Start-Sleep -Milliseconds 700 }
        Remove-Item $PidFile -Force -ErrorAction SilentlyContinue
        Refresh-Status
    } catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'MLV Resolve FS', 'OK', 'Error') | Out-Null
    }
})

$openButton.Add_Click({
    try {
        if (-not $driveCombo.SelectedItem) { return }
        $driveRoot = ([string]$driveCombo.SelectedItem) + '\'
        if (-not (Test-Path -LiteralPath $driveRoot)) {
            throw 'The virtual drive is not mounted yet. Click Mount for Resolve first.'
        }
        Start-Process explorer.exe $driveRoot
    } catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'MLV Resolve FS', 'OK', 'Warning') | Out-Null
        Refresh-Status
    }
})

$closeButton.Add_Click({ $form.Close() })

if (Test-Path $ConfigFile) {
    try {
        $cfg = Get-Content $ConfigFile -Raw | ConvertFrom-Json
        if ($cfg.source -and (Test-Path $cfg.source)) { $sourceBox.Text = $cfg.source }
        $targetDrive = [string]$cfg.drive
        if ($targetDrive -and $driveCombo.Items.Contains($targetDrive)) { $driveCombo.SelectedItem = $targetDrive }
        if ($null -ne $cfg.prefetch) { $prefetch.Value = [decimal]$cfg.prefetch }
        if ($null -ne $cfg.resolveNaming) { $resolveNaming.Checked = [bool]$cfg.resolveNaming }
        if ($null -ne $cfg.badPixels) { $badPixels.Checked = [bool]$cfg.badPixels }
        if ($null -ne $cfg.stripes) { $stripes.Checked = [bool]$cfg.stripes }
        if ($null -ne $cfg.cs2x2) { $cs2x2.Checked = [bool]$cfg.cs2x2 }
        if ($null -ne $cfg.dualPreview) { $dualPreview.Checked = [bool]$cfg.dualPreview }
        if ($null -ne $cfg.dualFull) { $dualFull.Checked = [bool]$cfg.dualFull }
        if ($null -ne $cfg.fps) { $fpsBox.Text = [string]$cfg.fps }
    } catch {}
}

Refresh-Status
[void]$form.ShowDialog()
