MLV RESOLVE FS v2.8 - STREAMLINED SIMPLE NAMING
================================================

v2.8 keeps the working WinFsp/FUSE + MLVFS Fast Pass backend and the simple
Resolve-friendly naming that proved to import correctly without helper scripts.

EXAMPLE
-------
A source recording:

    M22-1423.MLV

is exposed on the virtual drive as:

    R:\M22-1423\
        M22-1423_000000.dng
        M22-1423_000001.dng
        M22-1423_000002.dng
        ...
        M22-1423.wav

WHAT CHANGED IN v2.8
--------------------
- Removed all DaVinci Resolve Lua/Python helper scripts.
- Removed automatic Resolve import/sync controls from the launcher.
- Removed external-scripting checks and script self-healing.
- The installer removes helper scripts left by older MLV Resolve FS versions.
- Kept the simple naming scheme that allows Resolve to recognise the sequence
  naturally.

WHAT v2.8 KEEPS
---------------
- Working lossless LJ92 Fast Pass virtual DNG path.
- Per-frame virtual DNG file sizes.
- Clean Resolve naming mode without preview/log/MLD clutter.
- Black trailing-item/frame cleanup.
- Virtual WAV alongside the DNG sequence.
- Simple shared basename between folder, DNG sequence and WAV.

QUICK UPDATE FROM v2.7
----------------------
If your v2.7 backend is already working perfectly, run:

    UPDATE-TO-V2.8-NO-BACKEND-REBUILD.cmd

This removes the old Resolve helper scripts and updates only the launcher/installer
files. It leaves the working MLVFS backend untouched.

FULL INSTALL / UPDATE
---------------------
1. Unmount R: and close DaVinci Resolve and MLV Resolve FS.
2. Run INSTALL-MLV-RESOLVE-FS.cmd normally.
3. Approve UAC when requested.
4. When installation completes, close the Administrator installer.
5. Start MLV Resolve FS normally from Desktop/Start Menu. Do NOT run it as
   Administrator.
6. Leave "Simple Resolve naming" ticked.
7. Mount the MLV source folder and import the clip from the virtual drive.

LOGS
----
Mount logs:
    %LOCALAPPDATA%\MLVResolveFS\mount-stderr.log
    %LOCALAPPDATA%\MLVResolveFS\mount-stdout.log

Installer logs:
    C:\ProgramData\MLVResolveFS\logs\
