$ErrorActionPreference = 'Stop'

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $PSCommandPath + '"'))
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argList
    exit
}

$InstallDir = Join-Path $env:ProgramFiles 'MLV Resolve FS'
$DataDir = Join-Path $env:ProgramData 'MLVResolveFS'
$StateDir = Join-Path $env:LOCALAPPDATA 'MLVResolveFS'
$CygwinRoot = 'C:\cygwin64'
$BackendDir = Join-Path $CygwinRoot 'opt\mlvresolvefs'

try {
    $pidFile = Join-Path $StateDir 'mlvfs.pid'
    if (Test-Path $pidFile) {
        $processId = [int](Get-Content $pidFile | Select-Object -First 1)
        Stop-Process -Id $processId -Force -ErrorAction SilentlyContinue
        Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
    }

    Remove-Item (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\MLV Resolve FS.lnk') -Force -ErrorAction SilentlyContinue
    $commonDesktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
    Remove-Item (Join-Path $commonDesktop 'MLV Resolve FS.lnk') -Force -ErrorAction SilentlyContinue

    foreach ($scriptName in @('MLV Resolve FS - Import and Sync Mounted Clips.lua','MLV Resolve FS - Sync Audio.py','MLV Resolve FS - Import and Sync Mounted Clips.py')) {
        Remove-Item (Join-Path $env:ProgramData ('Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Utility\' + $scriptName)) -Force -ErrorAction SilentlyContinue
        Remove-Item (Join-Path $env:APPDATA ('Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts\Utility\' + $scriptName)) -Force -ErrorAction SilentlyContinue
    }

    Remove-Item $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item $BackendDir -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item $DataDir -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item $StateDir -Recurse -Force -ErrorAction SilentlyContinue

    Write-Host 'MLV Resolve FS has been removed.' -ForegroundColor Green
    Write-Host 'WinFsp and Cygwin were left installed because other programs may use them.' -ForegroundColor Yellow
} catch {
    Write-Host ('Uninstall error: ' + $_.Exception.Message) -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}
