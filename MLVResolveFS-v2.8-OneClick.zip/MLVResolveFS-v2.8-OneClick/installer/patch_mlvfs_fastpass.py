#!/usr/bin/env python3
from pathlib import Path
import re
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: patch_mlvfs_fastpass.py <MLVFS source root>')

root = Path(sys.argv[1])
main_path = root / 'mlvfs' / 'main.c'
dng_path = root / 'mlvfs' / 'dng.c'
mlv_path = root / 'mlvfs' / 'mlv.h'
index_path = root / 'mlvfs' / 'index.c'
wav_path = root / 'mlvfs' / 'wav.c'

for p in (main_path, dng_path, mlv_path, index_path, wav_path):
    if not p.exists():
        raise SystemExit(f'ERROR: expected source file not found: {p}')

main = main_path.read_text(encoding='utf-8')
dng = dng_path.read_text(encoding='utf-8')
mlv = mlv_path.read_text(encoding='utf-8')
index = index_path.read_text(encoding='utf-8')
wav = wav_path.read_text(encoding='utf-8')


def replace_c_function(source: str, signature_token: str, replacement: str) -> str:
    """Replace a whole C function by locating its signature token and matching braces."""
    start = source.find(signature_token)
    if start < 0:
        raise SystemExit(f'ERROR: could not find C function signature: {signature_token}')
    brace = source.find('{', start)
    if brace < 0:
        raise SystemExit(f'ERROR: could not find opening brace for: {signature_token}')
    depth = 0
    i = brace
    in_string = False
    in_char = False
    escape = False
    while i < len(source):
        c = source[i]
        if escape:
            escape = False
        elif c == '\\' and (in_string or in_char):
            escape = True
        elif c == '"' and not in_char:
            in_string = not in_string
        elif c == "'" and not in_string:
            in_char = not in_char
        elif not in_string and not in_char:
            if c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    return source[:start] + replacement.rstrip() + '\n' + source[i+1:]
        i += 1
    raise SystemExit(f'ERROR: unterminated C function while replacing: {signature_token}')

# The installer patches current Magic Lantern's LJ92 flag before invoking us.
if not re.search(r'^#define\s+MLV_VIDEO_CLASS_FLAG_LJ92\s+0x20\s*$', mlv, re.M):
    raise SystemExit('ERROR: modern MLV_VIDEO_CLASS_FLAG_LJ92 0x20 patch is not present')

FASTPASS_MARKER = 'MLV Resolve FS Fast Pass: copy the original LJ92 payload directly'

# 1) Return the compressed payload directly for modern lossless LJ92 MLV frames.
if FASTPASS_MARKER not in main:
    anchor = re.compile(
        r'(?P<indent>\s*)uint64_t packed_size = \(pixel_count \+ 2\) \* bpp / 16;\s*\n'
        r'(?P=indent)if\(lzma_compressed \|\| lj92_compressed\)',
        re.M,
    )
    m = anchor.search(main)
    if not m:
        raise SystemExit('ERROR: could not find get_image_data packed_size/LZMA-LJ92 anchor in main.c')
    indent = m.group('indent')
    block = f'''{indent}uint64_t packed_size = (pixel_count + 2) * bpp / 16;\n\n{indent}/*\n{indent} * {FASTPASS_MARKER}.\n{indent} * Current Magic Lantern lossless VIDF payloads already contain a complete\n{indent} * JPEG Lossless (LJ92) stream beginning with FF D8. Wrapping those bytes\n{indent} * directly in a DNG avoids the obsolete MLVFS LJ92 decode/untile path and\n{indent} * preserves the exact camera RAW stream for DaVinci Resolve to decode.\n{indent} */\n{indent}if(lj92_compressed)\n{indent}{{\n{indent}    uint64_t frame_data_start = frame_headers->position + frame_headers->vidf_hdr.frameSpace + sizeof(mlv_vidf_hdr_t);\n{indent}    size_t frame_size = frame_headers->vidf_hdr.blockSize - (frame_headers->vidf_hdr.frameSpace + sizeof(mlv_vidf_hdr_t));\n{indent}    uint8_t soi[2] = {{0, 0}};\n\n{indent}    if(frame_size < 2)\n{indent}    {{\n{indent}        err_printf("LJ92 Fast Pass: frame payload is too small\\n");\n{indent}        return 0;\n{indent}    }}\n\n{indent}    file_set_pos(file, frame_data_start, SEEK_SET);\n{indent}    if(fread(soi, 1, 2, file) != 2 || soi[0] != 0xFF || soi[1] != 0xD8)\n{indent}    {{\n{indent}        err_printf("LJ92 Fast Pass: expected FF D8 at payload start, got %02X %02X\\n", soi[0], soi[1]);\n{indent}        return 0;\n{indent}    }}\n\n{indent}    uint64_t read_offset = offset > 0 ? (uint64_t)offset : 0;\n{indent}    if(read_offset >= frame_size) return 0;\n{indent}    size_t read_size = MIN(max_size, frame_size - (size_t)read_offset);\n{indent}    file_set_pos(file, frame_data_start + read_offset, SEEK_SET);\n{indent}    size_t got = fread(output_buffer, 1, read_size, file);\n{indent}    if(ferror(file))\n{indent}    {{\n{indent}        int err = errno;\n{indent}        err_printf("LJ92 Fast Pass fread error: %s\\n", strerror(err));\n{indent}        return 0;\n{indent}    }}\n{indent}    return got;\n{indent}}}\n\n{indent}if(lzma_compressed || lj92_compressed)'''
    main = main[:m.start()] + block + main[m.end():]
    print('Patched main.c: direct LJ92 Fast Pass read path added.')
else:
    print('main.c: direct LJ92 Fast Pass read path already present.')

# 2) process_frame must never run pixel-domain corrections over compressed LJ92 bytes.
process_anchor = 'get_image_data(&frame_headers, chunk_files[frame_headers.fileNumber], (uint8_t*) image_buffer->data, 0, image_buffer->size);'
if 'int fastpass_lj92 = frame_headers.file_hdr.videoClass & MLV_VIDEO_CLASS_FLAG_LJ92;' not in main:
    if process_anchor not in main:
        raise SystemExit('ERROR: could not find process_frame get_image_data call in main.c')
    main = main.replace(
        process_anchor,
        'int fastpass_lj92 = frame_headers.file_hdr.videoClass & MLV_VIDEO_CLASS_FLAG_LJ92;\n            ' + process_anchor,
        1,
    )
    print('Patched main.c: process_frame Fast Pass guard added.')

replacements = [
    ('if(mlvfs.deflicker) deflicker', 'if(!fastpass_lj92 && mlvfs.deflicker) deflicker'),
    ('if(mlvfs.fix_pattern_noise)', 'if(!fastpass_lj92 && mlvfs.fix_pattern_noise)'),
    ('if(mlvfs.dual_iso == 1)', 'if(!fastpass_lj92 && mlvfs.dual_iso == 1)'),
    ('else if(mlvfs.dual_iso == 2)', 'else if(!fastpass_lj92 && mlvfs.dual_iso == 2)'),
    ('if(mlvfs.chroma_smooth && mlvfs.dual_iso != 2)', 'if(!fastpass_lj92 && mlvfs.chroma_smooth && mlvfs.dual_iso != 2)'),
    ('if(mlvfs.fix_stripes)', 'if(!fastpass_lj92 && mlvfs.fix_stripes)'),
]
for old, new in replacements:
    if new in main:
        continue
    if old not in main:
        raise SystemExit(f'ERROR: could not find process_frame guard target: {old}')
    main = main.replace(old, new, 1)

focus_old = '''            else\n            {\n                fix_focus_pixels(&frame_headers, image_buffer->data, 0);'''
focus_new = '''            else if(!fastpass_lj92)\n            {\n                fix_focus_pixels(&frame_headers, image_buffer->data, 0);'''
if focus_new not in main:
    if focus_old not in main:
        raise SystemExit('ERROR: could not find process_frame focus-pixel else block')
    main = main.replace(focus_old, focus_new, 1)
print('Patched main.c: pixel corrections are bypassed for compressed Fast Pass frames.')

# 3) A Fast Pass DNG must declare the original bit depth and JPEG/LJ92 compression.
bits_old = '{tcBitsPerSample,               ttShort,    1,      16},'
bits_new = '{tcBitsPerSample,               ttShort,    1,      (frame_headers->file_hdr.videoClass & MLV_VIDEO_CLASS_FLAG_LJ92) ? frame_headers->rawi_hdr.raw_info.bits_per_pixel : 16},'
comp_old = '{tcCompression,                 ttShort,    1,      ccUncompressed},'
comp_new = '{tcCompression,                 ttShort,    1,      (frame_headers->file_hdr.videoClass & MLV_VIDEO_CLASS_FLAG_LJ92) ? ccJPEG : ccUncompressed},'
for old, new, label in ((bits_old, bits_new, 'BitsPerSample'), (comp_old, comp_new, 'Compression')):
    if new not in dng:
        if old not in dng:
            raise SystemExit(f'ERROR: could not find DNG {label} tag initializer')
        dng = dng.replace(old, new, 1)
        print(f'Patched dng.c: {label} is Fast Pass aware.')

# 4) File/strip byte count must be the actual compressed VIDF payload length.
size_marker = 'MLV Resolve FS Fast Pass size'
if size_marker not in dng:
    size_re = re.compile(
        r'size_t dng_get_image_size\(struct frame_headers \* frame_headers\)\s*\{\s*'
        r'return frame_headers->rawi_hdr\.xRes \* frame_headers->rawi_hdr\.yRes \* 2;\s*\}',
        re.S,
    )
    m = size_re.search(dng)
    if not m:
        raise SystemExit('ERROR: could not find dng_get_image_size implementation')
    replacement = '''size_t dng_get_image_size(struct frame_headers * frame_headers)\n{\n    /* MLV Resolve FS Fast Pass size: compressed LJ92 bytes are stored verbatim. */\n    if(frame_headers->file_hdr.videoClass & MLV_VIDEO_CLASS_FLAG_LJ92)\n    {\n        size_t overhead = frame_headers->vidf_hdr.frameSpace + sizeof(mlv_vidf_hdr_t);\n        if(frame_headers->vidf_hdr.blockSize > overhead)\n        {\n            return frame_headers->vidf_hdr.blockSize - overhead;\n        }\n        return 0;\n    }\n    return frame_headers->rawi_hdr.xRes * frame_headers->rawi_hdr.yRes * 2;\n}'''
    dng = dng[:m.start()] + replacement + dng[m.end():]
    print('Patched dng.c: DNG image/strip size uses compressed LJ92 payload size.')
else:
    print('dng.c: Fast Pass image size patch already present.')


# 5) Fast Pass produces variable-size DNG files. Upstream MLVFS caches one
# stat structure per MLV clip because its original uncompressed DNGs all had
# identical sizes. That is invalid for LJ92: each frame has a different
# compressed payload length. Key the attribute cache by the full virtual DNG
# path so Windows/Resolve see the exact EOF for every individual frame.
attr_marker = 'MLV Resolve FS per-frame DNG attribute cache'
if attr_marker not in main:
    old_lookup = 'if (string_ends_with(path_in_mlv, ".dng") && (dng_st = lookup_dng_attr(mlv_filename)) != NULL)'
    new_lookup = '/* MLV Resolve FS per-frame DNG attribute cache */\n            if (string_ends_with(path_in_mlv, ".dng") && (dng_st = lookup_dng_attr(path)) != NULL)'
    old_register = 'register_dng_attr(mlv_filename, stbuf);'
    new_register = 'register_dng_attr(path, stbuf);'
    if old_lookup not in main:
        raise SystemExit('ERROR: could not find upstream DNG attribute lookup in main.c')
    if old_register not in main:
        raise SystemExit('ERROR: could not find upstream DNG attribute registration in main.c')
    main = main.replace(old_lookup, new_lookup, 1)
    main = main.replace(old_register, new_register, 1)
    print('Patched main.c: DNG stat cache is now per virtual frame path.')
else:
    print('main.c: per-frame DNG attribute cache already present.')


# 6) Simple Resolve naming.
# Upstream --resolve-naming produces long BMD-style names. For Resolve/Explorer
# sequence detection we instead expose one compact, shared basename:
#   folder: M22-1423
#   frames: M22-1423_000000.dng ...
#   audio:  M22-1423.wav
# The reverse resolver tries both .MLV and .mlv so the virtual folder still
# maps back to the real source file.
SIMPLE_NAME_MARKER = 'MLV Resolve FS simple Resolve naming'
if SIMPLE_NAME_MARKER not in main:
    basename_replacement = r'''static int get_mlv_basename(const char *path, char ** mlv_basename)
{
    if(!(string_ends_with(path, ".MLV") || string_ends_with(path, ".mlv"))) return 0;
    char *temp = copy_string(path);
    const char *start = find_last_separator(temp) ? find_last_separator(temp) + 1 : temp;
    char *dot = strrchr(start, '.');
    if(dot == NULL) { free(temp); return 0; }
    *dot = '\0';

    /* MLV Resolve FS simple Resolve naming: one short basename is used for
     * the virtual folder, DNG sequence and matching WAV sidecar. */
    *mlv_basename = copy_string(start);
    free(temp);
    return *mlv_basename != NULL;
}'''
    main = replace_c_function(main, 'static int get_mlv_basename(const char *path, char ** mlv_basename)', basename_replacement)

    reverse_replacement = r'''static int get_mlv_name_from_basename(const char *path, char ** mlv_name)
{
    if(mlvfs.name_scheme == 1)
    {
        /* MLV Resolve FS simple Resolve naming. The virtual directory omits
         * the .MLV suffix, so resolve it back to whichever source case exists. */
        char *candidate = concat_string(path, ".MLV");
        if(candidate)
        {
            char *real_candidate = path_append(mlvfs.mlv_path, candidate);
            struct STAT64 st;
            if(real_candidate && STAT64(real_candidate, &st) == 0)
            {
                free(real_candidate);
                *mlv_name = candidate;
                return 1;
            }
            if(real_candidate) free(real_candidate);
            free(candidate);
        }

        candidate = concat_string(path, ".mlv");
        if(candidate)
        {
            char *real_candidate = path_append(mlvfs.mlv_path, candidate);
            struct STAT64 st;
            if(real_candidate && STAT64(real_candidate, &st) == 0)
            {
                free(real_candidate);
                *mlv_name = candidate;
                return 1;
            }
            if(real_candidate) free(real_candidate);
            free(candidate);
        }
        return 0;
    }

    *mlv_name = copy_string(path);
    return *mlv_name != NULL;
}'''
    main = replace_c_function(main, 'static int get_mlv_name_from_basename(const char *path, char ** mlv_name)', reverse_replacement)
    print('Patched main.c: Resolve naming now uses short shared clip/DNG/WAV basenames.')
else:
    print('main.c: simple Resolve naming patch already present.')

# 7) Resolve-clean virtual directory.
# In --resolve-naming mode, Resolve should see only the image sequence and its
# matching WAV. Upstream MLVFS also exposes _PREVIEW.gif, .log, and any real
# files from the .MLD sidecar directory. Those extra still/log items can be
# imported as separate clips and appear as a black/preview tail on the timeline.
CLEAN_MARKER = 'MLV Resolve FS clean Resolve directory'
if CLEAN_MARKER not in main:
    def wrap_two_listing_lines(source, first_stmt, marker_comment):
        pos = source.find(first_stmt)
        if pos < 0:
            raise SystemExit(f'ERROR: could not find Resolve-clean listing statement: {first_stmt}')
        line_start = source.rfind('\n', 0, pos) + 1
        indent = source[line_start:pos]
        first_end = source.find('\n', pos)
        if first_end < 0:
            raise SystemExit('ERROR: malformed listing statement in main.c')
        second_start = first_end + 1
        second_end = source.find('\n', second_start)
        if second_end < 0:
            second_end = len(source)
        second_line = source[second_start:second_end]
        if 'filler(buf, filename, NULL, 0);' not in second_line:
            raise SystemExit('ERROR: expected filler line after listing statement in main.c')
        wrapped = '\n'.join([
            indent + marker_comment,
            indent + 'if(!mlvfs.name_scheme)',
            indent + '{',
            indent + '    ' + first_stmt,
            indent + '    filler(buf, filename, NULL, 0);',
            indent + '}',
        ])
        return source[:line_start] + wrapped + source[second_end:]

    main = wrap_two_listing_lines(
        main,
        'sprintf(filename, "%s.log", mlv_basename);',
        '/* MLV Resolve FS clean Resolve directory */',
    )

    main = wrap_two_listing_lines(
        main,
        'sprintf(filename, "_PREVIEW.gif");',
        '/* Hide preview helper from Resolve naming mode. */',
    )

    # Upstream formatting around the MLD sidecar pass-through has changed over time.
    # Match stable statements rather than one large whitespace-sensitive literal block.
    mld_comment = '/* now pass over the MLD dir to the "real" directory listing code */'
    comment_pos = main.find(mld_comment)
    if comment_pos < 0:
        raise SystemExit('ERROR: could not find MLD pass-through comment in main.c')
    assign_pos = main.find('real_path = copy_string(mlv_filename);', comment_pos)
    if assign_pos < 0:
        raise SystemExit('ERROR: could not find MLD real_path assignment in main.c')
    strcpy_pos = main.find('strcpy(dot, ".MLD");', assign_pos)
    if strcpy_pos < 0:
        raise SystemExit('ERROR: could not find MLD strcpy in main.c')
    close_pos = main.find('}', strcpy_pos)
    if close_pos < 0:
        raise SystemExit('ERROR: could not find end of MLD pass-through block in main.c')
    close_pos += 1
    line_start = main.rfind('\n', 0, comment_pos) + 1
    indent = main[line_start:comment_pos]
    parts = [
        indent + mld_comment,
        indent + '/* In Resolve naming mode keep the virtual clip directory clean:',
        indent + ' * DNG sequence + WAV only. Do not leak XMP/preview/log/MLD files into Resolve. */',
        indent + 'if(!mlvfs.name_scheme)',
        indent + '{',
        indent + '    real_path = copy_string(mlv_filename);',
        indent + "    char *dot = strrchr(real_path, '.');",
        indent + '    if (dot)',
        indent + '    {',
        indent + '        strcpy(dot, ".MLD");',
        indent + '    }',
        indent + '}',
    ]
    new_real = '\n'.join(parts)
    main = main[:line_start] + new_real + main[close_pos:]
    print('Patched main.c: Resolve naming mode now exposes only DNG sequence + WAV.')
else:
    print('main.c: clean Resolve directory patch already present.')

# 8) Timestamp-accurate virtual WAV.
# Upstream MLVFS concatenates AUDF payloads and ignores each packet timestamp.
# v2.3 places every AUDF packet on the video time axis using its hardware timestamp.
AUDIO_MARKER = 'MLV Resolve FS timestamp-accurate virtual WAV'
if AUDIO_MARKER not in wav:
    timing_code = r'''/* MLV Resolve FS timestamp-accurate virtual WAV */
struct mlvresolve_av_timing
{
    uint64_t first_video_ts;
    uint64_t last_video_ts;
    uint32_t video_frames;
    int have_video;
};

static uint64_t mlvresolve_align_down(uint64_t value, uint16_t block_align)
{
    uint64_t a = block_align ? block_align : 1;
    return value - (value % a);
}

static uint64_t mlvresolve_align_up(uint64_t value, uint16_t block_align)
{
    uint64_t a = block_align ? block_align : 1;
    if(value % a) value += a - (value % a);
    return value;
}

static void mlvresolve_scan_video_timing(FILE **chunk_files, mlv_xref_hdr_t *block_xref,
                                         struct mlvresolve_av_timing *timing)
{
    memset(timing, 0, sizeof(*timing));
    if(!chunk_files || !block_xref) return;
    mlv_xref_t *xrefs = (mlv_xref_t *)&(((uint8_t*)block_xref)[sizeof(mlv_xref_hdr_t)]);
    for(uint32_t pos = 0; pos < block_xref->entryCount; pos++)
    {
        if(xrefs[pos].frameType != MLV_FRAME_VIDF) continue;
        FILE *in_file = chunk_files[xrefs[pos].fileNumber];
        mlv_hdr_t hdr;
        file_set_pos(in_file, xrefs[pos].frameOffset, SEEK_SET);
        if(fread(&hdr, sizeof(hdr), 1, in_file) != 1)
        {
            clearerr(in_file);
            continue;
        }
        if(memcmp(hdr.blockType, "VIDF", 4)) continue;
        if(!timing->have_video)
        {
            timing->first_video_ts = hdr.timestamp;
            timing->last_video_ts = hdr.timestamp;
            timing->have_video = 1;
        }
        else
        {
            if(hdr.timestamp < timing->first_video_ts) timing->first_video_ts = hdr.timestamp;
            if(hdr.timestamp > timing->last_video_ts) timing->last_video_ts = hdr.timestamp;
        }
        timing->video_frames++;
    }
}

static uint16_t mlvresolve_wav_block_align(mlv_wavi_hdr_t *wavi_hdr)
{
    uint16_t a = wavi_hdr->blockAlign;
    if(!a)
    {
        uint16_t bytes_per_sample = (uint16_t)MAX(1, wavi_hdr->bitsPerSample / 8);
        a = (uint16_t)(MAX(1, wavi_hdr->channels) * bytes_per_sample);
    }
    return a ? a : 1;
}

static uint64_t mlvresolve_video_audio_bytes(mlv_file_hdr_t *file_hdr, mlv_wavi_hdr_t *wavi_hdr,
                                             uint32_t frame_count)
{
    if(!file_hdr->sourceFpsNom || !frame_count || !wavi_hdr->bytesPerSecond) return 0;
    uint16_t align = mlvresolve_wav_block_align(wavi_hdr);
    uint64_t numerator = (uint64_t)wavi_hdr->bytesPerSecond *
                         (uint64_t)file_hdr->sourceFpsDenom * (uint64_t)frame_count;
    uint64_t bytes = (numerator + (uint64_t)file_hdr->sourceFpsNom - 1ULL) /
                     (uint64_t)file_hdr->sourceFpsNom;
    bytes = mlvresolve_align_up(bytes, align);
    bytes += align;
    return bytes;
}

'''
    insert_at = wav.find('size_t wav_get_data(const char *path')
    if insert_at < 0:
        raise SystemExit('ERROR: could not find wav_get_data insertion point')
    wav = wav[:insert_at] + timing_code + wav[insert_at:]

    direct_sig = 'size_t wav_get_data_direct(FILE ** chunk_files'
    direct_replacement = r'''size_t wav_get_data_direct(FILE ** chunk_files, mlv_xref_hdr_t * block_xref, mlv_file_hdr_t * mlv_hdr, mlv_wavi_hdr_t * wavi_hdr, mlv_rtci_hdr_t * rtci_hdr, mlv_idnt_hdr_t * idnt_hdr, size_t file_size, uint8_t * output_buffer, off_t offset, size_t length)
{
    uint16_t block_align = mlvresolve_wav_block_align(wavi_hdr);
    struct mlvresolve_av_timing timing;
    mlvresolve_scan_video_timing(chunk_files, block_xref, &timing);

    struct wav_header header =
    {
        .RIFF = "RIFF",
        .file_size = (uint32_t)(file_size >= 8 ? file_size - 8 : 0),
        .WAVE = "WAVE",
        .bext_id = "bext",
        .bext_size = sizeof(struct wav_bext),
        .bext.time_reference = 0,
        .bext.version = 1,
        .iXML_id = "iXML",
        .iXML_size = 1024,
        .fmt = "fmt ",
        .subchunk1_size = 16,
        .audio_format = 1,
        .num_channels = wavi_hdr->channels,
        .sample_rate = wavi_hdr->samplingRate,
        .byte_rate = wavi_hdr->bytesPerSecond,
        .block_align = block_align,
        .bits_per_sample = wavi_hdr->bitsPerSample,
        .data = "data",
        .subchunk2_size = (uint32_t)(file_size > sizeof(struct wav_header) ? file_size - sizeof(struct wav_header) : 0),
    };

    char temp[33];
    snprintf(temp, sizeof(temp), "%s", idnt_hdr->cameraName);
    memcpy(header.bext.originator, temp, 32);
    snprintf(temp, sizeof(temp), "JPCAN%04d%.8s%02d%02d%02d%09d", idnt_hdr->cameraModel, idnt_hdr->cameraSerial, rtci_hdr->tm_hour, rtci_hdr->tm_min, rtci_hdr->tm_sec, rand());
    memcpy(header.bext.originator_reference, temp, 32);
    snprintf(temp, sizeof(temp), "%04d:%02d:%02d", 1900 + rtci_hdr->tm_year, rtci_hdr->tm_mon, rtci_hdr->tm_mday);
    memcpy(header.bext.origination_date, temp, 10);
    snprintf(temp, sizeof(temp), "%02d:%02d:%02d", rtci_hdr->tm_hour, rtci_hdr->tm_min, rtci_hdr->tm_sec);
    memcpy(header.bext.origination_time, temp, 8);

    char * project = "Magic Lantern";
    char * notes = "MLV Resolve FS - AUDF packets positioned from hardware timestamps";
    char * keywords = "MLV Resolve FS";
    int tape = 1, scene = 1, shot = 1, take = 1;
    int fps_denom = mlv_hdr->sourceFpsDenom;
    int fps_nom = mlv_hdr->sourceFpsNom;
    snprintf(header.iXML, header.iXML_size, iXML, project, notes, keywords, tape, scene, shot, take, fps_nom, fps_denom, fps_nom, fps_denom, fps_nom, fps_denom);

    int64_t out_pos = 0;
    int64_t req_off = offset;
    int64_t remaining = length;

    if(req_off < (int64_t)sizeof(struct wav_header))
    {
        int64_t n = MIN((int64_t)sizeof(struct wav_header) - req_off, remaining);
        uint8_t *hp = (uint8_t *)&header;
        memcpy(output_buffer + out_pos, hp + req_off, (size_t)n);
        out_pos += n;
        req_off += n;
        remaining -= n;
    }
    if(remaining <= 0) return length;

    int64_t data_req_start = req_off - (int64_t)sizeof(struct wav_header);
    int64_t data_req_end = data_req_start + remaining;
    memset(output_buffer + out_pos, 0, (size_t)remaining);

    if(!timing.have_video || !wavi_hdr->bytesPerSecond) return length;

    mlv_xref_t *xrefs = (mlv_xref_t *)&(((uint8_t*)block_xref)[sizeof(mlv_xref_hdr_t)]);
    mlv_audf_hdr_t audf_hdr;
    for(uint32_t i = 0; i < block_xref->entryCount; i++)
    {
        if(xrefs[i].frameType != MLV_FRAME_AUDF) continue;
        FILE *in_file = chunk_files[xrefs[i].fileNumber];
        int64_t position = xrefs[i].frameOffset;
        file_set_pos(in_file, position, SEEK_SET);
        if(fread(&audf_hdr, sizeof(audf_hdr), 1, in_file) != 1)
        {
            clearerr(in_file);
            continue;
        }
        if(memcmp(audf_hdr.blockType, "AUDF", 4)) continue;

        uint64_t overhead = (uint64_t)sizeof(mlv_audf_hdr_t) + (uint64_t)audf_hdr.frameSpace;
        if((uint64_t)audf_hdr.blockSize <= overhead) continue;
        uint64_t payload_size = (uint64_t)audf_hdr.blockSize - overhead;

        int64_t delta_us = (int64_t)audf_hdr.timestamp - (int64_t)timing.first_video_ts;
        int64_t packet_start;
        if(delta_us >= 0)
            packet_start = (int64_t)(((uint64_t)delta_us * (uint64_t)wavi_hdr->bytesPerSecond) / 1000000ULL);
        else
            packet_start = -(int64_t)(((uint64_t)(-delta_us) * (uint64_t)wavi_hdr->bytesPerSecond) / 1000000ULL);
        if(packet_start >= 0) packet_start = (int64_t)mlvresolve_align_down((uint64_t)packet_start, block_align);
        else packet_start = -(int64_t)mlvresolve_align_down((uint64_t)(-packet_start), block_align);

        int64_t packet_end = packet_start + (int64_t)payload_size;
        int64_t overlap_start = MAX(data_req_start, packet_start);
        int64_t overlap_end = MIN(data_req_end, packet_end);
        if(overlap_end <= overlap_start) continue;

        int64_t source_skip = overlap_start - packet_start;
        int64_t dest_skip = overlap_start - data_req_start;
        int64_t bytes = overlap_end - overlap_start;
        if(source_skip < 0 || dest_skip < 0 || bytes <= 0) continue;

        file_set_pos(in_file, position + (int64_t)overhead + source_skip, SEEK_SET);
        size_t got = fread(output_buffer + out_pos + dest_skip, 1, (size_t)bytes, in_file);
        if(got < (size_t)bytes) clearerr(in_file);
    }
    return length;
}'''
    wav = replace_c_function(wav, direct_sig, direct_replacement)

    size_sig = 'size_t wav_get_size(const char *path)'
    size_replacement = r'''size_t wav_get_size(const char *path)
{
    size_t result = 0;
    mlv_file_hdr_t file_hdr;
    mlv_wavi_hdr_t wavi_hdr;
    mlv_rtci_hdr_t rtci_hdr;
    mlv_idnt_hdr_t idnt_hdr;
    FILE *mlv_file = fopen(path, "rb");
    if(!mlv_file) return 0;

    if(fread(&file_hdr, sizeof(file_hdr), 1, mlv_file) &&
       !memcmp(file_hdr.fileMagic, "MLVI", 4) &&
       wav_get_headers(path, &file_hdr, &wavi_hdr, &rtci_hdr, &idnt_hdr))
    {
        uint32_t frame_count = (uint32_t)mlv_get_frame_count(path);
        uint64_t data_size = mlvresolve_video_audio_bytes(&file_hdr, &wavi_hdr, frame_count);
        if(data_size) result = sizeof(struct wav_header) + (size_t)data_size;
    }
    fclose(mlv_file);
    return result;
}'''
    wav = replace_c_function(wav, size_sig, size_replacement)
    print('Patched wav.c: AUDF packets are positioned by hardware timestamp and duration matches video.')
else:
    print('wav.c: timestamp-accurate virtual WAV patch already present.')

# Sanity checks before writing anything.
checks = [
    (FASTPASS_MARKER in main, 'direct Fast Pass marker'),
    ('!fastpass_lj92 && mlvfs.fix_stripes' in main, 'processing guard'),
    ('? ccJPEG : ccUncompressed' in dng, 'JPEG compression tag'),
    ('? frame_headers->rawi_hdr.raw_info.bits_per_pixel : 16' in dng, 'raw bit-depth tag'),
    (size_marker in dng, 'compressed payload size'),
    ('lookup_dng_attr(path)' in main and 'register_dng_attr(path, stbuf)' in main, 'per-frame DNG stat cache'),
    (SIMPLE_NAME_MARKER in main and 'concat_string(path, \".MLV\")' in main, 'simple Resolve naming'),
    (CLEAN_MARKER in main and 'Do not leak XMP/preview/log/MLD' in main, 'clean Resolve directory'),
    (AUDIO_MARKER in wav and 'audf_hdr.timestamp' in wav and 'packet_start' in wav, 'timestamp-accurate audio'),
]
failed = [label for ok, label in checks if not ok]
if failed:
    raise SystemExit('ERROR: v2.8 verification failed: ' + ', '.join(failed))

main_path.write_text(main, encoding='utf-8', newline='\n')
dng_path.write_text(dng, encoding='utf-8', newline='\n')
index_path.write_text(index, encoding='utf-8', newline='\n')
wav_path.write_text(wav, encoding='utf-8', newline='\n')
print('MLV Resolve FS v2.8 Streamlined Simple Naming + clean Fast Pass/audio source patch completed successfully.')
