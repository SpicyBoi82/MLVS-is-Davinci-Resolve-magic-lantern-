[CmdletBinding()]
param(
    [switch]$NoDesktopShortcut,
    [switch]$BackendOnly
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $PSCommandPath + '"'))
    if ($NoDesktopShortcut) { $argList += '-NoDesktopShortcut' }
    if ($BackendOnly) { $argList += '-BackendOnly' }
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argList
    exit
}

$PackageRoot = Split-Path -Parent $PSScriptRoot
$InstallDir = Join-Path $env:ProgramFiles 'MLV Resolve FS'
$InstallAppDir = Join-Path $InstallDir 'app'
$InstallInstallerDir = Join-Path $InstallDir 'installer'
$DataDir = Join-Path $env:ProgramData 'MLVResolveFS'
$CygwinRoot = 'C:\cygwin64'
$CygwinBin = Join-Path $CygwinRoot 'bin'
$BashExe = Join-Path $CygwinBin 'bash.exe'
$BackendExe = Join-Path $CygwinRoot 'opt\mlvresolvefs\bin\mlvfs.exe'
$LogDir = Join-Path $DataDir 'logs'
$LogFile = Join-Path $LogDir ('install-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')

New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = [ConsoleColor]::Gray)
    $line = ('[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $Message)
    Write-Host $line -ForegroundColor $Color
    Add-Content -Path $LogFile -Value $line
}

function Assert-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Installer must be run as Administrator.'
    }
}

function Copy-IfDifferent {
    param([Parameter(Mandatory=$true)][string]$Source, [Parameter(Mandatory=$true)][string]$Destination)
    $srcFull = [System.IO.Path]::GetFullPath($Source).TrimEnd('\')
    $dstFull = [System.IO.Path]::GetFullPath($Destination).TrimEnd('\')
    if ([string]::Equals($srcFull, $dstFull, [System.StringComparison]::OrdinalIgnoreCase)) {
        Write-Log ('Skipping self-copy: {0}' -f $dstFull) DarkGray
        return
    }
    if (-not (Test-Path $Source)) { throw ('Required installer file not found: {0}' -f $Source) }
    Copy-Item $Source $Destination -Force
}

function Install-LauncherFirst {
    Write-Log 'Installing the launcher and shortcuts first...' Cyan
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    New-Item -ItemType Directory -Force -Path $InstallAppDir | Out-Null
    New-Item -ItemType Directory -Force -Path $InstallInstallerDir | Out-Null

    Copy-IfDifferent (Join-Path $PackageRoot 'app\MLVResolveFS-Launcher.ps1') (Join-Path $InstallAppDir 'MLVResolveFS-Launcher.ps1')
    Copy-IfDifferent (Join-Path $PackageRoot 'installer\Install-MLVResolveFS.ps1') (Join-Path $InstallInstallerDir 'Install-MLVResolveFS.ps1')
    Copy-IfDifferent (Join-Path $PackageRoot 'installer\patch_mlvfs_fastpass.py') (Join-Path $InstallInstallerDir 'patch_mlvfs_fastpass.py')
    Copy-IfDifferent (Join-Path $PackageRoot 'installer\Uninstall-MLVResolveFS.ps1') (Join-Path $InstallInstallerDir 'Uninstall-MLVResolveFS.ps1')
    $readmeSource = Join-Path $PackageRoot 'README-FIRST.txt'
    if (Test-Path $readmeSource) { Copy-IfDifferent $readmeSource (Join-Path $InstallDir 'README.txt') }

    # v2.8 removes the optional Resolve helper scripts used by earlier versions.
    $legacyCommonResolveScripts = Join-Path $env:ProgramData 'Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Utility'
    foreach ($scriptName in @('MLV Resolve FS - Import and Sync Mounted Clips.lua','MLV Resolve FS - Import and Sync Mounted Clips.py','MLV Resolve FS - Sync Audio.py')) {
        Remove-Item (Join-Path $legacyCommonResolveScripts $scriptName) -Force -ErrorAction SilentlyContinue
    }
    Remove-Item (Join-Path $InstallDir 'resolve') -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $InstallDir 'UPDATE-SEAMLESS-IMPORT-ONLY.cmd') -Force -ErrorAction SilentlyContinue
    Write-Log 'Removed legacy Resolve helper-script components from earlier versions.' DarkGray

    @'
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0app\MLVResolveFS-Launcher.ps1"
'@ | Set-Content -Encoding ASCII (Join-Path $InstallDir 'MLV Resolve FS.cmd')

    @'
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\Install-MLVResolveFS.ps1" -BackendOnly
'@ | Set-Content -Encoding ASCII (Join-Path $InstallDir 'REPAIR-OR-UPDATE.cmd')

    @'
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\Uninstall-MLVResolveFS.ps1"
'@ | Set-Content -Encoding ASCII (Join-Path $InstallDir 'UNINSTALL.cmd')

    $launcher = Join-Path $InstallAppDir 'MLVResolveFS-Launcher.ps1'
    $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $shortcutArgs = '-NoProfile -ExecutionPolicy Bypass -STA -File "{0}"' -f $launcher
    $ws = New-Object -ComObject WScript.Shell

    $startMenuDir = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs'
    $startShortcut = $ws.CreateShortcut((Join-Path $startMenuDir 'MLV Resolve FS.lnk'))
    $startShortcut.TargetPath = $powershell
    $startShortcut.Arguments = $shortcutArgs
    $startShortcut.WorkingDirectory = $InstallDir
    $startShortcut.Description = 'Mount Magic Lantern MLV footage as virtual CinemaDNG for DaVinci Resolve'
    $startShortcut.Save()

    if (-not $NoDesktopShortcut) {
        $desktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
        $desktopShortcut = $ws.CreateShortcut((Join-Path $desktop 'MLV Resolve FS.lnk'))
        $desktopShortcut.TargetPath = $powershell
        $desktopShortcut.Arguments = $shortcutArgs
        $desktopShortcut.WorkingDirectory = $InstallDir
        $desktopShortcut.Description = 'Mount Magic Lantern MLV footage as virtual CinemaDNG for DaVinci Resolve'
        $desktopShortcut.Save()
    }

    Write-Log 'MLV Resolve FS launcher is now available from Desktop/Start Menu.' Green
}

function Test-WinFspInstalled {
    foreach ($path in @('HKLM:\SOFTWARE\WOW6432Node\WinFsp','HKLM:\SOFTWARE\WinFsp')) {
        if (Test-Path $path) { return $true }
    }
    return $false
}

function Install-WinFsp {
    if (Test-WinFspInstalled) { Write-Log 'WinFsp is already installed.' Green; return }
    Write-Log 'Installing WinFsp...' Cyan

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        $args = @('install','--id','WinFsp.WinFsp','-e','--source','winget','--accept-source-agreements','--accept-package-agreements','--silent')
        $p = Start-Process -FilePath $winget.Source -ArgumentList $args -Wait -PassThru -WindowStyle Hidden
        if ($p.ExitCode -eq 0 -and (Test-WinFspInstalled)) { Write-Log 'WinFsp installed via Windows Package Manager.' Green; return }
        Write-Log ('WinGet WinFsp install returned code {0}; trying official MSI.' -f $p.ExitCode) Yellow
    }

    $tmpMsi = Join-Path $env:TEMP 'winfsp-latest.msi'
    $release = Invoke-RestMethod -Uri 'https://api.github.com/repos/winfsp/winfsp/releases/latest' -Headers @{ 'User-Agent' = 'MLVResolveFS-Installer' }
    $asset = $release.assets | Where-Object { $_.name -match '^winfsp-.*\.msi$' } | Select-Object -First 1
    if (-not $asset) { throw 'Could not find a WinFsp MSI in the latest official release.' }
    Invoke-WebRequest -UseBasicParsing -Uri $asset.browser_download_url -OutFile $tmpMsi
    $msi = Start-Process -FilePath 'msiexec.exe' -ArgumentList @('/i', ('"{0}"' -f $tmpMsi), '/qn', '/norestart') -Wait -PassThru
    if ($msi.ExitCode -notin @(0,3010,1641)) { throw ('WinFsp MSI installation failed with exit code {0}.' -f $msi.ExitCode) }
    if (-not (Test-WinFspInstalled)) { throw 'WinFsp installation completed but WinFsp was not detected.' }
    Write-Log 'WinFsp installed.' Green
}

function Install-CygwinAndBuildTools {
    if ((Test-Path $BashExe) -and (Test-Path (Join-Path $CygwinBin 'gcc.exe')) -and (Test-Path (Join-Path $CygwinBin 'make.exe'))) {
        Write-Log 'Cygwin build environment already exists; ensuring packages are present.' Green
    }

    $setupExe = Join-Path $env:TEMP 'cygwin-setup-x86_64.exe'
    Write-Log 'Downloading the official Cygwin setup program...' Cyan
    Invoke-WebRequest -UseBasicParsing -Uri 'https://cygwin.com/setup-x86_64.exe' -OutFile $setupExe
    $packages = 'gcc-core,make,git,patch,cygfuse,pkg-config,diffutils,coreutils,findutils,sed,gawk,python3'
    $mirrors = @('https://mirrors.kernel.org/sourceware/cygwin/','https://mirrorservice.org/sites/sourceware.org/pub/cygwin/')
    $success = $false
    foreach ($mirror in $mirrors) {
        Write-Log ('Installing/updating Cygwin packages from {0}' -f $mirror) Cyan
        $args = @('-q','-R',$CygwinRoot,'-s',$mirror,'-P',$packages,'-d','-N')
        $p = Start-Process -FilePath $setupExe -ArgumentList $args -Wait -PassThru
        if ($p.ExitCode -eq 0 -and (Test-Path $BashExe)) { $success = $true; break }
        Write-Log ('Cygwin setup returned code {0} using this mirror.' -f $p.ExitCode) Yellow
    }
    if (-not $success) { throw 'Cygwin setup did not complete successfully.' }
    foreach ($tool in @('bash.exe','gcc.exe','make.exe','git.exe')) {
        $candidate = Join-Path $CygwinBin $tool
        if (-not (Test-Path $candidate)) { throw ('Required Cygwin tool is missing: {0}' -f $candidate) }
    }
    Write-Log 'Cygwin, compiler, Git, Make and cygfuse are installed.' Green
}

function Build-MLVFS {
    Write-Log 'Downloading/updating and building the actual MLVFS codebase...' Cyan
    $buildScriptWindows = Join-Path $CygwinRoot 'tmp\mlvresolvefs-build.sh'
    $buildStdout = Join-Path $env:TEMP 'mlvresolvefs-build-stdout.txt'
    $buildStderr = Join-Path $env:TEMP 'mlvresolvefs-build-stderr.txt'

    $patcherSource = Join-Path $PackageRoot 'installer\patch_mlvfs_fastpass.py'
    $patcherWindows = Join-Path $CygwinRoot 'tmp\mlvresolvefs-fastpass-patch.py'
    if (-not (Test-Path $patcherSource)) { throw ('Fast Pass patcher is missing: {0}' -f $patcherSource) }
    Copy-Item $patcherSource $patcherWindows -Force

    $buildScript = @'
set -euo pipefail
export PATH=/usr/local/bin:/usr/bin:/bin:$PATH
SRC=/usr/local/src/MLVFS
OUT=/opt/mlvresolvefs/bin
mkdir -p /usr/local/src "$OUT"

# Repair a previous interrupted clone automatically.
if [ -e "$SRC" ] && [ ! -d "$SRC/.git" ]; then
    echo "Removing incomplete previous MLVFS source tree: $SRC"
    rm -rf "$SRC"
fi

if [ -d "$SRC/.git" ]; then
    echo "Updating existing MLVFS source tree..."
    git -C "$SRC" fetch --prune origin
    git -C "$SRC" checkout -f master
    git -C "$SRC" reset --hard origin/master
    git -C "$SRC" clean -fdx
else
    echo "Cloning MLVFS..."
    git clone --depth 1 https://github.com/davidmilligan/MLVFS.git "$SRC"
fi

cd "$SRC"

# Modern Magic Lantern video-class assignments. Old MLVFS used 0x100 for LJ92.
echo "Patching MLVFS for current Magic Lantern compression flags..."
sed -i \
  -e 's/^#define MLV_VIDEO_CLASS_FLAG_LJ92[[:space:]]*0x100$/#define MLV_VIDEO_CLASS_FLAG_MCRAW   0x100\n#define MLV_VIDEO_CLASS_FLAG_LJ92    0x20\n#define MLV_VIDEO_CLASS_FLAG_JPEG2K  0x10/' \
  mlvfs/mlv.h

grep -E 'MLV_VIDEO_CLASS_FLAG_(MCRAW|LJ92|JPEG2K)' mlvfs/mlv.h

# v2.8: keep modern lossless MLV compressed and use simple shared clip naming. The source frame already
# contains a complete LJ92 bitstream. Put those exact bytes behind a DNG header.
echo "Applying MLV Resolve FS v2.8 streamlined Fast Pass + simple Resolve naming patch..."
python3 /tmp/mlvresolvefs-fastpass-patch.py "$SRC"

grep -n 'MLV Resolve FS Fast Pass' mlvfs/main.c mlvfs/dng.c || true
grep -n 'tcBitsPerSample\|tcCompression\|tcStripByteCounts' mlvfs/dng.c | head -20 || true

# Keep upstream ALLOW_WRITEABLE_DNGS compatibility behaviour. Some NLEs probe
# image sequences with a read/write open even though they never modify the media.
echo "Keeping MLVFS writable-open compatibility for NLE media probing."

# Treat Cygwin as the POSIX/FUSE path rather than the old native-Windows Pismo path.
while IFS= read -r -d '' f; do
    sed -i \
      -e 's/^#ifdef _WIN32$/#if defined(_WIN32) \&\& !defined(__CYGWIN__)/' \
      -e 's/^#ifndef _WIN32$/#if !defined(_WIN32) || defined(__CYGWIN__)/' \
      "$f"
done < <(find mlvfs -type f \( -name '*.c' -o -name '*.h' \) -print0)

echo "Cygwin FUSE diagnostics:"
pkg-config --modversion fuse || true
pkg-config --cflags --libs fuse || true
ls -l /usr/lib/libfuse.dll.a /usr/bin/cygfuse-2.8.dll 2>/dev/null || true

# WinFsp's Cygwin FUSE headers require CYGFUSE for correct import symbols.
sed -i -e 's|CFLAGS = -Wall -std=gnu99|CFLAGS = -Wall -I/usr/include/fuse -DCYGFUSE -std=gnu99|' mlvfs/Makefile

cd mlvfs
echo "Effective MLVFS CFLAGS/LIBS:"
grep -E '^(CFLAGS|LIBS)[[:space:]]*=' Makefile || true
make clean || true
make -j"$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 2)"
install -m 0755 mlvfs "$OUT/mlvfs.exe"
echo "Built v2.8 Streamlined Simple Naming backend: $OUT/mlvfs.exe"
'@

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($buildScriptWindows, ($buildScript -replace "`r`n", "`n"), $utf8NoBom)

    # IMPORTANT: Git writes normal progress messages (for example "Cloning into...")
    # to stderr. PowerShell 5 can turn redirected native stderr into ErrorRecords when
    # ErrorActionPreference is Stop. Run bash through Start-Process instead and judge
    # success strictly by the native process exit code.
    Remove-Item $buildStdout, $buildStderr -Force -ErrorAction SilentlyContinue
    $p = Start-Process -FilePath $BashExe `
        -ArgumentList @('--login','-c','/tmp/mlvresolvefs-build.sh') `
        -RedirectStandardOutput $buildStdout `
        -RedirectStandardError $buildStderr `
        -Wait -PassThru -NoNewWindow

    if (Test-Path $buildStdout) {
        Get-Content $buildStdout | ForEach-Object {
            Write-Host $_
            Add-Content -Path $LogFile -Value $_
        }
    }
    if (Test-Path $buildStderr) {
        Get-Content $buildStderr | ForEach-Object {
            # stderr is not automatically an error: gcc/git legitimately use it.
            Write-Host $_ -ForegroundColor DarkGray
            Add-Content -Path $LogFile -Value $_
        }
    }

    if ($p.ExitCode -ne 0) {
        throw ('MLVFS build failed with exit code {0}. See {1}' -f $p.ExitCode, $LogFile)
    }
    if (-not (Test-Path $BackendExe)) {
        throw ('Build reported success but backend executable is missing: {0}' -f $BackendExe)
    }
    Write-Log 'MLVFS v2.8 Streamlined Simple Naming backend built successfully.' Green
}

try {
    Assert-Admin
    Write-Log 'MLV Resolve FS v2.8 installer started.' Cyan
    Write-Log ('Installer log: {0}' -f $LogFile)
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'This installer currently supports 64-bit Windows only.' }

    # Full install/update copies application files only when launched from an extracted package.
    # Installed Repair uses -BackendOnly so it never attempts to copy files onto themselves.
    if (-not $BackendOnly) {
        Install-LauncherFirst
    } else {
        Write-Log 'Backend-only repair mode: leaving installed launcher/installer files untouched.' Cyan
    }
    Install-WinFsp
    Install-CygwinAndBuildTools
    Build-MLVFS

    Write-Log 'Installation complete. v2.8 Streamlined Simple Naming backend is ready.' Green
    Write-Host ''
    Write-Host 'MLV Resolve FS is installed and ready.' -ForegroundColor Green
    if (-not $BackendOnly) {
        Write-Host 'Installation finished. Close this installer, then open MLV Resolve FS from the Desktop or Start Menu.' -ForegroundColor Yellow
        Write-Host 'Do not run the launcher as Administrator; WinFsp drive letters must be created in your normal user session.' -ForegroundColor Yellow
    }
}
catch {
    Write-Log ('ERROR: {0}' -f $_.Exception.Message) Red
    Write-Host ''
    Write-Host 'The backend installation did not finish.' -ForegroundColor Red
    if (-not $BackendOnly) {
        Write-Host 'The MLV Resolve FS launcher/shortcut has still been installed.' -ForegroundColor Yellow
        Write-Host 'Open it and use "Install / Repair Backend" after sending me the error/log if needed.' -ForegroundColor Yellow
    } else {
        Write-Host 'The installed launcher has been left unchanged.' -ForegroundColor Yellow
    }
    Write-Host ('Log: {0}' -f $LogFile) -ForegroundColor Cyan
    Read-Host 'Press Enter to close'
    exit 1
}
