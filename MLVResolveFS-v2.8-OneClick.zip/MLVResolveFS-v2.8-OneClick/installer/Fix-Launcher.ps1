[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $args = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $PSCommandPath + '"'))
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $args
    exit
}

$PackageRoot = Split-Path -Parent $PSScriptRoot
$InstallDir = Join-Path $env:ProgramFiles 'MLV Resolve FS'
$InstallAppDir = Join-Path $InstallDir 'app'
$InstallInstallerDir = Join-Path $InstallDir 'installer'
$SourceLauncher = Join-Path $PackageRoot 'app\MLVResolveFS-Launcher.ps1'
$TargetLauncher = Join-Path $InstallAppDir 'MLVResolveFS-Launcher.ps1'

if (-not (Test-Path $SourceLauncher)) { throw "v2.8 launcher not found: $SourceLauncher" }

New-Item -ItemType Directory -Force -Path $InstallAppDir | Out-Null
New-Item -ItemType Directory -Force -Path $InstallInstallerDir | Out-Null
Copy-Item $SourceLauncher $TargetLauncher -Force
Copy-Item (Join-Path $PackageRoot 'installer\Install-MLVResolveFS.ps1') (Join-Path $InstallInstallerDir 'Install-MLVResolveFS.ps1') -Force
Copy-Item (Join-Path $PackageRoot 'installer\patch_mlvfs_fastpass.py') (Join-Path $InstallInstallerDir 'patch_mlvfs_fastpass.py') -Force
Copy-Item (Join-Path $PackageRoot 'installer\Uninstall-MLVResolveFS.ps1') (Join-Path $InstallInstallerDir 'Uninstall-MLVResolveFS.ps1') -Force
if (Test-Path (Join-Path $PackageRoot 'README-FIRST.txt')) {
    Copy-Item (Join-Path $PackageRoot 'README-FIRST.txt') (Join-Path $InstallDir 'README.txt') -Force
}

# Remove all legacy Resolve integration files from older versions.
$commonResolveScripts = Join-Path $env:ProgramData 'Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Utility'
foreach ($scriptName in @('MLV Resolve FS - Import and Sync Mounted Clips.lua','MLV Resolve FS - Import and Sync Mounted Clips.py','MLV Resolve FS - Sync Audio.py')) {
    Remove-Item (Join-Path $commonResolveScripts $scriptName) -Force -ErrorAction SilentlyContinue
}
Remove-Item (Join-Path $InstallDir 'resolve') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $InstallDir 'UPDATE-SEAMLESS-IMPORT-ONLY.cmd') -Force -ErrorAction SilentlyContinue

@'
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\Install-MLVResolveFS.ps1" -BackendOnly
'@ | Set-Content -Encoding ASCII (Join-Path $InstallDir 'REPAIR-OR-UPDATE.cmd')

@'
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\Uninstall-MLVResolveFS.ps1"
'@ | Set-Content -Encoding ASCII (Join-Path $InstallDir 'UNINSTALL.cmd')

# Recreate shortcuts.
$powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$shortcutArgs = '-NoProfile -ExecutionPolicy Bypass -STA -File "{0}"' -f $TargetLauncher
$ws = New-Object -ComObject WScript.Shell

$startMenuDir = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs'
$startShortcut = $ws.CreateShortcut((Join-Path $startMenuDir 'MLV Resolve FS.lnk'))
$startShortcut.TargetPath = $powershell
$startShortcut.Arguments = $shortcutArgs
$startShortcut.WorkingDirectory = $InstallDir
$startShortcut.Description = 'Mount Magic Lantern MLV footage as virtual CinemaDNG for DaVinci Resolve'
$startShortcut.Save()

$desktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
$desktopShortcut = $ws.CreateShortcut((Join-Path $desktop 'MLV Resolve FS.lnk'))
$desktopShortcut.TargetPath = $powershell
$desktopShortcut.Arguments = $shortcutArgs
$desktopShortcut.WorkingDirectory = $InstallDir
$desktopShortcut.Description = 'Mount Magic Lantern MLV footage as virtual CinemaDNG for DaVinci Resolve'
$desktopShortcut.Save()

Write-Host ''
Write-Host 'MLV Resolve FS v2.8 streamlined launcher installed.' -ForegroundColor Green
Write-Host 'The working backend was not rebuilt.' -ForegroundColor Green
Write-Host 'Opening MLV Resolve FS...' -ForegroundColor Yellow
Start-Process -FilePath $powershell -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-STA','-File',('"' + $TargetLauncher + '"'))
Start-Sleep -Seconds 1
